-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: petgrooming_system
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `petgrooming_system`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `petgrooming_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `petgrooming_system`;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'pawcareservicesystem','petgrooming@2006');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointment_services`
--

DROP TABLE IF EXISTS `appointment_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointment_services` (
  `appointment_service_id` int(11) NOT NULL AUTO_INCREMENT,
  `appointment_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  PRIMARY KEY (`appointment_service_id`),
  KEY `appointment_id` (`appointment_id`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `appointment_services_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`appointment_id`),
  CONSTRAINT `appointment_services_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `grooming_services` (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment_services`
--

LOCK TABLES `appointment_services` WRITE;
/*!40000 ALTER TABLE `appointment_services` DISABLE KEYS */;
INSERT INTO `appointment_services` VALUES (1,1,3),(2,2,5),(3,2,2),(4,3,1),(5,3,4),(6,4,6),(7,4,4),(8,5,5),(9,5,4),(10,6,5),(11,6,4);
/*!40000 ALTER TABLE `appointment_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL AUTO_INCREMENT,
  `pet_id` varchar(20) NOT NULL,
  `service_id` int(11) NOT NULL,
  `groomer_id` varchar(20) DEFAULT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  PRIMARY KEY (`appointment_id`),
  KEY `pet_id` (`pet_id`),
  KEY `service_id` (`service_id`),
  KEY `fk_appointment_groomer` (`groomer_id`),
  CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`pet_id`) REFERENCES `pets` (`pet_id`),
  CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `grooming_services` (`service_id`),
  CONSTRAINT `fk_appointment_groomer` FOREIGN KEY (`groomer_id`) REFERENCES `groomers` (`groomer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
INSERT INTO `appointments` VALUES (1,'P001',3,'G001','2026-10-10','09:00:00','Completed'),(2,'P008',5,'G002','2026-10-10','10:30:00','Completed'),(3,'P002',1,'G003','2026-10-12','09:00:00','Pending'),(4,'P011',6,'G004','2026-10-12','14:00:00','Pending'),(5,'P011',5,'G001','2026-10-11','16:00:00','Completed'),(6,'P001',5,'G002','2026-10-11','16:00:00','In Progress');
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customer_id` varchar(20) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `contact_number` varchar(20) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Active',
  `date_registered` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES ('C001','John','Cruz','09171234567','Cagayan de Oro City','Active','2026-10-09 11:59:20'),('C002','Maria','Santos','09281234567','Iligan City','Active','2026-10-09 11:59:20'),('C003','James','Reyes','09391234567','Tagoloan, Misamis Oriental','Active','2026-10-09 11:59:20'),('C004','Anna','Garcia','09451234567','Opol, Misamis Oriental','Active','2026-10-09 11:59:20'),('C005','Mark','Dela Cruz','09561234567','Cagayan de Oro City','Archived','2026-10-09 11:59:20'),('C006','Mark','Cruz','09557149373','Jasaan Misamis Oriental','Active','2026-10-09 11:59:20'),('C007','Noriel','Japos','0936775368','Pagatpat Cagayan De Oro City','Active','2026-10-11 04:06:22');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groomers`
--

DROP TABLE IF EXISTS `groomers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groomers` (
  `groomer_id` varchar(20) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Active',
  PRIMARY KEY (`groomer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groomers`
--

LOCK TABLES `groomers` WRITE;
/*!40000 ALTER TABLE `groomers` DISABLE KEYS */;
INSERT INTO `groomers` VALUES ('G001','Axel John','Blaya','09123456789','General Pet Grooming','Active'),('G002','Hannah Gwyn','Linhogan','09987654321','General Pet Grooming','Active'),('G003','Honey Mae','Japos','09112223330','General Pet Grooming','Active'),('G004','Kenth','Loong','09223334444','General Pet Grooming','Active'),('G005','Lesther Jed','Nunez','09334445555','General Pet Grooming','Active');
/*!40000 ALTER TABLE `groomers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grooming_records`
--

DROP TABLE IF EXISTS `grooming_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grooming_records` (
  `record_id` int(11) NOT NULL AUTO_INCREMENT,
  `appointment_id` int(11) NOT NULL,
  `allergy` varchar(10) DEFAULT NULL,
  `allergy_details` text DEFAULT NULL,
  `behavior` varchar(50) DEFAULT NULL,
  `special_care` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `grooming_date` date DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`record_id`),
  KEY `appointment_id` (`appointment_id`),
  CONSTRAINT `grooming_records_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`appointment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grooming_records`
--

LOCK TABLES `grooming_records` WRITE;
/*!40000 ALTER TABLE `grooming_records` DISABLE KEYS */;
INSERT INTO `grooming_records` VALUES (1,1,'No','','Calm','None','Full grooming done. Coat is clean and soft.','2026-10-10','Active'),(2,2,'Yes','Sensitive skin, use mild shampoo only','Nervous','Handle gently and keep ears dry','Bath and nail trimming done. Pet stayed calm after the bath.','2026-10-10','Active');
/*!40000 ALTER TABLE `grooming_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grooming_services`
--

DROP TABLE IF EXISTS `grooming_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grooming_services` (
  `service_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` varchar(20) DEFAULT 'Active',
  `duration_minutes` int(11) NOT NULL DEFAULT 60,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grooming_services`
--

LOCK TABLES `grooming_services` WRITE;
/*!40000 ALTER TABLE `grooming_services` DISABLE KEYS */;
INSERT INTO `grooming_services` VALUES (1,'Bath & Blow Dry','Shampoo bath with blow dry',350.00,'Active',60),(2,'Nail Trimming','Nail cutting and filing',150.00,'Active',30),(3,'Full Grooming','Bath, haircut, nail trimming and ear cleaning',600.00,'Active',120),(4,'Ear Cleaning','Gentle ear cleaning',200.00,'Active',30),(5,'Basic Bath','Basic shampoo bath',300.00,'Active',60),(6,'Haircut','Coat trimming and styling',400.00,'Active',60);
/*!40000 ALTER TABLE `grooming_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `appointment_id` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `change_amount` decimal(10,2) DEFAULT 0.00,
  `payment_status` varchar(20) DEFAULT 'Pending',
  `payment_date` date NOT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `appointment_id` (`appointment_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`appointment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,1,600.00,600.00,400.00,'Paid','2026-10-10'),(2,2,450.00,450.00,50.00,'Paid','2026-10-10'),(3,3,550.00,200.00,0.00,'Partial','2026-10-10'),(4,4,600.00,300.00,0.00,'Partial','2026-10-10'),(5,6,500.00,300.00,700.00,'Partial','2026-10-11');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pets`
--

DROP TABLE IF EXISTS `pets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pets` (
  `pet_id` varchar(20) NOT NULL,
  `customer_id` varchar(20) NOT NULL,
  `pet_name` varchar(100) NOT NULL,
  `pet_type` varchar(50) NOT NULL,
  `breed` varchar(100) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`pet_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `pets_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pets`
--

LOCK TABLES `pets` WRITE;
/*!40000 ALTER TABLE `pets` DISABLE KEYS */;
INSERT INTO `pets` VALUES ('P001','C001','Bruno Jr.','Dog','Golden Retriever',2,'MALE'),('P002','C001','Mimi','Cat','Persian',4,'FEMALE'),('P003','C002','Max','Dog','Shih Tzu',4,'MALE'),('P004','C003','Coco','Dog','Poodle',5,'FEMALE'),('P005','C004','Luna','Cat','Siamese',2,'FEMALE'),('P006','C004','Rocky','Dog','Beagle',3,'MALE'),('P007','C005','Bunny','Rabbit','Holland Lop',1,'FEMALE'),('P008','C006','Eunice','Dog','BullDog',7,'FEMALE'),('P011','C001','Maxxy','Dog','Chiwawa',5,'FEMALE'),('P012','C007','LingLing','Dog','Hotdog',6,'FEMALE');
/*!40000 ALTER TABLE `pets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-11 17:11:35
