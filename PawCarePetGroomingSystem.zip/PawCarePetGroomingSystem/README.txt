PAWCARE PET GROOMING SYSTEM
Java Swing desktop app (NetBeans, Maven, MySQL)

REQUIREMENTS
- Java 17 or higher
- Apache NetBeans
- XAMPP (Apache and MySQL)

HOW TO RUN
1. Open XAMPP Control Panel and start Apache and MySQL.
2. Open phpMyAdmin (http://localhost/phpmyadmin).
3. Click Import, choose petgrooming_system.sql, and click Import.
   (The file creates the database petgrooming_system with sample data.)
4. Open the project folder PawCarePetGroomingSystem in NetBeans.
5. Right-click the project, choose Clean and Build, then Run.
   The main class is com.mycompany.pawcarepetgroomingsystem.PawCarePetGroomingSystem.

LOGIN
Username: pawcareservicesystem
Password: petgrooming@2006
(The login is saved in the admins table in the database.)

DATABASE CONNECTION
Host: localhost:3306, Database: petgrooming_system
User: root, Password: (empty)

FEATURES
- Login
- Customer and Pet (add, update, archive, search)
- Groomers and Grooming Services
- Appointments (multiple services per appointment)
- Grooming Check (save, update, archive, complete)
- Payments
- Reports (by customer and date range)