package service;

import database.DBConnection;
import model.Payment;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class PaymentService {

    public boolean addPayment(Payment payment) {

        String sql = "INSERT INTO payments "
                   + "(appointment_id, total_amount, amount_paid, "
                   + "change_amount, payment_status, payment_date) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, payment.getAppointmentId());
            pst.setBigDecimal(2, payment.getTotalAmount());
            pst.setBigDecimal(3, payment.getAmountPaid());
            pst.setBigDecimal(4, payment.getChangeAmount());
            pst.setString(5, payment.getPaymentStatus());
            pst.setDate(6, payment.getPaymentDate());

            return pst.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public ArrayList<Payment> getAllPayments() {

        ArrayList<Payment> payments = new ArrayList<>();

        String sql = "SELECT * FROM payments "
                   + "ORDER BY payment_id DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {

                Payment payment = new Payment();

                payment.setPaymentId(
                    rs.getInt("payment_id")
                );

                payment.setAppointmentId(
                    rs.getInt("appointment_id")
                );

                payment.setTotalAmount(
                    rs.getBigDecimal("total_amount")
                );

                payment.setAmountPaid(
                    rs.getBigDecimal("amount_paid")
                );

                payment.setChangeAmount(
                    rs.getBigDecimal("change_amount")
                );

                payment.setPaymentStatus(
                    rs.getString("payment_status")
                );

                payment.setPaymentDate(
                    rs.getDate("payment_date")
                );

                payments.add(payment);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return payments;
    }

    public boolean updatePayment(Payment payment) {

        String sql = "UPDATE payments SET "
                   + "appointment_id = ?, "
                   + "total_amount = ?, "
                   + "amount_paid = ?, "
                   + "change_amount = ?, "
                   + "payment_status = ?, "
                   + "payment_date = ? "
                   + "WHERE payment_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, payment.getAppointmentId());
            pst.setBigDecimal(2, payment.getTotalAmount());
            pst.setBigDecimal(3, payment.getAmountPaid());
            pst.setBigDecimal(4, payment.getChangeAmount());
            pst.setString(5, payment.getPaymentStatus());
            pst.setDate(6, payment.getPaymentDate());
            pst.setInt(7, payment.getPaymentId());

            return pst.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean archivePayment(int paymentId) {

        String sql = "UPDATE payments "
                   + "SET payment_status = 'Archived' "
                   + "WHERE payment_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, paymentId);

            return pst.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

public ArrayList<Payment> searchPayments(String keyword) {

    ArrayList<Payment> payments = new ArrayList<>();

    String sql = "SELECT * FROM payments "
               + "WHERE payment_status <> 'Archived' "
               + "AND (CAST(payment_id AS CHAR) LIKE ? "
               + "OR CAST(appointment_id AS CHAR) LIKE ? "
               + "OR payment_status LIKE ?) "
               + "ORDER BY payment_id DESC";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        String search = "%" + keyword + "%";

        pst.setString(1, search);
        pst.setString(2, search);
        pst.setString(3, search);

        ResultSet rs = pst.executeQuery();

        while (rs.next()) {

            Payment payment = new Payment();

            payment.setPaymentId(
                rs.getInt("payment_id")
            );

            payment.setAppointmentId(
                rs.getInt("appointment_id")
            );

            payment.setTotalAmount(
                rs.getBigDecimal("total_amount")
            );

            payment.setAmountPaid(
                rs.getBigDecimal("amount_paid")
            );

            payment.setChangeAmount(
                rs.getBigDecimal("change_amount")
            );

            payment.setPaymentStatus(
                rs.getString("payment_status")
            );

            payment.setPaymentDate(
                rs.getDate("payment_date")
            );

            payments.add(payment);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return payments;
}

 public BigDecimal getAppointmentTotal(int appointmentId) {

    String sql =
            "SELECT COALESCE(SUM(gs.price), 0) AS total "
          + "FROM appointment_services aps "
          + "JOIN grooming_services gs "
          + "ON aps.service_id = gs.service_id "
          + "WHERE aps.appointment_id = ?";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setInt(1, appointmentId);

        ResultSet rs = pst.executeQuery();

        if (rs.next()) {

            return rs.getBigDecimal("total");
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    return BigDecimal.ZERO;
}
}