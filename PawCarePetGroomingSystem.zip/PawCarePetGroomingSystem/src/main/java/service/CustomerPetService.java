package service;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustomerPetService {

    public String generateCustomerId() {

        int nextId = 1;

        try {
            Connection con = DBConnection.getConnection();

            String sql = "SELECT MAX(CAST(SUBSTRING(customer_id, 2) AS UNSIGNED)) "
                       + "FROM customers";

            PreparedStatement pst = con.prepareStatement(sql);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                nextId = rs.getInt(1) + 1;
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return String.format("C%03d", nextId);
    }

    public String generatePetId() {

        int nextId = 1;

        try {
            Connection con = DBConnection.getConnection();

            String sql = "SELECT MAX(CAST(SUBSTRING(pet_id, 2) AS UNSIGNED)) "
                       + "FROM pets";

            PreparedStatement pst = con.prepareStatement(sql);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                nextId = rs.getInt(1) + 1;
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return String.format("P%03d", nextId);
    }
}