package com.mycompany.pawcarepetgroomingsystem;

import gui.LoginFrame;

public class PawCarePetGroomingSystem {

    public static void main(String[] args) {

        java.awt.EventQueue.invokeLater(() -> {
            LoginFrame login = new LoginFrame();
            login.setVisible(true);
        });
    }
}