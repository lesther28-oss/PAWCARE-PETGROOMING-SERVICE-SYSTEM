
package gui;

import database.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GroomingServiceFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(GroomingServiceFrame.class.getName());

    public GroomingServiceFrame() {
    initComponents();

    loadServices();
    setupTable();
txtServiceId.setEditable(false);

    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtServiceId = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtServiceName = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtDescription = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtPrice = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        btnAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnArchieve = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        cmbStatus = new javax.swing.JComboBox<>();
        lblDuration = new javax.swing.JLabel();
        txtDuration = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        txtSearch = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblGroomingServices = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(241, 248, 254));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(227, 240, 253));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(36, 59, 90));
        jLabel1.setText("GROOMING SERVICE");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, -1, 30));

        jLabel2.setForeground(new java.awt.Color(36, 59, 90));
        jLabel2.setText("Manage the Grooming Services offered by PawCare");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 40, -1, 20));

        btnBack.setBackground(new java.awt.Color(36, 59, 90));
        btnBack.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        btnBack.setForeground(java.awt.Color.white);
        btnBack.setText("←");
        btnBack.addActionListener(this::btnBackActionPerformed);
        jPanel1.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 30, 30));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gui/petimage3.jpg"))); // NOI18N
        jPanel1.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 0, -1, 70));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 6, 1240, 70));

        jPanel2.setBackground(new java.awt.Color(52, 89, 145));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.setPreferredSize(new java.awt.Dimension(620, 300));

        jPanel6.setBackground(new java.awt.Color(241, 248, 254));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel6.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 6, -1, -1));

        jLabel6.setText("Service ID");
        jPanel6.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 6, -1, -1));

        txtServiceId.addActionListener(this::txtServiceIdActionPerformed);
        jPanel6.add(txtServiceId, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 28, 330, -1));

        jLabel7.setText("Service Name");
        jPanel6.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 62, -1, -1));

        txtServiceName.addActionListener(this::txtServiceNameActionPerformed);
        jPanel6.add(txtServiceName, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 90, 330, -1));

        jLabel8.setText("Description");
        jPanel6.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 124, -1, -1));
        jPanel6.add(txtDescription, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 146, 330, 30));

        jLabel9.setText("Price");
        jPanel6.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 10, 36, -1));

        txtPrice.addActionListener(this::txtPriceActionPerformed);
        jPanel6.add(txtPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 30, 340, -1));

        jLabel10.setText("Status");
        jPanel6.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 120, -1, -1));

        btnAdd.setText("ADD");
        btnAdd.addActionListener(this::btnAddActionPerformed);
        jPanel6.add(btnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 192, 140, -1));

        btnUpdate.setText("UPDATE");
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);
        jPanel6.add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 190, 170, 20));

        btnArchieve.setText("ARCHIVE");
        btnArchieve.addActionListener(this::btnArchieveActionPerformed);
        jPanel6.add(btnArchieve, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 190, 190, 20));

        btnClear.setText("CLEAR");
        btnClear.addActionListener(this::btnClearActionPerformed);
        jPanel6.add(btnClear, new org.netbeans.lib.awtextra.AbsoluteConstraints(632, 190, 140, 20));

        cmbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose Status", "Active", "Archived" }));
        cmbStatus.addActionListener(this::cmbStatusActionPerformed);
        jPanel6.add(cmbStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 140, 340, 30));

        lblDuration.setText("Duration (min)");
        jPanel6.add(lblDuration, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 60, -1, -1));
        jPanel6.add(txtDuration, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 80, 340, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("SERVICE INFORMATION");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel4))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel5)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, 848, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 850, 260));

        jPanel3.setBackground(new java.awt.Color(227, 240, 253));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));

        jPanel7.setBackground(new java.awt.Color(52, 89, 145));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("FEATURE SERVICE");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        jLabel12.setText("Basic Bath");

        jLabel13.setText("Full Grooming");

        jLabel15.setText("Ear Cleaning");

        jLabel17.setText("Nail Trimming");

        jLabel18.setText("Haircut");

        jLabel19.setText("Bath & Blow Dry");

        jLabel20.setText("₱350.00");

        jLabel21.setText(" ₱200.00");

        jLabel22.setText("₱300.00");

        jLabel23.setText("₱600.00");

        jLabel24.setText("₱150.00");

        jLabel25.setText("  ₱400.00");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel13)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(jLabel14))
                    .addComponent(jLabel17)
                    .addComponent(jLabel12)
                    .addComponent(jLabel18)
                    .addComponent(jLabel19)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel16)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 134, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel20, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel22, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel23, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel24, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel25, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(55, 55, 55))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel19)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(96, 96, 96)
                        .addComponent(jLabel16))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17)
                            .addComponent(jLabel24))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(jLabel23))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15)
                            .addComponent(jLabel21))))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addComponent(jLabel22))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(jLabel25))
                .addGap(60, 60, 60))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 100, 350, 260));

        jPanel4.setBackground(new java.awt.Color(241, 248, 254));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));

        txtSearch.addActionListener(this::txtSearchActionPerformed);

        btnSearch.setText("SEARCH");
        btnSearch.addActionListener(this::btnSearchActionPerformed);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(768, Short.MAX_VALUE)
                .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearch, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 1250, 60));

        jPanel5.setBackground(new java.awt.Color(227, 240, 253));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblGroomingServices.setForeground(new java.awt.Color(52, 89, 145));
        tblGroomingServices.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Service ID", "Service Name", "Description", "Price ", "Duration", "Status"
            }
        ));
        tblGroomingServices.setGridColor(new java.awt.Color(36, 59, 90));
        tblGroomingServices.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblGroomingServicesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblGroomingServices);

        jPanel5.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1240, 230));

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, 1260, 260));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtServiceIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtServiceIdActionPerformed
       
    }//GEN-LAST:event_txtServiceIdActionPerformed

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
    
    }//GEN-LAST:event_txtSearchActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
                                       
    String keyword = txtSearch.getText().trim().toLowerCase();

    DefaultTableModel model =
            (DefaultTableModel) tblGroomingServices.getModel();

    model.setRowCount(0);

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {
            JOptionPane.showMessageDialog(
                this,
                "Cannot connect to the database.",
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        String sql =
                "SELECT service_id, service_name, description, price, "
              + "duration_minutes, status "
              + "FROM grooming_services "
              + "WHERE CAST(service_id AS CHAR) LIKE ? "
              + "OR LOWER(service_name) LIKE ? "
              + "OR LOWER(description) LIKE ? "
              + "OR CAST(price AS CHAR) LIKE ? "
              + "OR CAST(duration_minutes AS CHAR) LIKE ? "
              + "OR LOWER(status) LIKE ? "
              + "ORDER BY service_id";

        PreparedStatement pst = con.prepareStatement(sql);

        String like = "%" + keyword + "%";

        pst.setString(1, like);
        pst.setString(2, like);
        pst.setString(3, like);
        pst.setString(4, like);
        pst.setString(5, like);
        pst.setString(6, like);

        ResultSet rs = pst.executeQuery();

        int count = 0;

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("service_id"),
                rs.getString("service_name"),
                rs.getString("description"),
                String.format("%.2f", rs.getDouble("price")),
                rs.getInt("duration_minutes"),
                rs.getString("status")
            });

            count++;
        }

        rs.close();
        pst.close();
        con.close();

        if (count == 0) {
            JOptionPane.showMessageDialog(
                this,
                "No grooming service found.",
                "Search Result",
                JOptionPane.INFORMATION_MESSAGE
            );
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
            this,
            "Error searching grooming services:\n"
                + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
 
        MainFrame main = new MainFrame();
        main.setVisible(true);
        this.dispose();      
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
                                       
    String serviceName = txtServiceName.getText().trim();
    String description = txtDescription.getText().trim();
    String priceText = txtPrice.getText().trim();
    String durationText = txtDuration.getText().trim();
    String status = cmbStatus.getSelectedItem().toString();

    if (serviceName.isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "Please enter the service name.",
            "Missing Information",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (priceText.isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "Please enter the price.",
            "Missing Information",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (durationText.isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "Please enter the estimated duration.",
            "Missing Information",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    double price;

    try {

        price = Double.parseDouble(priceText);

        if (price < 0) {
            throw new NumberFormatException();
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
            this,
            "Price must be a valid number and cannot be negative.",
            "Invalid Price",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    int duration;

    try {

        duration = Integer.parseInt(durationText);

        if (duration <= 0) {
            throw new NumberFormatException();
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
            this,
            "Duration must be a positive whole number in minutes.",
            "Invalid Duration",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (cmbStatus.getSelectedIndex() == 0) {

        JOptionPane.showMessageDialog(
            this,
            "Please select a status.",
            "Missing Information",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                this,
                "Could not connect to the database.",
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        String checkSql =
            "SELECT COUNT(*) FROM grooming_services "
            + "WHERE LOWER(service_name) = LOWER(?)";

        PreparedStatement checkPst =
            con.prepareStatement(checkSql);

        checkPst.setString(1, serviceName);

        ResultSet checkRs =
            checkPst.executeQuery();

        if (checkRs.next() && checkRs.getInt(1) > 0) {

            JOptionPane.showMessageDialog(
                this,
                "This grooming service already exists.",
                "Duplicate Service",
                JOptionPane.WARNING_MESSAGE
            );

            con.close();

            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to add this grooming service?",
            "Confirm Add",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (confirm != JOptionPane.YES_OPTION) {

            con.close();

            return;
        }

        String sql =
            "INSERT INTO grooming_services "
            + "(service_name, description, price, duration_minutes, status) "
            + "VALUES (?, ?, ?, ?, ?)";

        PreparedStatement pst =
            con.prepareStatement(
                sql,
                Statement.RETURN_GENERATED_KEYS
            );

        pst.setString(1, serviceName);
        pst.setString(2, description);
        pst.setDouble(3, price);
        pst.setInt(4, duration);
        pst.setString(5, status);

        pst.executeUpdate();

        ResultSet rs =
            pst.getGeneratedKeys();

        int serviceId = 0;

        if (rs.next()) {
            serviceId = rs.getInt(1);
        }

        txtServiceId.setText(
            String.valueOf(serviceId)
        );

        DefaultTableModel model =
            (DefaultTableModel) tblGroomingServices.getModel();

        model.addRow(new Object[]{
            serviceId,
            serviceName,
            description,
            String.format("%.2f", price),
            duration,
            status
        });

        JOptionPane.showMessageDialog(
            this,
            "Grooming service added successfully!",
            "Success",
            JOptionPane.INFORMATION_MESSAGE
        );

        con.close();

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Database Error: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE
        );

        e.printStackTrace();
    }
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
                                          
    int selectedRow = tblGroomingServices.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this,
                "Please select a grooming service to update.",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
        return;
    }

    String serviceIdText = txtServiceId.getText().trim();
    String serviceName = txtServiceName.getText().trim();
    String description = txtDescription.getText().trim();
    String priceText = txtPrice.getText().trim();
    String durationText = txtDuration.getText().trim();
    String status = cmbStatus.getSelectedItem().toString();

    if (serviceIdText.isEmpty()) {
        JOptionPane.showMessageDialog(this,
                "Service ID is missing. Please select a row from the table.",
                "Validation Error",
                JOptionPane.WARNING_MESSAGE);
        return;
    }

    int serviceId;

    try {
        serviceId = Integer.parseInt(serviceIdText);

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(this,
                "Service ID must be a number.",
                "Validation Error",
                JOptionPane.WARNING_MESSAGE);
        return;
    }

    if (serviceName.isEmpty()) {

        JOptionPane.showMessageDialog(this,
                "Please enter the service name.",
                "Validation Error",
                JOptionPane.WARNING_MESSAGE);

        txtServiceName.requestFocus();
        return;
    }

    if (priceText.isEmpty()) {

        JOptionPane.showMessageDialog(this,
                "Please enter the price.",
                "Validation Error",
                JOptionPane.WARNING_MESSAGE);

        txtPrice.requestFocus();
        return;
    }

    if (durationText.isEmpty()) {

        JOptionPane.showMessageDialog(this,
                "Please enter the estimated duration.",
                "Validation Error",
                JOptionPane.WARNING_MESSAGE);

        txtDuration.requestFocus();
        return;
    }

    double price;

    try {

        price = Double.parseDouble(priceText);

        if (price < 0) {
            throw new NumberFormatException();
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(this,
                "Invalid price. Please enter numbers only (example: 350.00).",
                "Validation Error",
                JOptionPane.WARNING_MESSAGE);

        txtPrice.requestFocus();
        return;
    }

    int duration;

    try {

        duration = Integer.parseInt(durationText);

        if (duration <= 0) {
            throw new NumberFormatException();
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(this,
                "Duration must be a positive whole number in minutes.",
                "Validation Error",
                JOptionPane.WARNING_MESSAGE);

        txtDuration.requestFocus();
        return;
    }

    if (status.equals("Choose Status") || status.isEmpty()) {

        JOptionPane.showMessageDialog(this,
                "Please select a status.",
                "Validation Error",
                JOptionPane.WARNING_MESSAGE);
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to update this grooming service?",
            "Confirm Update",
            JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        String checkSql =
                "SELECT service_id FROM grooming_services "
                + "WHERE LOWER(service_name) = LOWER(?) "
                + "AND service_id <> ?";

        PreparedStatement checkPst =
                con.prepareStatement(checkSql);

        checkPst.setString(1, serviceName);
        checkPst.setInt(2, serviceId);

        ResultSet rs = checkPst.executeQuery();

        if (rs.next()) {

            JOptionPane.showMessageDialog(this,
                    "Another service with this name already exists.",
                    "Duplicate Service",
                    JOptionPane.WARNING_MESSAGE);

            rs.close();
            checkPst.close();
            con.close();

            return;
        }

        rs.close();
        checkPst.close();

        String sql =
                "UPDATE grooming_services "
                + "SET service_name = ?, "
                + "description = ?, "
                + "price = ?, "
                + "duration_minutes = ?, "
                + "status = ? "
                + "WHERE service_id = ?";

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setString(1, serviceName);
        pst.setString(2, description);
        pst.setDouble(3, price);
        pst.setInt(4, duration);
        pst.setString(5, status);
        pst.setInt(6, serviceId);

        int rowsUpdated = pst.executeUpdate();

        pst.close();
        con.close();

        if (rowsUpdated > 0) {

            DefaultTableModel model =
                    (DefaultTableModel) tblGroomingServices.getModel();

            model.setValueAt(serviceName, selectedRow, 1);
            model.setValueAt(description, selectedRow, 2);
            model.setValueAt(String.format("%.2f", price), selectedRow, 3);
            model.setValueAt(duration, selectedRow, 4);
            model.setValueAt(status, selectedRow, 5);

            JOptionPane.showMessageDialog(this,
                    "Grooming service updated successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

        } else {

            JOptionPane.showMessageDialog(this,
                    "No record was updated. Please try again.",
                    "Update Failed",
                    JOptionPane.WARNING_MESSAGE);
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(this,
                "Error updating grooming service:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void txtServiceNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtServiceNameActionPerformed

    }//GEN-LAST:event_txtServiceNameActionPerformed

    private void btnArchieveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchieveActionPerformed
                                            
    int selectedRow = tblGroomingServices.getSelectedRow();

    if (selectedRow == -1) {

        JOptionPane.showMessageDialog(
            this,
            "Please select a grooming service to archive.",
            "No Selection",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    DefaultTableModel model =
            (DefaultTableModel) tblGroomingServices.getModel();

    int serviceId =
            Integer.parseInt(
                model.getValueAt(selectedRow, 0).toString()
            );

    String serviceName =
            model.getValueAt(selectedRow, 1).toString();

    String currentStatus =
            model.getValueAt(selectedRow, 5).toString();

    if (currentStatus.equalsIgnoreCase("Archived")) {

        JOptionPane.showMessageDialog(
            this,
            "This grooming service is already archived.",
            "Already Archived",
            JOptionPane.INFORMATION_MESSAGE
        );

        return;
    }

    int confirm = JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to archive \"" + serviceName + "\"?",
        "Confirm Archive",
        JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                this,
                "Cannot connect to the database.",
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        String sql =
                "UPDATE grooming_services "
                + "SET status = ? "
                + "WHERE service_id = ?";

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setString(1, "Archived");
        pst.setInt(2, serviceId);

        int rowsUpdated =
                pst.executeUpdate();

        pst.close();
        con.close();

        if (rowsUpdated > 0) {

            model.setValueAt(
                "Archived",
                selectedRow,
                5
            );

            JOptionPane.showMessageDialog(
                this,
                "Grooming service archived successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE
            );

        } else {

            JOptionPane.showMessageDialog(
                this,
                "No record was archived. Please try again.",
                "Archive Failed",
                JOptionPane.WARNING_MESSAGE
            );
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
            this,
            "Error archiving grooming service:\n"
                + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnArchieveActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
                                        
    txtServiceId.setText("");
    txtServiceName.setText("");
    txtDescription.setText("");
    txtPrice.setText("");
    txtDuration.setText("");
    cmbStatus.setSelectedIndex(0);

    tblGroomingServices.clearSelection();

    txtServiceName.requestFocus();
    }//GEN-LAST:event_btnClearActionPerformed

    private void cmbStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbStatusActionPerformed
      
    }//GEN-LAST:event_cmbStatusActionPerformed

    private void txtPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPriceActionPerformed
      
    }//GEN-LAST:event_txtPriceActionPerformed

    private void tblGroomingServicesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblGroomingServicesMouseClicked
                                                
    int selectedRow = tblGroomingServices.getSelectedRow();

    if (selectedRow == -1) {
        return;
    }

    DefaultTableModel model =
            (DefaultTableModel) tblGroomingServices.getModel();

    Object serviceId =
            model.getValueAt(selectedRow, 0);

    Object serviceName =
            model.getValueAt(selectedRow, 1);

    Object description =
            model.getValueAt(selectedRow, 2);

    Object price =
            model.getValueAt(selectedRow, 3);

    Object duration =
            model.getValueAt(selectedRow, 4);

    Object status =
            model.getValueAt(selectedRow, 5);

    txtServiceId.setText(
            serviceId == null
                ? ""
                : serviceId.toString()
    );

    txtServiceName.setText(
            serviceName == null
                ? ""
                : serviceName.toString()
    );

    txtDescription.setText(
            description == null
                ? ""
                : description.toString()
    );

    txtPrice.setText(
            price == null
                ? ""
                : price.toString()
    );

    txtDuration.setText(
            duration == null
                ? ""
                : duration.toString()
    );

    if (status != null) {

        cmbStatus.setSelectedItem(
                status.toString()
        );
    }
    }//GEN-LAST:event_tblGroomingServicesMouseClicked
private void loadServices() {

    DefaultTableModel model =
            (DefaultTableModel) tblGroomingServices.getModel();

    model.setRowCount(0);

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        String sql =
                "SELECT service_id, service_name, description, "
              + "price, duration_minutes, status "
              + "FROM grooming_services "
              + "ORDER BY service_id";

        PreparedStatement pst =
                con.prepareStatement(sql);

        ResultSet rs =
                pst.executeQuery();

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("service_id"),
                rs.getString("service_name"),
                rs.getString("description"),
                String.format("%.2f", rs.getDouble("price")),
                rs.getInt("duration_minutes"),
                rs.getString("status")
            });
        }

        rs.close();
        pst.close();
        con.close();

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error loading grooming services:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
private void setupTable() {

    javax.swing.table.TableRowSorter<DefaultTableModel> sorter =
            new javax.swing.table.TableRowSorter<>((DefaultTableModel) tblGroomingServices.getModel());
    tblGroomingServices.setRowSorter(sorter);

    sorter.setComparator(0, (a, b) ->
        Integer.compare(Integer.parseInt(a.toString()), Integer.parseInt(b.toString())));

sorter.setComparator(3, (a, b) ->
        Double.compare(Double.parseDouble(a.toString()), Double.parseDouble(b.toString())));

sorter.setComparator(4, (a, b) ->
        Integer.compare(
            Integer.parseInt(a.toString()),
            Integer.parseInt(b.toString())
        ));
    javax.swing.table.DefaultTableCellRenderer renderer = new javax.swing.table.DefaultTableCellRenderer() {

        @Override
        public java.awt.Component getTableCellRendererComponent(
                javax.swing.JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {

            if (column == 3 && value != null) {
                value = "₱" + value.toString();
            }

            java.awt.Component c = super.getTableCellRendererComponent(
                    table, value, isSelected, hasFocus, row, column);

            int modelRow = table.convertRowIndexToModel(row);
            Object status = table.getModel().getValueAt(modelRow, 5);

            if (!isSelected) {
                if (status != null && status.toString().equalsIgnoreCase("Archived")) {
                    c.setForeground(new java.awt.Color(150, 150, 150));
                } else {
                    c.setForeground(new java.awt.Color(52, 89, 145));
                }
            }

            return c;
        }
    };

    tblGroomingServices.setDefaultRenderer(Object.class, renderer);
}
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> new GroomingServiceFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnArchieve;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cmbStatus;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblDuration;
    private javax.swing.JTable tblGroomingServices;
    private javax.swing.JTextField txtDescription;
    private javax.swing.JTextField txtDuration;
    private javax.swing.JTextField txtPrice;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtServiceId;
    private javax.swing.JTextField txtServiceName;
    // End of variables declaration//GEN-END:variables
}
