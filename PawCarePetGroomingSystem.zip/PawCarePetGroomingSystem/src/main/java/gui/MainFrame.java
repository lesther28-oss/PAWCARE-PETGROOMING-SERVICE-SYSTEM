
package gui;
import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class MainFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MainFrame.class.getName());

   
    public MainFrame() {
    initComponents();

    loadTodaysAppointments();
    loadCustomerCount();
    loadPetCount();
    loadAppointmentCount();
    loadTodaysSales();

    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
}

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        pnlHeader = new javax.swing.JPanel();
        lblHeaderTitle = new javax.swing.JLabel();
        btnWelcome = new javax.swing.JLabel();
        lblSubHeader = new javax.swing.JLabel();
        pnlSideBar = new javax.swing.JPanel();
        btnDashboard = new javax.swing.JButton();
        btnCustomerandPet = new javax.swing.JButton();
        btnAppointment = new javax.swing.JButton();
        btnGroomingService = new javax.swing.JButton();
        btnGroomingCheck = new javax.swing.JButton();
        btnPayment = new javax.swing.JButton();
        btnReport = new javax.swing.JButton();
        btnLogOut = new javax.swing.JButton();
        lblSideBarTitle = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        btnGroomers = new javax.swing.JButton();
        btnPolicies = new javax.swing.JButton();
        pnlDashboard = new javax.swing.JPanel();
        lblDashboardTitle = new javax.swing.JLabel();
        lblDashboardSubtitle = new javax.swing.JLabel();
        pnlCustomerCard = new javax.swing.JPanel();
        lblCustomerCount = new javax.swing.JLabel();
        lblCustomerCardTitle = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        pnlAppointmentCard = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        pnlUpcoming = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MainFrame");
        setMinimumSize(new java.awt.Dimension(1366, 768));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pnlHeader.setBackground(new java.awt.Color(226, 241, 255));
        pnlHeader.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        pnlHeader.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblHeaderTitle.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        lblHeaderTitle.setForeground(new java.awt.Color(36, 59, 90));
        lblHeaderTitle.setText("PawCare Admin Dashboard ");
        pnlHeader.add(lblHeaderTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 10, -1, -1));

        btnWelcome.setForeground(new java.awt.Color(100, 100, 100));
        btnWelcome.setText("Welcome Admin");
        pnlHeader.add(btnWelcome, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 20, -1, -1));

        lblSubHeader.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblSubHeader.setText("Pet Grooming Management System");
        pnlHeader.add(lblSubHeader, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 40, -1, -1));

        getContentPane().add(pnlHeader, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 1030, 70));

        pnlSideBar.setBackground(new java.awt.Color(36, 59, 90));
        pnlSideBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnDashboard.setBackground(new java.awt.Color(36, 59, 90));
        btnDashboard.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        btnDashboard.setForeground(java.awt.Color.white);
        btnDashboard.setText("🏠︎ DASHBOARD");
        btnDashboard.addActionListener(this::btnDashboardActionPerformed);
        pnlSideBar.add(btnDashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, -1, -1));

        btnCustomerandPet.setBackground(new java.awt.Color(36, 59, 90));
        btnCustomerandPet.setFont(new java.awt.Font("Segoe UI Emoji", 1, 12)); // NOI18N
        btnCustomerandPet.setForeground(java.awt.Color.white);
        btnCustomerandPet.setText("🪪 CUSTOMER & PET");
        btnCustomerandPet.addActionListener(this::btnCustomerandPetActionPerformed);
        pnlSideBar.add(btnCustomerandPet, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, -1, -1));

        btnAppointment.setBackground(new java.awt.Color(36, 59, 90));
        btnAppointment.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        btnAppointment.setForeground(java.awt.Color.white);
        btnAppointment.setText("📆 APPOINTMENT");
        btnAppointment.addActionListener(this::btnAppointmentActionPerformed);
        pnlSideBar.add(btnAppointment, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 180, -1, -1));

        btnGroomingService.setBackground(new java.awt.Color(36, 59, 90));
        btnGroomingService.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        btnGroomingService.setForeground(java.awt.Color.white);
        btnGroomingService.setText("🛎️ GROOMING SERVICE");
        btnGroomingService.addActionListener(this::btnGroomingServiceActionPerformed);
        pnlSideBar.add(btnGroomingService, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 430, -1, -1));

        btnGroomingCheck.setBackground(new java.awt.Color(36, 59, 90));
        btnGroomingCheck.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        btnGroomingCheck.setForeground(java.awt.Color.white);
        btnGroomingCheck.setText("✍️ GROOMING CHECK ");
        btnGroomingCheck.addActionListener(this::btnGroomingCheckActionPerformed);
        pnlSideBar.add(btnGroomingCheck, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, -1, -1));

        btnPayment.setBackground(new java.awt.Color(36, 59, 90));
        btnPayment.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        btnPayment.setForeground(java.awt.Color.white);
        btnPayment.setText("💰 PAYMENT ");
        btnPayment.addActionListener(this::btnPaymentActionPerformed);
        pnlSideBar.add(btnPayment, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, -1, -1));

        btnReport.setBackground(new java.awt.Color(36, 59, 90));
        btnReport.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        btnReport.setForeground(java.awt.Color.white);
        btnReport.setText("🖨️ REPORT");
        btnReport.addActionListener(this::btnReportActionPerformed);
        pnlSideBar.add(btnReport, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 330, -1, -1));

        btnLogOut.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLogOut.setForeground(new java.awt.Color(36, 59, 90));
        btnLogOut.setText("LOGOUT");
        btnLogOut.addActionListener(this::btnLogOutActionPerformed);
        pnlSideBar.add(btnLogOut, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 670, -1, -1));

        lblSideBarTitle.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        lblSideBarTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblSideBarTitle.setText("🐾 PAWCARE");
        pnlSideBar.add(lblSideBarTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, -1, -1));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gui/petimage2.png"))); // NOI18N
        pnlSideBar.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, -1, 160));

        btnGroomers.setBackground(new java.awt.Color(36, 59, 90));
        btnGroomers.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        btnGroomers.setForeground(java.awt.Color.white);
        btnGroomers.setText("📝 GROOMERS ");
        btnGroomers.addActionListener(this::btnGroomersActionPerformed);
        pnlSideBar.add(btnGroomers, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, -1, -1));

        btnPolicies.setBackground(new java.awt.Color(36, 59, 90));
        btnPolicies.setFont(new java.awt.Font("Segoe UI Emoji", 1, 12)); // NOI18N
        btnPolicies.setForeground(java.awt.Color.white);
        btnPolicies.setText("📢 POLICIES");
        btnPolicies.addActionListener(this::btnPoliciesActionPerformed);
        pnlSideBar.add(btnPolicies, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 480, -1, -1));

        getContentPane().add(pnlSideBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 250, 880));

        pnlDashboard.setBackground(new java.awt.Color(241, 248, 254));
        pnlDashboard.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        pnlDashboard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblDashboardTitle.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblDashboardTitle.setForeground(new java.awt.Color(36, 59, 90));
        lblDashboardTitle.setText("Dashboard");
        pnlDashboard.add(lblDashboardTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 70, -1, -1));

        lblDashboardSubtitle.setForeground(new java.awt.Color(100, 100, 100));
        lblDashboardSubtitle.setText("Welcome back, Admin! Here's today's overview.");
        pnlDashboard.add(lblDashboardSubtitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(233, 44, -1, -1));

        pnlCustomerCard.setBackground(new java.awt.Color(255, 250, 240));
        pnlCustomerCard.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lblCustomerCount.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblCustomerCount.setForeground(new java.awt.Color(36, 59, 90));
        lblCustomerCount.setText("12");

        lblCustomerCardTitle.setForeground(new java.awt.Color(100, 100, 100));
        lblCustomerCardTitle.setText("Total Customers");

        javax.swing.GroupLayout pnlCustomerCardLayout = new javax.swing.GroupLayout(pnlCustomerCard);
        pnlCustomerCard.setLayout(pnlCustomerCardLayout);
        pnlCustomerCardLayout.setHorizontalGroup(
            pnlCustomerCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCustomerCardLayout.createSequentialGroup()
                .addGroup(pnlCustomerCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCustomerCardLayout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(lblCustomerCount))
                    .addGroup(pnlCustomerCardLayout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addComponent(lblCustomerCardTitle)))
                .addContainerGap(73, Short.MAX_VALUE))
        );
        pnlCustomerCardLayout.setVerticalGroup(
            pnlCustomerCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCustomerCardLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(lblCustomerCount)
                .addGap(18, 18, 18)
                .addComponent(lblCustomerCardTitle)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        pnlDashboard.add(pnlCustomerCard, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 130, 230, 140));

        jPanel2.setBackground(new java.awt.Color(255, 244, 244));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(36, 59, 90));
        jLabel2.setText("18");

        jLabel3.setForeground(new java.awt.Color(100, 100, 100));
        jLabel3.setText("Total Pets");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(88, 88, 88)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel2)))
                .addContainerGap(99, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        pnlDashboard.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 130, 240, 140));

        pnlAppointmentCard.setBackground(new java.awt.Color(238, 250, 247));
        pnlAppointmentCard.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(36, 59, 90));
        jLabel4.setText("5");

        jLabel5.setForeground(new java.awt.Color(100, 100, 100));
        jLabel5.setText("Appointments");

        javax.swing.GroupLayout pnlAppointmentCardLayout = new javax.swing.GroupLayout(pnlAppointmentCard);
        pnlAppointmentCard.setLayout(pnlAppointmentCardLayout);
        pnlAppointmentCardLayout.setHorizontalGroup(
            pnlAppointmentCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAppointmentCardLayout.createSequentialGroup()
                .addGroup(pnlAppointmentCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlAppointmentCardLayout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addComponent(jLabel5))
                    .addGroup(pnlAppointmentCardLayout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addComponent(jLabel4)))
                .addContainerGap(70, Short.MAX_VALUE))
        );
        pnlAppointmentCardLayout.setVerticalGroup(
            pnlAppointmentCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAppointmentCardLayout.createSequentialGroup()
                .addContainerGap(37, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addGap(35, 35, 35))
        );

        pnlDashboard.add(pnlAppointmentCard, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 210, 140));

        jPanel4.setBackground(new java.awt.Color(52, 89, 145));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.setForeground(new java.awt.Color(36, 59, 90));

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Today's Sales");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("  ₱2,450");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addContainerGap(70, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(44, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addGap(34, 34, 34))
        );

        pnlDashboard.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 130, 220, 140));

        pnlUpcoming.setBackground(java.awt.Color.white);
        pnlUpcoming.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        pnlDashboard.add(pnlUpcoming, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, -1, -1));

        jPanel1.setBackground(new java.awt.Color(248, 244, 253));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 205, 205)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(36, 59, 90));
        jLabel8.setText("Upcoming Appointments");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 10, -1, -1));

        jLabel10.setText("Today's scheduled grooming apppointments");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 40, -1, -1));

        jTable1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "PET", "OWNER", "DATE", "TIME", "SERVICE", "STATUS"
            }
        ));
        jTable1.setSelectionBackground(new java.awt.Color(248, 244, 253));
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 70, 950, 230));

        pnlDashboard.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 990, 350));

        getContentPane().add(pnlDashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 1030, 740));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCustomerandPetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCustomerandPetActionPerformed
        CustomerPetFrame customerpet = new CustomerPetFrame();
        customerpet.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnCustomerandPetActionPerformed

    private void btnGroomingCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGroomingCheckActionPerformed

        GroomingCheckFrame groomingCheck =
        new GroomingCheckFrame("");
        groomingCheck.setVisible(true);
        this.setVisible(false);        
    }//GEN-LAST:event_btnGroomingCheckActionPerformed

    private void btnDashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDashboardActionPerformed
        
    }//GEN-LAST:event_btnDashboardActionPerformed

    private void btnAppointmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAppointmentActionPerformed

        AppointmentFrame appointment = new AppointmentFrame();
        appointment.setVisible(true);
        this.setVisible(false);       
    }//GEN-LAST:event_btnAppointmentActionPerformed

    private void btnGroomingServiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGroomingServiceActionPerformed

        GroomingServiceFrame groomingservice = new GroomingServiceFrame();
        groomingservice.setVisible(true);
        this.setVisible(false);        
    }//GEN-LAST:event_btnGroomingServiceActionPerformed

    private void btnPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPaymentActionPerformed
                                       
    PaymentFrame payment = new PaymentFrame(0);
    payment.setVisible(true); 
    this.setVisible(false); 
    }//GEN-LAST:event_btnPaymentActionPerformed

    private void btnReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReportActionPerformed
     
        ReportFrame report = new ReportFrame();
        report.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnReportActionPerformed

    private void btnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOutActionPerformed
     
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnLogOutActionPerformed

    private void btnGroomersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGroomersActionPerformed

        GroomerFrame groomer = new GroomerFrame();
        groomer.setVisible(true);
        this.setVisible(false);         // TODO add your handling code here:
    }//GEN-LAST:event_btnGroomersActionPerformed

    private void btnPoliciesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPoliciesActionPerformed
PoliciesFrame policy = new PoliciesFrame();
        policy.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnPoliciesActionPerformed
private void loadTodaysAppointments() {

    String sql =
            "SELECT a.appointment_id, "
          + "p.pet_name, "
          + "CONCAT(c.first_name, ' ', c.last_name) AS owner, "
          + "a.appointment_date, "
          + "a.appointment_time, "
          + "GROUP_CONCAT("
          + "DISTINCT gs.service_name "
          + "ORDER BY gs.service_name "
          + "SEPARATOR ', '"
          + ") AS services, "
          + "a.status "
          + "FROM appointments a "
          + "JOIN pets p "
          + "ON a.pet_id = p.pet_id "
          + "JOIN customers c "
          + "ON p.customer_id = c.customer_id "
          + "LEFT JOIN appointment_services aps "
          + "ON a.appointment_id = aps.appointment_id "
          + "LEFT JOIN grooming_services gs "
          + "ON aps.service_id = gs.service_id "
          + "WHERE a.appointment_date = CURDATE() "
          + "AND a.status = 'Pending' "
          + "GROUP BY a.appointment_id, "
          + "p.pet_name, "
          + "c.first_name, "
          + "c.last_name, "
          + "a.appointment_date, "
          + "a.appointment_time, "
          + "a.status "
          + "ORDER BY a.appointment_time ASC";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        DefaultTableModel model =
                (DefaultTableModel) jTable1.getModel();

        model.setRowCount(0);

        while (rs.next()) {

            String services =
                    rs.getString("services");

            if (services == null ||
                services.trim().isEmpty()) {

                services = "No Service";
            }

            model.addRow(new Object[]{
                rs.getString("pet_name"),
                rs.getString("owner"),
                rs.getDate("appointment_date"),
                rs.getTime("appointment_time"),
                services,
                rs.getString("status")
            });
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading today's appointments: "
            + e.getMessage(),
            "Dashboard Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadCustomerCount() {

    String sql =
            "SELECT COUNT(DISTINCT c.customer_id) "
          + "FROM appointments a "
          + "JOIN pets p "
          + "ON a.pet_id = p.pet_id "
          + "JOIN customers c "
          + "ON p.customer_id = c.customer_id "
          + "WHERE a.appointment_date = CURDATE() "
          + "AND a.status = 'Completed'";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        if (rs.next()) {
            lblCustomerCount.setText(
                String.valueOf(rs.getInt(1))
            );
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading customer count: " + e.getMessage(),
            "Dashboard Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadAppointmentCount() {

    String sql =
            "SELECT COUNT(*) "
          + "FROM appointments "
          + "WHERE appointment_date = CURDATE() "
          + "AND status = 'Completed'";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        if (rs.next()) {
            jLabel4.setText(
                String.valueOf(rs.getInt(1))
            );
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading appointment count: " + e.getMessage(),
            "Dashboard Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadPetCount() {

    String sql =
            "SELECT COUNT(DISTINCT p.pet_id) "
          + "FROM appointments a "
          + "JOIN pets p "
          + "ON a.pet_id = p.pet_id "
          + "WHERE a.appointment_date = CURDATE() "
          + "AND a.status = 'Completed'";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        if (rs.next()) {
            jLabel2.setText(
                String.valueOf(rs.getInt(1))
            );
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading pet count: " + e.getMessage(),
            "Dashboard Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadTodaysSales() {

    String sql =
            "SELECT COALESCE(SUM(p.total_amount), 0) "
          + "FROM payments p "
          + "JOIN appointments a "
          + "ON p.appointment_id = a.appointment_id "
          + "WHERE p.payment_date = CURDATE() "
          + "AND p.payment_status = 'Paid' "
          + "AND a.status = 'Completed'";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        if (rs.next()) {

            double sales = rs.getDouble(1);

            jLabel7.setText(
                String.format("₱%,.2f", sales)
            );
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading today's sales: "
            + e.getMessage(),
            "Dashboard Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> new MainFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAppointment;
    private javax.swing.JButton btnCustomerandPet;
    private javax.swing.JButton btnDashboard;
    private javax.swing.JButton btnGroomers;
    private javax.swing.JButton btnGroomingCheck;
    private javax.swing.JButton btnGroomingService;
    private javax.swing.JButton btnLogOut;
    private javax.swing.JButton btnPayment;
    private javax.swing.JButton btnPolicies;
    private javax.swing.JButton btnReport;
    private javax.swing.JLabel btnWelcome;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblCustomerCardTitle;
    private javax.swing.JLabel lblCustomerCount;
    private javax.swing.JLabel lblDashboardSubtitle;
    private javax.swing.JLabel lblDashboardTitle;
    private javax.swing.JLabel lblHeaderTitle;
    private javax.swing.JLabel lblSideBarTitle;
    private javax.swing.JLabel lblSubHeader;
    private javax.swing.JPanel pnlAppointmentCard;
    private javax.swing.JPanel pnlCustomerCard;
    private javax.swing.JPanel pnlDashboard;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlSideBar;
    private javax.swing.JPanel pnlUpcoming;
    // End of variables declaration//GEN-END:variables
}
