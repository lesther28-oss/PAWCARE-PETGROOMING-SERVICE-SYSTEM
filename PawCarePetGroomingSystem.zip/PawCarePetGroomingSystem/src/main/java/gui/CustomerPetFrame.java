
package gui;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import service.CustomerPetService;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import database.DBConnection;

public class CustomerPetFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(CustomerPetFrame.class.getName());


    private final CustomerPetService customerPetService =
        new CustomerPetService();
    
    public CustomerPetFrame() {
    initComponents();

    lblOther.setVisible(false);
    txtOtherAnimal.setVisible(false);

    loadCustomerPetTable();

    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField5 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtCustomerId = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        txtContact = new javax.swing.JTextField();
        txtAddress = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtLastName = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txtPetId = new javax.swing.JTextField();
        txtPetName = new javax.swing.JTextField();
        txtBreed = new javax.swing.JTextField();
        txtCustomerId2 = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        cmbPetType = new javax.swing.JComboBox<>();
        cmbGender = new javax.swing.JComboBox<>();
        lblOther = new javax.swing.JLabel();
        txtOtherAnimal = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        txtAge = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        cmbSearchBy = new javax.swing.JComboBox<>();
        btnSearch2 = new javax.swing.JButton();
        lblSearch = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblCustomerPet = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        btnClear = new javax.swing.JButton();
        btnAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnArchieves = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        btnArchieve = new javax.swing.JButton();

        jTextField5.setText("jTextField5");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(232, 238, 244));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(241, 248, 254));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel1.setPreferredSize(new java.awt.Dimension(350, 260));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(36, 59, 90));
        jLabel6.setText("Customer Id");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 41, -1, -1));

        txtCustomerId.setEditable(false);
        txtCustomerId.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel1.add(txtCustomerId, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 490, 30));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(36, 59, 90));
        jLabel7.setText("First Name");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(36, 59, 90));
        jLabel8.setText("Contact Number");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(36, 59, 90));
        jLabel9.setText("Address");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, -1));

        txtName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel1.add(txtName, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 180, 26));

        txtContact.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel1.add(txtContact, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 490, 24));

        txtAddress.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel1.add(txtAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 490, 29));

        jPanel6.setBackground(new java.awt.Color(226, 241, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(36, 59, 90));
        jLabel4.setText("CUSTOMER / OWNER");
        jPanel6.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI Emoji", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(36, 59, 90));
        jLabel5.setText("👤");
        jPanel6.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, 35));

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 560, 40));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(36, 59, 90));
        jLabel3.setText("Last Name");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, -1, -1));

        txtLastName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel1.add(txtLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 110, 280, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, 560, 260));

        jPanel2.setBackground(new java.awt.Color(241, 248, 254));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.setForeground(new java.awt.Color(36, 59, 90));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(36, 59, 90));
        jLabel12.setText("Pet ID");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 42, -1, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(36, 59, 90));
        jLabel13.setText("Customer ID");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(261, 42, -1, -1));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(36, 59, 90));
        jLabel14.setText("Pet Name");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 98, -1, -1));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(36, 59, 90));
        jLabel15.setText("Pet Type");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, -1, -1));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(36, 59, 90));
        jLabel16.setText("Breed");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, -1, -1));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(36, 59, 90));
        jLabel17.setText("Gender");
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 150, -1, -1));

        txtPetId.setEditable(false);
        txtPetId.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.add(txtPetId, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 64, 211, 28));

        txtPetName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.add(txtPetName, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 120, 211, 20));

        txtBreed.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.add(txtBreed, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 300, 20));

        txtCustomerId2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.add(txtCustomerId2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 60, 260, 28));

        btnSearch.setBackground(new java.awt.Color(36, 59, 90));
        btnSearch.setFont(new java.awt.Font("Segoe UI Symbol", 1, 10)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setText("🔎︎");
        btnSearch.addActionListener(this::btnSearchActionPerformed);
        jPanel2.add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 60, 40, 30));

        cmbPetType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECT TYPE", "Dog", "Cat", "Rabbit", "Bird", "Other" }));
        cmbPetType.addActionListener(this::cmbPetTypeActionPerformed);
        jPanel2.add(cmbPetType, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 210, -1));

        cmbGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECT GENDER", "FEMALE", "MALE" }));
        jPanel2.add(cmbGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 170, 240, -1));

        lblOther.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblOther.setForeground(new java.awt.Color(36, 59, 90));
        lblOther.setText("Other Animal");
        jPanel2.add(lblOther, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 200, -1, -1));

        txtOtherAnimal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.add(txtOtherAnimal, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 220, 300, 20));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(36, 59, 90));
        jLabel23.setText("Age");
        jPanel2.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 100, -1, -1));
        jPanel2.add(txtAge, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 120, 310, -1));

        jPanel8.setBackground(new java.awt.Color(226, 241, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(36, 59, 90));
        jLabel10.setText("PET INFORMATION");

        jLabel11.setFont(new java.awt.Font("Segoe UI Symbol", 1, 16)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(36, 59, 90));
        jLabel11.setText("🐾");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addContainerGap(444, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addContainerGap())
        );

        jPanel2.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 610, 40));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 100, 610, 260));

        jPanel3.setBackground(new java.awt.Color(241, 248, 254));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(36, 59, 90));
        jLabel19.setText("SEARCH CUSTOMER / PET");
        jPanel3.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 34, -1, -1));

        jLabel20.setFont(new java.awt.Font("Segoe UI Symbol", 1, 16)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(36, 59, 90));
        jLabel20.setText("🔎︎");
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(7, 29, -1, -1));
        jPanel3.add(txtSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 57, 450, -1));

        cmbSearchBy.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose Search", "All", "Customer ID", "First Name", "Last Name", "Pet ID", "Pet Name" }));
        cmbSearchBy.addActionListener(this::cmbSearchByActionPerformed);
        jPanel3.add(cmbSearchBy, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 57, 253, -1));

        btnSearch2.setBackground(new java.awt.Color(36, 59, 90));
        btnSearch2.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        btnSearch2.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch2.setText("🔎︎ SEARCH");
        btnSearch2.addActionListener(this::btnSearch2ActionPerformed);
        jPanel3.add(btnSearch2, new org.netbeans.lib.awtextra.AbsoluteConstraints(472, 57, 112, -1));

        lblSearch.setForeground(new java.awt.Color(100, 100, 100));
        lblSearch.setText("Search by");
        jPanel3.add(lblSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 30, -1, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 380, 910, 100));

        jPanel4.setBackground(new java.awt.Color(241, 248, 254));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(36, 59, 90));
        jLabel22.setText("Customer and Pet List");

        tblCustomerPet.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Customer ID", "First Name", "Last Name", "Contact Number", "Address", "Pet ID", "Pet Name", "Pet Type", "Breed", "Age", "Sex"
            }
        ));
        tblCustomerPet.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblCustomerPetMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblCustomerPet);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel22)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 11, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 490, 1210, 210));

        jPanel5.setBackground(new java.awt.Color(241, 248, 254));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));

        btnClear.setBackground(new java.awt.Color(36, 59, 90));
        btnClear.setFont(new java.awt.Font("Segoe UI Emoji", 1, 12)); // NOI18N
        btnClear.setForeground(new java.awt.Color(255, 255, 255));
        btnClear.setText("↻ CLEAR");
        btnClear.addActionListener(this::btnClearActionPerformed);

        btnAdd.setBackground(new java.awt.Color(36, 59, 90));
        btnAdd.setFont(new java.awt.Font("Segoe UI Emoji", 1, 12)); // NOI18N
        btnAdd.setForeground(new java.awt.Color(255, 255, 255));
        btnAdd.setText("➕ ADD");
        btnAdd.addActionListener(this::btnAddActionPerformed);

        btnUpdate.setBackground(new java.awt.Color(36, 59, 90));
        btnUpdate.setFont(new java.awt.Font("Segoe UI Emoji", 1, 12)); // NOI18N
        btnUpdate.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdate.setText("✏ UPDATE");
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);

        btnArchieves.setText("ARCHIVE");
        btnArchieves.addActionListener(this::btnArchievesActionPerformed);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(btnArchieves, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnUpdate)
                    .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdd)
                    .addComponent(btnUpdate))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnClear)
                    .addComponent(btnArchieves))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 380, 280, 100));

        jPanel7.setBackground(new java.awt.Color(227, 240, 253));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(36, 59, 90));
        jLabel1.setText("Customer & Pet");
        jPanel7.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, 220, 30));

        jLabel18.setForeground(new java.awt.Color(36, 59, 90));
        jLabel18.setText("Manage customer and pet information");
        jPanel7.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, -1, -1));

        jButton1.setBackground(new java.awt.Color(36, 59, 90));
        jButton1.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("←");
        jButton1.addActionListener(this::jButton1ActionPerformed);
        jPanel7.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 60, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gui/petimage3.jpg"))); // NOI18N
        jPanel7.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, -10, -1, 94));

        btnArchieve.setBackground(new java.awt.Color(36, 59, 90));
        btnArchieve.setFont(new java.awt.Font("Segoe UI Emoji", 1, 12)); // NOI18N
        btnArchieve.setForeground(new java.awt.Color(255, 255, 255));
        btnArchieve.setText("📦 ARCHIEVE");
        btnArchieve.addActionListener(this::btnArchieveActionPerformed);
        jPanel7.add(btnArchieve, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 420, -1, -1));

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 80));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        MainFrame main = new MainFrame();
        main.setVisible(true);
        this.dispose(); 
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed


    String firstName = txtName.getText().trim();
    String lastName = txtLastName.getText().trim();
    String contact = txtContact.getText().trim();
    String address = txtAddress.getText().trim();

    String petName = txtPetName.getText().trim();
    String petType = cmbPetType.getSelectedItem().toString();
    String breed = txtBreed.getText().trim();
    String ageText = txtAge.getText().trim();
    String gender = cmbGender.getSelectedItem().toString();
    String otherAnimal = txtOtherAnimal.getText().trim();

    if (firstName.isEmpty() || lastName.isEmpty()
        || contact.isEmpty() || address.isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "Please complete the customer information.",
            "Missing Information",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (petName.isEmpty() || breed.isEmpty() || ageText.isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "Please complete the pet information.",
            "Missing Information",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (cmbPetType.getSelectedIndex() == 0) {

        JOptionPane.showMessageDialog(
            this,
            "Please select a pet type.",
            "Missing Information",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (petType.equals("Other")) {

        if (otherAnimal.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Please specify the animal type.",
                "Missing Information",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        petType = otherAnimal;
    }

    if (cmbGender.getSelectedIndex() == 0) {

        JOptionPane.showMessageDialog(
            this,
            "Please select a gender.",
            "Missing Information",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    int age;

    try {

        age = Integer.parseInt(ageText);

        if (age < 0) {
            throw new NumberFormatException();
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
            this,
            "Age must be a valid number.",
            "Invalid Age",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                this,
                "Could not connect to the database.",
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        String customerId = null;

        String findCustomerSql =
                "SELECT customer_id FROM customers "
                + "WHERE first_name = ? "
                + "AND last_name = ? "
                + "AND contact_number = ?";


        PreparedStatement findCustomerPst =
                con.prepareStatement(findCustomerSql);


        findCustomerPst.setString(1, firstName);
        findCustomerPst.setString(2, lastName);
        findCustomerPst.setString(3, contact);

        java.sql.ResultSet customerRs =
            findCustomerPst.executeQuery();


        if (customerRs.next()) {

            customerId =
                customerRs.getString("customer_id");


            String petCheckSql =
                "SELECT pet_id FROM pets "
                + "WHERE customer_id = ? AND pet_name = ?";

            PreparedStatement petCheckPst =
                con.prepareStatement(petCheckSql);

            petCheckPst.setString(1, customerId);
            petCheckPst.setString(2, petName);

            java.sql.ResultSet petRs =
                petCheckPst.executeQuery();


            if (petRs.next()) {

                JOptionPane.showMessageDialog(
                    this,
                    "This pet is already registered under this customer.\n"
                    + "Customer ID: " + customerId
                    + "\nPet Name: " + petName,
                    "Duplicate Record",
                    JOptionPane.WARNING_MESSAGE
                );

                con.close();
                return;
            }
        }

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to add this customer and pet?",
            "Confirm Add",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (confirm != JOptionPane.YES_OPTION) {

            con.close();
            return;
        }
        
        if (customerId == null) {

            customerId =
                customerPetService.generateCustomerId();

    String customerSql =
    "INSERT INTO customers "
    + "(customer_id, first_name, last_name, contact_number, address) "
    + "VALUES (?, ?, ?, ?, ?)";

            PreparedStatement customerPst =
                con.prepareStatement(customerSql);

            customerPst.setString(1, customerId);
            customerPst.setString(2, firstName);
            customerPst.setString(3, lastName);
            customerPst.setString(4, contact);
            customerPst.setString(5, address);
            customerPst.executeUpdate();
        }

        String petId =
            customerPetService.generatePetId();

        String petSql =
            "INSERT INTO pets "
            + "(pet_id, customer_id, pet_name, pet_type, breed, age, sex) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        PreparedStatement petPst =
            con.prepareStatement(petSql);

        petPst.setString(1, petId);
        petPst.setString(2, customerId);
        petPst.setString(3, petName);
        petPst.setString(4, petType);
        petPst.setString(5, breed);
        petPst.setInt(6, age);
        petPst.setString(7, gender);

        petPst.executeUpdate();

        txtCustomerId.setText(customerId);
        txtCustomerId2.setText(customerId);
        txtPetId.setText(petId);


        DefaultTableModel model =
            (DefaultTableModel) tblCustomerPet.getModel();

        model.addRow(new Object[]{
            customerId,
            firstName,
            lastName,
            contact,
            address,
            petId,
            petName,
            petType,
            breed,
            age,
            gender
        });


        con.close();


        JOptionPane.showMessageDialog(
            this,
            "Customer and pet added successfully!",
            "Success",
            JOptionPane.INFORMATION_MESSAGE
        );


    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Database Error: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnArchieveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchieveActionPerformed

    }//GEN-LAST:event_btnArchieveActionPerformed

    private void tblCustomerPetMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCustomerPetMouseClicked


    int row = tblCustomerPet.getSelectedRow();

    if (row == -1) {
        return;
    }

    txtCustomerId.setText(
        tblCustomerPet.getValueAt(row, 0).toString()
    );

    txtName.setText(
    tblCustomerPet.getValueAt(row, 1).toString()

    );


    txtLastName.setText(
    tblCustomerPet.getValueAt(row, 2).toString()

    );


    txtContact.setText(
    tblCustomerPet.getValueAt(row, 3).toString()

    );

    txtAddress.setText(
        tblCustomerPet.getValueAt(row, 4).toString()
    );

    txtPetId.setText(
    tblCustomerPet.getValueAt(row, 5).toString()

    );

    txtPetName.setText(
    tblCustomerPet.getValueAt(row, 6).toString()

    );

    cmbPetType.setSelectedItem(
    tblCustomerPet.getValueAt(row, 7).toString()

    );

    txtBreed.setText(
    tblCustomerPet.getValueAt(row, 8).toString()

    );

    txtAge.setText(
    tblCustomerPet.getValueAt(row, 9).toString()

    );

    cmbGender.setSelectedItem(
    tblCustomerPet.getValueAt(row, 10).toString()

    );
    txtCustomerId2.setText(
        tblCustomerPet.getValueAt(row, 0).toString()
    ); 
    }//GEN-LAST:event_tblCustomerPetMouseClicked

    private void cmbPetTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbPetTypeActionPerformed

    boolean isOther =
        cmbPetType.getSelectedItem() != null
        && cmbPetType.getSelectedItem().toString().equals("Other");

    lblOther.setVisible(isOther);
    txtOtherAnimal.setVisible(isOther);

    if (!isOther) {
        txtOtherAnimal.setText("");
    }   
    }//GEN-LAST:event_cmbPetTypeActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
                                        
    int row = tblCustomerPet.getSelectedRow();

    if (row == -1) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a record from the table first.",
            "No Selection",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to update this record?",
        "Confirm Update",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    String customerId = txtCustomerId.getText().trim();
    String firstName = txtName.getText().trim();
    String lastName = txtLastName.getText().trim();
    String contact = txtContact.getText().trim();
    String address = txtAddress.getText().trim();

    String petId = txtPetId.getText().trim();
    String petName = txtPetName.getText().trim();

    String petType = cmbPetType.getSelectedItem().toString();
    String breed = txtBreed.getText().trim();
    String ageText = txtAge.getText().trim();
    String gender = cmbGender.getSelectedItem().toString();
    String otherAnimal = txtOtherAnimal.getText().trim();


    if (firstName.isEmpty() || lastName.isEmpty()
            || contact.isEmpty() || address.isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "Please complete the customer information.",
            "Missing Information",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    if (petName.isEmpty() || breed.isEmpty() || ageText.isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "Please complete the pet information.",
            "Missing Information",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    if (cmbPetType.getSelectedIndex() == 0) {

        JOptionPane.showMessageDialog(
            this,
            "Please select a pet type.",
            "Missing Information",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    if (petType.equals("Other")) {

        if (otherAnimal.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Please specify the animal type.",
                "Missing Information",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        petType = otherAnimal;
    }

    if (cmbGender.getSelectedIndex() == 0) {

        JOptionPane.showMessageDialog(
            this,
            "Please select a gender.",
            "Missing Information",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    int age;

    try {

        age = Integer.parseInt(ageText);

        if (age < 0) {
            throw new NumberFormatException();
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
            this,
            "Age must be a valid number.",
            "Invalid Age",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }


    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                this,
                "Could not connect to the database.",
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }
        

        String customerSql =
            "UPDATE customers SET first_name = ?, last_name = ?, "
          + "contact_number = ?, address = ? "
          + "WHERE customer_id = ?";

        PreparedStatement customerPst =
            con.prepareStatement(customerSql);

        customerPst.setString(1, firstName);
        customerPst.setString(2, lastName);
        customerPst.setString(3, contact);
        customerPst.setString(4, address);
        customerPst.setString(5, customerId);

        customerPst.executeUpdate();


        String petSql =
            "UPDATE pets SET pet_name = ?, pet_type = ?, "
          + "breed = ?, age = ?, sex = ? "
          + "WHERE pet_id = ?";

        PreparedStatement petPst =
            con.prepareStatement(petSql);

        petPst.setString(1, petName);
        petPst.setString(2, petType);
        petPst.setString(3, breed);
        petPst.setInt(4, age);
        petPst.setString(5, gender);
        petPst.setString(6, petId);

        petPst.executeUpdate();
  

        javax.swing.table.DefaultTableModel model =
            (javax.swing.table.DefaultTableModel)
            tblCustomerPet.getModel();

        model.setValueAt(customerId, row, 0);
        model.setValueAt(firstName, row, 1);
        model.setValueAt(lastName, row, 2);
        model.setValueAt(contact, row, 3);
        model.setValueAt(address, row, 4);
        model.setValueAt(petId, row, 5);
        model.setValueAt(petName, row, 6);
        model.setValueAt(petType, row, 7);
        model.setValueAt(breed, row, 8);
        model.setValueAt(age, row, 9);
        model.setValueAt(gender, row, 10);


        JOptionPane.showMessageDialog(
            this,
            "Customer and pet updated successfully!",
            "Success",
            JOptionPane.INFORMATION_MESSAGE
        );

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Database Error: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
                            
    txtCustomerId.setText(""); 
    txtName.setText(""); 
    txtLastName.setText("");
    txtContact.setText(""); 
    txtAddress.setText("");

    txtPetId.setText("");
    txtCustomerId2.setText("");
    txtPetName.setText("");
    txtBreed.setText("");
    txtAge.setText("");
    txtOtherAnimal.setText("");

    cmbPetType.setSelectedIndex(0);
    cmbGender.setSelectedIndex(0);

    txtSearch.setText("");
    cmbSearchBy.setSelectedIndex(0);


    txtName.requestFocus();
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnSearch2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearch2ActionPerformed

String keyword = txtSearch.getText()
        .trim()
        .toLowerCase(java.util.Locale.ROOT)
        .replaceAll("\\s+", " ");

String searchBy = cmbSearchBy.getSelectedItem() == null
        ? "Choose Search"
        : cmbSearchBy.getSelectedItem().toString();

if (keyword.isEmpty()) {
    JOptionPane.showMessageDialog(
        this,
        "Please enter something to search.",
        "Search",
        JOptionPane.WARNING_MESSAGE
    );
    return;
}

if (searchBy.equals("Choose Search")) {
    JOptionPane.showMessageDialog(
        this,
        "Please select what you want to search by.",
        "Search",
        JOptionPane.WARNING_MESSAGE
    );
    return;
}

loadCustomerPetTable();

DefaultTableModel model =
        (DefaultTableModel) tblCustomerPet.getModel();

int matches = 0;

for (int i = model.getRowCount() - 1; i >= 0; i--) {

    boolean match = false;

    if (searchBy.equals("All")) {

        StringBuilder searchableText = new StringBuilder();

        for (int col = 0; col < model.getColumnCount(); col++) {

            Object cell = model.getValueAt(i, col);

            String value = cell == null ? "" : cell.toString();

            searchableText.append(value).append(" ");
        }

        String rowText = searchableText.toString()
                .toLowerCase(java.util.Locale.ROOT)
                .trim()
                .replaceAll("\\s+", " ");

        match = rowText.contains(keyword);

    } else {

        int column = -1;

        switch (searchBy) {
            case "Customer ID":
                column = 0;
                break;

            case "First Name":
                column = 1;
                break;

            case "Last Name":
                column = 2;
                break;

            case "Pet ID":
                column = 5;
                break;

            case "Pet Name":
                column = 6;
                break;
        }

        if (column >= 0) {

            Object cell = model.getValueAt(i, column);

            String value = cell == null
                    ? ""
                    : cell.toString().toLowerCase(
                            java.util.Locale.ROOT
                    );

            match = value.contains(keyword);
        }
    }

    if (match) {
        matches++;
    } else {
        model.removeRow(i);
    }
}

tblCustomerPet.clearSelection();

if (matches == 0) {

    JOptionPane.showMessageDialog(
        this,
        "No matching records found.",
        "Search",
        JOptionPane.INFORMATION_MESSAGE
    );

} else {

    JOptionPane.showMessageDialog(
        this,
        matches + " matching record(s) found.",
        "Search Results",
        JOptionPane.INFORMATION_MESSAGE
    );
}
    }//GEN-LAST:event_btnSearch2ActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed

    String keyword = txtCustomerId2.getText().trim();

    if (keyword.isEmpty()) {
        JOptionPane.showMessageDialog(
            this,
            "Please type the customer's last name in the box beside the search button.",
            "Search Customer",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    String sql =
            "SELECT customer_id, first_name, last_name, "
          + "contact_number, address "
          + "FROM customers "
          + "WHERE status = 'Active' "
          + "AND (last_name LIKE ? OR customer_id = ?) "
          + "ORDER BY last_name, first_name";

    try (Connection con = DBConnection.getConnection()) {

        if (con == null) {
            JOptionPane.showMessageDialog(
                this,
                "Could not connect to the database.",
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        java.util.ArrayList<String> customerIds = new java.util.ArrayList<>();
        java.util.ArrayList<String> firstNames = new java.util.ArrayList<>();
        java.util.ArrayList<String> lastNames = new java.util.ArrayList<>();
        java.util.ArrayList<String> contacts = new java.util.ArrayList<>();
        java.util.ArrayList<String> addresses = new java.util.ArrayList<>();

        try (PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, "%" + keyword + "%");
            pst.setString(2, keyword);

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                customerIds.add(rs.getString("customer_id"));
                firstNames.add(rs.getString("first_name"));
                lastNames.add(rs.getString("last_name"));
                contacts.add(rs.getString("contact_number"));
                addresses.add(rs.getString("address"));
            }
        }

        if (customerIds.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Customer not found.",
                "Search Customer",
                JOptionPane.INFORMATION_MESSAGE
            );
            return;
        }

        Object[] choices = new Object[customerIds.size()];

        for (int i = 0; i < customerIds.size(); i++) {
            choices[i] = customerIds.get(i)
                    + " - " + firstNames.get(i) + " " + lastNames.get(i)
                    + " | " + contacts.get(i)
                    + " | " + addresses.get(i);
        }

        Object selected = JOptionPane.showInputDialog(
            this,
            "Select the customer:",
            "Select Customer",
            JOptionPane.QUESTION_MESSAGE,
            null,
            choices,
            choices[0]
        );

        if (selected == null) {
            return;
        }

        int index = 0;

        for (int i = 0; i < choices.length; i++) {
            if (choices[i].equals(selected)) {
                index = i;
                break;
            }
        }

        String customerId = customerIds.get(index);

        txtCustomerId.setText(customerId);
        txtName.setText(firstNames.get(index));
        txtLastName.setText(lastNames.get(index));
        txtContact.setText(contacts.get(index));
        txtAddress.setText(addresses.get(index));
        txtCustomerId2.setText(customerId);

        txtPetId.setText("");
        txtPetName.setText("");
        txtBreed.setText("");
        txtAge.setText("");
        txtOtherAnimal.setText("");
        cmbPetType.setSelectedIndex(0);
        cmbGender.setSelectedIndex(0);

        String petNames = "";

        String petSql = "SELECT pet_name FROM pets "
                      + "WHERE customer_id = ? ORDER BY pet_name";

        try (PreparedStatement petPst = con.prepareStatement(petSql)) {

            petPst.setString(1, customerId);

            ResultSet petRs = petPst.executeQuery();

            while (petRs.next()) {
                if (!petNames.isEmpty()) {
                    petNames = petNames + ", ";
                }
                petNames = petNames + petRs.getString("pet_name");
            }
        
        }
        if (petNames.isEmpty()) {
            
        }
                if (petNames.isEmpty()) {
            petNames = "None";
        }

        JOptionPane.showMessageDialog(
            this,
            "Customer selected: " + firstNames.get(index)
            + " " + lastNames.get(index)
            + "\nExisting pets: " + petNames
            + "\n\nType the new pet's information, then click ADD.",
            "Customer Found",
            JOptionPane.INFORMATION_MESSAGE
        );

        txtPetName.requestFocus();

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error searching customer: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void cmbSearchByActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbSearchByActionPerformed
 
    }//GEN-LAST:event_cmbSearchByActionPerformed

    private void btnArchievesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchievesActionPerformed

    int row = tblCustomerPet.getSelectedRow();

    if (row == -1) {
        javax.swing.JOptionPane.showMessageDialog(
            this,
            "Please select a customer and pet record first.",
            "No Selection",
            javax.swing.JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    String customerId = tblCustomerPet.getValueAt(row, 0).toString();

    int confirm = javax.swing.JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to archive this customer and pet?",
        "Confirm Archive",
        javax.swing.JOptionPane.YES_NO_OPTION,
        javax.swing.JOptionPane.QUESTION_MESSAGE
    );

    if (confirm != javax.swing.JOptionPane.YES_OPTION) {
        return;
    }

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {
            javax.swing.JOptionPane.showMessageDialog(
                this,
                "Could not connect to the database.",
                "Database Error",
                javax.swing.JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        String sql =
            "UPDATE customers SET status = 'Archived' "
            + "WHERE customer_id = ?";

        PreparedStatement pst = con.prepareStatement(sql);
        pst.setString(1, customerId);

        int rowsUpdated = pst.executeUpdate();

        if (rowsUpdated > 0) {

            javax.swing.JOptionPane.showMessageDialog(
                this,
                "Customer and pet archived successfully.",
                "Archive",
                javax.swing.JOptionPane.INFORMATION_MESSAGE
            );

            javax.swing.table.DefaultTableModel model =
                (javax.swing.table.DefaultTableModel)
                tblCustomerPet.getModel();

            model.removeRow(row);

            txtCustomerId.setText("");

            txtName.setText("");
            txtLastName.setText("");
            txtContact.setText("");
            txtAddress.setText("");

            txtPetId.setText("");
            txtCustomerId2.setText("");
            txtPetName.setText("");
            txtBreed.setText("");
            txtAge.setText("");
            txtOtherAnimal.setText("");

            cmbPetType.setSelectedIndex(0);
            cmbGender.setSelectedIndex(0);

        } else {

            javax.swing.JOptionPane.showMessageDialog(
                this,
                "The selected customer could not be archived.",
                "Archive Failed",
                javax.swing.JOptionPane.ERROR_MESSAGE
            );
        }

        con.close();

    } catch (Exception e) {

        javax.swing.JOptionPane.showMessageDialog(
            this,
            "Database Error: " + e.getMessage(),
            "Error",
            javax.swing.JOptionPane.ERROR_MESSAGE
        );
    }                
    }//GEN-LAST:event_btnArchievesActionPerformed
private void loadCustomerPetTable() {

    DefaultTableModel model =
            (DefaultTableModel) tblCustomerPet.getModel();

    model.setRowCount(0);

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Could not connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        String sql =
                "SELECT "
                + "c.customer_id, "
                + "c.first_name, "
                + "c.last_name, "
                + "c.contact_number, "
                + "c.address, "
                + "p.pet_id, "
                + "p.pet_name, "
                + "p.pet_type, "
                + "p.breed, "
                + "p.age, "
                + "p.sex "
                + "FROM customers c "
                + "JOIN pets p "
                + "ON c.customer_id = p.customer_id "
                + "WHERE c.status = 'Active' "
                + "ORDER BY c.customer_id";

        PreparedStatement pst =
                con.prepareStatement(sql);

        java.sql.ResultSet rs =
                pst.executeQuery();

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getString("customer_id"),
                rs.getString("first_name"),
                rs.getString("last_name"),
                rs.getString("contact_number"),
                rs.getString("address"),
                rs.getString("pet_id"),
                rs.getString("pet_name"),
                rs.getString("pet_type"),
                rs.getString("breed"),
                rs.getInt("age"),
                rs.getString("sex")
            });
        }

        rs.close();
        pst.close();
        con.close();

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error loading customer and pet records:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(() -> new CustomerPetFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnArchieve;
    private javax.swing.JButton btnArchieves;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnSearch2;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cmbGender;
    private javax.swing.JComboBox<String> cmbPetType;
    private javax.swing.JComboBox<String> cmbSearchBy;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JLabel lblOther;
    private javax.swing.JLabel lblSearch;
    private javax.swing.JTable tblCustomerPet;
    private javax.swing.JTextField txtAddress;
    private javax.swing.JTextField txtAge;
    private javax.swing.JTextField txtBreed;
    private javax.swing.JTextField txtContact;
    private javax.swing.JTextField txtCustomerId;
    private javax.swing.JTextField txtCustomerId2;
    private javax.swing.JTextField txtLastName;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtOtherAnimal;
    private javax.swing.JTextField txtPetId;
    private javax.swing.JTextField txtPetName;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
