
package gui;
import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class GroomerFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GroomerFrame.class.getName());

   public GroomerFrame() {
    initComponents();

    txtGroomerId.setEditable(false);

    loadStatusToCombo();
    generateGroomerId();
    loadGroomers();
    setupGroomerTableColors();

    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
}
private void loadStatusToCombo() {

    cmbStatus.setModel(
        new javax.swing.DefaultComboBoxModel<>(
            new String[] {
                "Choose Status",
                "Active",
                "Inactive",
                "Archived"
            }
        )
    );
}
private void generateGroomerId() {

    int nextId = 1;

    try {

        Connection con = DBConnection.getConnection();

        String sql =
                "SELECT MAX(CAST(SUBSTRING(groomer_id, 2) AS UNSIGNED)) "
              + "FROM groomers";

        PreparedStatement pst =
                con.prepareStatement(sql);

        ResultSet rs =
                pst.executeQuery();

        if (rs.next()) {
            nextId = rs.getInt(1) + 1;
        }

        rs.close();
        pst.close();
        con.close();

    } catch (Exception e) {

        e.printStackTrace();
    }

    txtGroomerId.setText(
            String.format("G%03d", nextId)
    );
}
private void loadGroomers() {

    DefaultTableModel model =
            (DefaultTableModel) tblGroomers.getModel();

    model.setRowCount(0);

    try {

        Connection con =
                DBConnection.getConnection();

        String sql =
                "SELECT groomer_id, first_name, last_name, "
              + "contact_number, specialization, status "
              + "FROM groomers "
              + "ORDER BY groomer_id";

        PreparedStatement pst =
                con.prepareStatement(sql);

        ResultSet rs =
                pst.executeQuery();

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getString("groomer_id"),
                rs.getString("first_name"),
                rs.getString("last_name"),
                rs.getString("contact_number"),
                rs.getString("specialization"),
                rs.getString("status")
            });
        }

        rs.close();
        pst.close();
        con.close();

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error loading groomers:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
private boolean isGroomerBusy(
        String groomerId,
        String date,
        String time) {

    String sql =
            "SELECT COUNT(*) "
          + "FROM appointments a "
          + "JOIN grooming_services gs "
          + "ON a.service_id = gs.service_id "
          + "WHERE a.groomer_id = ? "
          + "AND a.appointment_date = ? "
          + "AND a.status NOT IN ('Cancelled', 'Completed') "
          + "AND ? < ADDTIME(a.appointment_time, "
          + "SEC_TO_TIME(gs.duration_minutes * 60)) "
          + "AND ADDTIME(?, SEC_TO_TIME(gs.duration_minutes * 60)) "
          + "> a.appointment_time";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, groomerId);
        pst.setDate(2, java.sql.Date.valueOf(date));
        pst.setTime(3, java.sql.Time.valueOf(time));
        pst.setTime(4, java.sql.Time.valueOf(time));

        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            return rs.getInt(1) > 0;
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return false;
}
private void setupGroomerTableColors() {

    javax.swing.table.DefaultTableCellRenderer renderer =
            new javax.swing.table.DefaultTableCellRenderer() {

        @Override
        public java.awt.Component getTableCellRendererComponent(
                javax.swing.JTable table,
                Object value,
                boolean isSelected,
                boolean hasFocus,
                int row,
                int column) {

            java.awt.Component c =
                    super.getTableCellRendererComponent(
                            table,
                            value,
                            isSelected,
                            hasFocus,
                            row,
                            column
                    );

            Object status =
                    table.getValueAt(row, 5);

            if (!isSelected) {

                if (status != null) {

                    String statusText =
                            status.toString();

                    if (statusText.equalsIgnoreCase("Active")) {

                        c.setForeground(new java.awt.Color(34, 139, 34));

                    } else if (statusText.equalsIgnoreCase("Inactive")) {

                        c.setForeground(new java.awt.Color(230, 160, 0));

                    } else if (statusText.equalsIgnoreCase("Archived")) {

                        c.setForeground(new java.awt.Color(150, 150, 150));

                    } else {

                        c.setForeground(
                                new java.awt.Color(36, 59, 90)
                        );
                    }

                }
            }

            return c;
        }
    };

    tblGroomers.setDefaultRenderer(
            Object.class,
            renderer
    );
}
private void clearFields() {

    txtFirstName.setText("");
    txtLastName.setText("");
    txtContact.setText("");
    txtSpecialization.setText("");

    cmbStatus.setSelectedIndex(0);
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        txtGroomerId = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtLastName = new javax.swing.JTextField();
        txtFirstName = new javax.swing.JTextField();
        txtContact = new javax.swing.JTextField();
        btnUpdate = new javax.swing.JButton();
        cmbStatus = new javax.swing.JComboBox<>();
        btnAdd = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txtSpecialization = new javax.swing.JTextField();
        btnArchieve = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        txtSearch = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblGroomers = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(245, 249, 253));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(226, 241, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(36, 59, 90));
        jLabel7.setText("GROOMER MANAGEMENT");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 20, -1, -1));

        jLabel9.setForeground(new java.awt.Color(36, 59, 90));
        jLabel9.setText("Manage your pet grooming staff");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 50, 256, -1));

        jButton1.setBackground(new java.awt.Color(36, 59, 90));
        jButton1.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        jButton1.setForeground(java.awt.Color.white);
        jButton1.setText("←");
        jButton1.addActionListener(this::jButton1ActionPerformed);
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gui/petimage3.jpg"))); // NOI18N
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 0, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1310, 80));

        jPanel2.setBackground(new java.awt.Color(255, 250, 240));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 218, 130)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtGroomerId.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.add(txtGroomerId, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 230, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(36, 59, 90));
        jLabel3.setText("Last Name:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 60, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(36, 59, 90));
        jLabel2.setText("First Name:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 50, -1, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(36, 59, 90));
        jLabel1.setText("Groomer ID:");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        txtLastName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.add(txtLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 80, 390, 30));

        txtFirstName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.add(txtFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 80, 250, 30));

        txtContact.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.add(txtContact, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 230, 30));

        btnUpdate.setBackground(new java.awt.Color(55, 105, 160));
        btnUpdate.setForeground(java.awt.Color.white);
        btnUpdate.setText("Update");
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);
        jPanel2.add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 210, 180, 30));

        cmbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose Status", " " }));
        cmbStatus.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        cmbStatus.addActionListener(this::cmbStatusActionPerformed);
        jPanel2.add(cmbStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 160, 390, 30));

        btnAdd.setBackground(new java.awt.Color(36, 59, 90));
        btnAdd.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAdd.setForeground(java.awt.Color.white);
        btnAdd.setText("Add");
        btnAdd.addActionListener(this::btnAddActionPerformed);
        jPanel2.add(btnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, 200, 30));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(36, 59, 90));
        jLabel6.setText("Status:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 130, -1, -1));

        txtSpecialization.setActionCommand("<Not Set>");
        txtSpecialization.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.add(txtSpecialization, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 160, 250, 30));

        btnArchieve.setBackground(new java.awt.Color(36, 59, 90));
        btnArchieve.setForeground(java.awt.Color.white);
        btnArchieve.setText("Archive");
        btnArchieve.addActionListener(this::btnArchieveActionPerformed);
        jPanel2.add(btnArchieve, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 210, 160, 30));

        btnClear.setBackground(new java.awt.Color(190, 200, 210));
        btnClear.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnClear.setForeground(java.awt.Color.white);
        btnClear.setText("Clear");
        btnClear.addActionListener(this::btnClearActionPerformed);
        jPanel2.add(btnClear, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 210, 220, 30));

        jPanel4.setBackground(new java.awt.Color(255, 243, 214));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 218, 130)));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(36, 59, 90));
        jLabel8.setText("Groomer Information");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(1127, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1300, 40));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(36, 59, 90));
        jLabel5.setText("Specialization:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 130, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(36, 59, 90));
        jLabel4.setText("Contact Number:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 1260, 250));

        jPanel3.setBackground(new java.awt.Color(255, 244, 244));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 205, 205)));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(255, 226, 226));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 205, 205)));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtSearch.addActionListener(this::txtSearchActionPerformed);
        jPanel5.add(txtSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 10, 240, 30));

        btnSearch.setText("SEARCH");
        btnSearch.addActionListener(this::btnSearchActionPerformed);
        jPanel5.add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 10, 110, 30));

        jPanel3.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1260, 54));

        tblGroomers.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Groomer Id", "First Name", "Last Name", "Contact Number", "Specialization", "Status", "Availability"
            }
        ));
        tblGroomers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblGroomersMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblGroomers);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 1250, 278));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, 1260, 360));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed

    String groomerId =
            txtGroomerId.getText().trim();

    String firstName =
            txtFirstName.getText().trim();

    String lastName =
            txtLastName.getText().trim();

    String contact =
            txtContact.getText().trim();

    String specialization =
            txtSpecialization.getText().trim();

    String status =
            cmbStatus.getSelectedItem().toString();


    if (firstName.isEmpty()
            || lastName.isEmpty()
            || contact.isEmpty()
            || specialization.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "Please complete all groomer information.",
                "Missing Information",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (cmbStatus.getSelectedIndex() == 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a status.",
                "Missing Status",
                JOptionPane.WARNING_MESSAGE
        );

        cmbStatus.requestFocus();

        return;
    }


    try {

        Connection con =
                DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        String sql =
                "INSERT INTO groomers "
              + "(groomer_id, first_name, last_name, "
              + "contact_number, specialization, status) "
              + "VALUES (?, ?, ?, ?, ?, ?)";

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setString(1, groomerId);
        pst.setString(2, firstName);
        pst.setString(3, lastName);
        pst.setString(4, contact);
        pst.setString(5, specialization);
        pst.setString(6, status);

        pst.executeUpdate();

        pst.close();
        con.close();

        JOptionPane.showMessageDialog(
                this,
                "Groomer added successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE
        );

        loadGroomers();
        clearFields();
        generateGroomerId();

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error adding groomer:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed

    clearFields();
    generateGroomerId();
    }//GEN-LAST:event_btnClearActionPerformed

    private void tblGroomersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblGroomersMouseClicked

        int selectedRow = tblGroomers.getSelectedRow();
        if (selectedRow >= 0) {

    txtGroomerId.setText(
            tblGroomers.getValueAt(selectedRow, 0).toString()
    );

    txtFirstName.setText(
            tblGroomers.getValueAt(selectedRow, 1).toString()
    );

    txtLastName.setText(
            tblGroomers.getValueAt(selectedRow, 2).toString()
    );

    txtContact.setText(
            tblGroomers.getValueAt(selectedRow, 3).toString()
    );

    txtSpecialization.setText(
            tblGroomers.getValueAt(selectedRow, 4).toString()
    );

    cmbStatus.setSelectedItem(
            tblGroomers.getValueAt(selectedRow, 5).toString()
    );
}
    }//GEN-LAST:event_tblGroomersMouseClicked

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed


    String groomerId =
            txtGroomerId.getText().trim();

    String firstName =
            txtFirstName.getText().trim();

    String lastName =
            txtLastName.getText().trim();

    String contact =
            txtContact.getText().trim();

    String specialization =
            txtSpecialization.getText().trim();

    String status =
            cmbStatus.getSelectedItem().toString();

    if (groomerId.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a groomer first.",
                "No Groomer Selected",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (firstName.isEmpty()
            || lastName.isEmpty()
            || contact.isEmpty()
            || specialization.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "Please complete all groomer information.",
                "Missing Information",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (cmbStatus.getSelectedIndex() == 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a status.",
                "Missing Status",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    try {

        Connection con =
                DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        String sql =
                "UPDATE groomers SET "
              + "first_name = ?, "
              + "last_name = ?, "
              + "contact_number = ?, "
              + "specialization = ?, "
              + "status = ? "
              + "WHERE groomer_id = ?";

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setString(1, firstName);
        pst.setString(2, lastName);
        pst.setString(3, contact);
        pst.setString(4, specialization);
        pst.setString(5, status);
        pst.setString(6, groomerId);

        pst.executeUpdate();

        pst.close();
        con.close();

        JOptionPane.showMessageDialog(
                this,
                "Groomer updated successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE
        );

        loadGroomers();
        clearFields();
        generateGroomerId();

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error updating groomer:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnArchieveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchieveActionPerformed

    String groomerId =
            txtGroomerId.getText().trim();

    if (groomerId.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a groomer first.",
                "No Groomer Selected",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to archive this groomer?",
            "Confirm Archive",
            JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    try {

        Connection con =
                DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        String sql =
                "UPDATE groomers "
              + "SET status = 'Archived' "
              + "WHERE groomer_id = ?";

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setString(1, groomerId);

        pst.executeUpdate();

        pst.close();
        con.close();

        JOptionPane.showMessageDialog(
                this,
                "Groomer archived successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE
        );

        loadGroomers();
        clearFields();
        generateGroomerId();

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error archiving groomer:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnArchieveActionPerformed

    private void cmbStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbStatusActionPerformed

    }//GEN-LAST:event_cmbStatusActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed

    String keyword = txtSearch.getText().trim();

    if (keyword.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "Please enter a groomer ID, first name, last name, or contact number.",
                "Search",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    DefaultTableModel model =
            (DefaultTableModel) tblGroomers.getModel();

    model.setRowCount(0);

    try {

        Connection con =
                DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        String sql =
                "SELECT groomer_id, "
                + "first_name, "
                + "last_name, "
                + "contact_number, "
                + "specialization, "
                + "status "
                + "FROM groomers "
                + "WHERE groomer_id LIKE ? "
                + "OR first_name LIKE ? "
                + "OR last_name LIKE ? "
                + "OR contact_number LIKE ? "
                + "OR specialization LIKE ? "
                + "ORDER BY groomer_id";

        PreparedStatement pst =
                con.prepareStatement(sql);

        String search =
                "%" + keyword + "%";

        pst.setString(1, search);
        pst.setString(2, search);
        pst.setString(3, search);
        pst.setString(4, search);
        pst.setString(5, search);

        ResultSet rs =
                pst.executeQuery();

        boolean found = false;

        while (rs.next()) {

            found = true;

            model.addRow(new Object[]{
                rs.getString("groomer_id"),
                rs.getString("first_name"),
                rs.getString("last_name"),
                rs.getString("contact_number"),
                rs.getString("specialization"),
                rs.getString("status")
            });
        }

        rs.close();
        pst.close();
        con.close();

        if (!found) {

            JOptionPane.showMessageDialog(
                    this,
                    "No groomer found.",
                    "Search",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error searching groomers:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed

    }//GEN-LAST:event_txtSearchActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        MainFrame main = new MainFrame();
        main.setVisible(true);
        this.dispose(); 
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new GroomerFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnArchieve;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cmbStatus;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblGroomers;
    private javax.swing.JTextField txtContact;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtGroomerId;
    private javax.swing.JTextField txtLastName;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtSpecialization;
    // End of variables declaration//GEN-END:variables
}
