
package gui;
import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import java.sql.Date;
import java.util.Calendar;
import java.sql.SQLException;
public class ReportFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ReportFrame.class.getName());
    private JSpinner datePickerFrom;
private JSpinner datePickerTo;
    


public ReportFrame() {
    initComponents();

    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);

    lblCustomerId.setText("-");
    lblFullName.setText("-");
    lblContact.setText("-");
    lblAddress.setText("-");

    cmbReportType.setModel(
    new javax.swing.DefaultComboBoxModel<>(
        new String[]{
            "Choose",
            "Recent Records",
            "Today",
            "Yesterday",
            "This Week",
            "This Month",
            "Last Month",
            "Custom Date"
        }
    )
);

cmbReportType.setSelectedIndex(0);
cmbReportType.addActionListener(e -> updateDatePickers());

    datePickerFrom = new JSpinner(new SpinnerDateModel());
    datePickerFrom.setEditor(
        new JSpinner.DateEditor(datePickerFrom, "yyyy-MM-dd")
    );
    datePickerFrom.setValue(new java.util.Date());

    datePickerTo = new JSpinner(new SpinnerDateModel());
    datePickerTo.setEditor(
        new JSpinner.DateEditor(datePickerTo, "yyyy-MM-dd")
    );
    datePickerTo.setValue(new java.util.Date());

    txtDate.setVisible(false);
    dateChooserTo.setVisible(false);

    jPanel2.add(
        datePickerFrom,
        new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 40, 200, 30)
    );

    jPanel2.add(
        datePickerTo,
        new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 90, 200, 30)
    );

    jPanel2.revalidate();
    jPanel2.repaint();
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        pnlCustomerInfo = new javax.swing.JPanel();
        lblCustomerIdTitle = new javax.swing.JLabel();
        lblCustomerId = new javax.swing.JLabel();
        lblFullNameTitle = new javax.swing.JLabel();
        lblFullName = new javax.swing.JLabel();
        lblContactTitle = new javax.swing.JLabel();
        lblContact = new javax.swing.JLabel();
        lblAddressTitle = new javax.swing.JLabel();
        lblAddress = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        lblCustomerInfoTitle = new javax.swing.JLabel();
        pnlPetInfo = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        lblPetInfoTitle = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPets = new javax.swing.JTable();
        lblCustomerInfoTitle1 = new javax.swing.JLabel();
        HistoryPanel = new javax.swing.JTabbedPane();
        groomingHistoryPanel = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblGroomingHistory = new javax.swing.JTable();
        paymentHistoryPanel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblPaymentHistory = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tblAppointmentHistory = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblSearch = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        lblReportPeriod = new javax.swing.JLabel();
        cmbReportType = new javax.swing.JComboBox<>();
        btnGenerate = new javax.swing.JButton();
        lblFrom = new javax.swing.JLabel();
        lblTo = new javax.swing.JLabel();
        txtDate = new javax.swing.JTextField();
        dateChooserTo = new javax.swing.JTextField();
        appointmentHistoryPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(241, 248, 254));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(227, 240, 253));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(36, 59, 90));
        jLabel2.setText("REPORTS");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, -1, -1));

        jLabel3.setForeground(new java.awt.Color(36, 59, 90));
        jLabel3.setText("Customer Records and System Reports");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gui/petimage3.jpg"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 0, 280, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gui/petimage4.jpg"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 80, 60));

        jButton1.setBackground(new java.awt.Color(36, 59, 90));
        jButton1.setFont(new java.awt.Font("Segoe UI Symbol", 0, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("←");
        jButton1.addActionListener(this::jButton1ActionPerformed);
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 30, 20));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1270, 80));

        pnlCustomerInfo.setBackground(new java.awt.Color(248, 252, 255));
        pnlCustomerInfo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        pnlCustomerInfo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblCustomerIdTitle.setText("Customer ID:");
        pnlCustomerInfo.add(lblCustomerIdTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        lblCustomerId.setText("-");
        pnlCustomerInfo.add(lblCustomerId, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 40, -1, -1));

        lblFullNameTitle.setText("Full Name:");
        pnlCustomerInfo.add(lblFullNameTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        lblFullName.setText("-");
        pnlCustomerInfo.add(lblFullName, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 70, -1, -1));

        lblContactTitle.setText("Contact Number:");
        pnlCustomerInfo.add(lblContactTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        lblContact.setText("-");
        pnlCustomerInfo.add(lblContact, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 100, -1, -1));

        lblAddressTitle.setText("Address:");
        pnlCustomerInfo.add(lblAddressTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));

        lblAddress.setText("-");
        pnlCustomerInfo.add(lblAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 130, -1, -1));

        jPanel4.setBackground(new java.awt.Color(220, 238, 252));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));

        lblCustomerInfoTitle.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCustomerInfoTitle.setText("Customer Information");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCustomerInfoTitle)
                .addContainerGap(266, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCustomerInfoTitle, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        pnlCustomerInfo.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, -1));

        getContentPane().add(pnlCustomerInfo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 420, 160));

        pnlPetInfo.setBackground(new java.awt.Color(248, 252, 255));
        pnlPetInfo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        pnlPetInfo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(220, 238, 252));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));

        lblPetInfoTitle.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblPetInfoTitle.setText("Pet Information");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblPetInfoTitle)
                .addContainerGap(707, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblPetInfoTitle, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        pnlPetInfo.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, -1));

        tblPets.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Pet ID", "Pet Name", "Type", "Breed", "Age", "Sex"
            }
        ));
        jScrollPane1.setViewportView(tblPets);

        pnlPetInfo.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 770, 100));

        getContentPane().add(pnlPetInfo, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 230, 820, 160));

        lblCustomerInfoTitle1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCustomerInfoTitle1.setText("Customer Information");
        getContentPane().add(lblCustomerInfoTitle1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        groomingHistoryPanel.setBackground(new java.awt.Color(242, 250, 247));
        groomingHistoryPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));

        tblGroomingHistory.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Record ID", "Appointment ID", "Pet", "Grooming Date", "Allergy", "Behavior", "Notes"
            }
        ));
        jScrollPane4.setViewportView(tblGroomingHistory);

        javax.swing.GroupLayout groomingHistoryPanelLayout = new javax.swing.GroupLayout(groomingHistoryPanel);
        groomingHistoryPanel.setLayout(groomingHistoryPanelLayout);
        groomingHistoryPanelLayout.setHorizontalGroup(
            groomingHistoryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(groomingHistoryPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 1240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        groomingHistoryPanelLayout.setVerticalGroup(
            groomingHistoryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(groomingHistoryPanelLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(11, Short.MAX_VALUE))
        );

        HistoryPanel.addTab("Grooming History", groomingHistoryPanel);

        paymentHistoryPanel.setBackground(new java.awt.Color(248, 244, 253));
        paymentHistoryPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));

        jScrollPane3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));

        tblPaymentHistory.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Payment ID", "Appointment ID", "Payment Date", "Total Amount", "Amount Paid", "Change", "Payment Status"
            }
        ));
        jScrollPane3.setViewportView(tblPaymentHistory);

        javax.swing.GroupLayout paymentHistoryPanelLayout = new javax.swing.GroupLayout(paymentHistoryPanel);
        paymentHistoryPanel.setLayout(paymentHistoryPanelLayout);
        paymentHistoryPanelLayout.setHorizontalGroup(
            paymentHistoryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, paymentHistoryPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1236, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        paymentHistoryPanelLayout.setVerticalGroup(
            paymentHistoryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paymentHistoryPanelLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        HistoryPanel.addTab("Payment History", paymentHistoryPanel);

        jPanel5.setBackground(new java.awt.Color(255, 250, 240));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblAppointmentHistory.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Appointment ID", "Customer Name", "Pet Name", "Groomer Name", "Service", "Appointment Date", "Appointment Time", "Status"
            }
        ));
        jScrollPane5.setViewportView(tblAppointmentHistory);

        jPanel5.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, 1180, 130));

        HistoryPanel.addTab("Appointment History", jPanel5);

        getContentPane().add(HistoryPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, 1220, 220));
        HistoryPanel.getAccessibleContext().setAccessibleName("HistoryPanel");

        jPanel2.setBackground(new java.awt.Color(255, 244, 244));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 226, 226)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 25, -1, -1));

        lblSearch.setText("Search Customer:");
        jPanel2.add(lblSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 17, -1, -1));

        txtSearch.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.add(txtSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 39, 225, -1));

        btnSearch.setBackground(new java.awt.Color(36, 59, 90));
        btnSearch.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSearch.setForeground(java.awt.Color.white);
        btnSearch.setText("SEARCH");
        btnSearch.addActionListener(this::btnSearchActionPerformed);
        jPanel2.add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 40, -1, -1));

        lblReportPeriod.setText("Report Period:");
        jPanel2.add(lblReportPeriod, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));

        cmbReportType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose", "Recent Records", "Today", "Yesterday", "This Week", "This Month", "Custom Date" }));
        cmbReportType.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel2.add(cmbReportType, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 230, -1));

        btnGenerate.setText("GENERATE REPORT");
        btnGenerate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        btnGenerate.addActionListener(this::btnGenerateActionPerformed);
        jPanel2.add(btnGenerate, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 50, 190, 40));

        lblFrom.setText(" From:");
        jPanel2.add(lblFrom, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, -1, -1));

        lblTo.setText("To:");
        jPanel2.add(lblTo, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 70, -1, -1));

        txtDate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        txtDate.addActionListener(this::txtDateActionPerformed);
        jPanel2.add(txtDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 40, 200, 30));

        dateChooserTo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        dateChooserTo.addActionListener(this::dateChooserToActionPerformed);
        jPanel2.add(dateChooserTo, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 90, 200, 30));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 1260, 130));

        appointmentHistoryPanel.setBackground(new java.awt.Color(220, 238, 252));
        appointmentHistoryPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        appointmentHistoryPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(appointmentHistoryPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 1230, 235));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        MainFrame main = new MainFrame();
        main.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDateActionPerformed

    }//GEN-LAST:event_txtDateActionPerformed

    private void dateChooserToActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dateChooserToActionPerformed

    }//GEN-LAST:event_dateChooserToActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
                                          
    String lastName = txtSearch.getText().trim();

    if (lastName.isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "Please enter a customer's last name.",
            "Search",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    String sql =
            "SELECT customer_id, first_name, last_name, "
          + "contact_number, address "
          + "FROM customers "
          + "WHERE last_name LIKE ? "
          + "AND status = 'Active' "
          + "ORDER BY customer_id";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, "%" + lastName + "%");

        ResultSet rs = pst.executeQuery();

        java.util.ArrayList<String> customerIds =
                new java.util.ArrayList<>();

        java.util.ArrayList<String> customerNames =
                new java.util.ArrayList<>();

        java.util.ArrayList<String> contacts =
                new java.util.ArrayList<>();

        java.util.ArrayList<String> addresses =
                new java.util.ArrayList<>();

        while (rs.next()) {

            customerIds.add(
                rs.getString("customer_id")
            );

            customerNames.add(
                rs.getString("first_name")
                + " "
                + rs.getString("last_name")
            );

            contacts.add(
                rs.getString("contact_number")
            );

            addresses.add(
                rs.getString("address")
            );
        }

        if (customerIds.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Customer not found.",
                "Search",
                JOptionPane.INFORMATION_MESSAGE
            );

            return;
        }

        int selectedIndex = 0;
        if (customerIds.size() > 1) {

            Object[] choices =
                    new Object[customerIds.size()];

            for (int i = 0; i < customerIds.size(); i++) {

                choices[i] =
                        customerIds.get(i)
                        + " - "
                        + customerNames.get(i);
            }

            Object selected =
                    JOptionPane.showInputDialog(
                        this,
                        "Multiple customers found.\n"
                        + "Please select a customer:",
                        "Select Customer",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        choices,
                        choices[0]
                    );

            if (selected == null) {
                return;
            }

            for (int i = 0; i < choices.length; i++) {

                if (choices[i].equals(selected)) {
                    selectedIndex = i;
                    break;
                }
            }
        }
        String customerId =
                customerIds.get(selectedIndex);

        lblCustomerId.setText(customerId);

        lblFullName.setText(
                customerNames.get(selectedIndex)
        );

        lblContact.setText(
                contacts.get(selectedIndex)
        );

        lblAddress.setText(
                addresses.get(selectedIndex)
        );
        ((DefaultTableModel) tblAppointmentHistory.getModel()).setRowCount(0);
((DefaultTableModel) tblGroomingHistory.getModel()).setRowCount(0);
((DefaultTableModel) tblPaymentHistory.getModel()).setRowCount(0);
        String petSql =
                "SELECT pet_id, pet_name, pet_type, "
              + "breed, age, sex "
              + "FROM pets "
              + "WHERE customer_id = ? "
              + "ORDER BY pet_name";

        try (PreparedStatement petPst =
                con.prepareStatement(petSql)) {

            petPst.setString(1, customerId);

            ResultSet petRs =
                    petPst.executeQuery();

            DefaultTableModel petModel =
                    (DefaultTableModel) tblPets.getModel();

            petModel.setRowCount(0);

            while (petRs.next()) {

                petModel.addRow(new Object[]{
                    petRs.getString("pet_id"),
                    petRs.getString("pet_name"),
                    petRs.getString("pet_type"),
                    petRs.getString("breed"),
                    petRs.getInt("age"),
                    petRs.getString("sex")
                });
            }
        }
    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error searching customer: "
            + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnGenerateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerateActionPerformed

    String customerId = lblCustomerId.getText().trim();

    if (customerId.isEmpty() || customerId.equals("-")) {
        JOptionPane.showMessageDialog(
            this,
            "Please search and select a customer first.",
            "Missing Customer",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    String reportType =
            cmbReportType.getSelectedItem().toString();

    if (reportType.equals("Choose")) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a report period.",
            "Missing Report Period",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    java.util.Date selectedFrom =
            (java.util.Date) datePickerFrom.getValue();

    java.util.Date selectedTo =
            (java.util.Date) datePickerTo.getValue();

    java.time.ZoneId zone =
            java.time.ZoneId.systemDefault();

    java.time.LocalDate fromLocal =
            selectedFrom.toInstant()
                .atZone(zone)
                .toLocalDate();

    java.time.LocalDate toLocal =
            selectedTo.toInstant()
                .atZone(zone)
                .toLocalDate();

    if (fromLocal.isAfter(toLocal)) {
        JOptionPane.showMessageDialog(
            this,
            "From Date cannot be later than To Date.",
            "Invalid Date Range",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    java.sql.Date fromDate = java.sql.Date.valueOf(fromLocal);
    java.sql.Date toDate = java.sql.Date.valueOf(toLocal);

    ((DefaultTableModel) tblAppointmentHistory.getModel())
            .setRowCount(0);

    ((DefaultTableModel) tblGroomingHistory.getModel())
            .setRowCount(0);

    ((DefaultTableModel) tblPaymentHistory.getModel())
            .setRowCount(0);

    loadAppointmentHistoryByDate(
        customerId, fromDate, toDate
    );

    loadGroomingHistoryByDate(
        customerId, fromDate, toDate
    );

    loadPaymentHistoryByDate(
        customerId, fromDate, toDate
    );

    JOptionPane.showMessageDialog(
        this,
        "Report generated successfully!",
        "Success",
        JOptionPane.INFORMATION_MESSAGE
    );
    }//GEN-LAST:event_btnGenerateActionPerformed
private void loadAppointmentHistory() {

    String customerId = lblCustomerId.getText();

    if (customerId.equals("-")) {
        return;
    }

    String sql = "SELECT a.appointment_id, "
               + "CONCAT(c.first_name, ' ', c.last_name) AS customer, "
               + "p.pet_name, "
               + "a.appointment_date, "
               + "a.appointment_time, "
               + "gs.service_name, "
               + "CONCAT(g.first_name, ' ', g.last_name) AS groomer, "
               + "a.status "
               + "FROM appointments a "
               + "JOIN pets p ON a.pet_id = p.pet_id "
               + "JOIN customers c ON p.customer_id = c.customer_id "
               + "JOIN grooming_services gs ON a.service_id = gs.service_id "
               + "LEFT JOIN groomers g ON a.groomer_id = g.groomer_id "
               + "WHERE c.customer_id = ? "
               + "ORDER BY a.appointment_date DESC, "
               + "a.appointment_time DESC, "
               + "a.appointment_id DESC";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, customerId);

        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
                (DefaultTableModel) tblPaymentHistory.getModel();

        model.setRowCount(0);

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("appointment_id"),
                rs.getString("customer"),
                rs.getString("pet_name"),
                rs.getDate("appointment_date"),
                rs.getTime("appointment_time"),
                rs.getString("service_name"),
                rs.getString("groomer"),
                rs.getString("status")
            });
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading appointment history: "
            + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadGroomingHistory() {

    String customerId = lblCustomerId.getText();

    if (customerId.equals("-")) {
        return;
    }

    String sql = "SELECT gr.record_id, "
               + "gr.appointment_id, "
               + "p.pet_name, "
               + "gr.grooming_date, "
               + "gr.allergy, "
               + "gr.behavior, "
               + "gr.notes "
               + "FROM grooming_records gr "
               + "JOIN appointments a "
               + "ON gr.appointment_id = a.appointment_id "
               + "JOIN pets p "
               + "ON a.pet_id = p.pet_id "
               + "WHERE p.customer_id = ? "
               + "ORDER BY gr.grooming_date DESC, "
               + "gr.record_id DESC";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, customerId);

        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
                (DefaultTableModel) tblGroomingHistory.getModel();

        model.setRowCount(0);

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("record_id"),
                rs.getInt("appointment_id"),
                rs.getString("pet_name"),
                rs.getDate("grooming_date"),
                rs.getString("allergy"),
                rs.getString("behavior"),
                rs.getString("notes")
            });
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading grooming history: "
            + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadPaymentHistory() {

    String customerId = lblCustomerId.getText();

    if (customerId.equals("-")) {
        return;
    }

    String sql = "SELECT pay.payment_id, "
               + "pay.appointment_id, "
               + "pay.payment_date, "
               + "pay.total_amount, "
               + "pay.amount_paid, "
               + "pay.change_amount, "
               + "pay.payment_status "
               + "FROM payments pay "
               + "JOIN appointments a "
               + "ON pay.appointment_id = a.appointment_id "
               + "JOIN pets p "
               + "ON a.pet_id = p.pet_id "
               + "WHERE p.customer_id = ? "
               + "ORDER BY pay.payment_date DESC, "
               + "pay.payment_id DESC";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, customerId);

        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
        (DefaultTableModel) tblPaymentHistory.getModel();

        model.setRowCount(0);

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("payment_id"),
                rs.getInt("appointment_id"),
                rs.getDate("payment_date"),
                rs.getBigDecimal("total_amount"),
                rs.getBigDecimal("amount_paid"),
                rs.getBigDecimal("change_amount"),
                rs.getString("payment_status")
            });
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading payment history: "
            + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadAppointmentHistoryByDate(
        String customerId,
        Date fromDate,
        Date toDate) {

    String sql;

    if (fromDate == null || toDate == null) {

        sql = "SELECT a.appointment_id, "
            + "CONCAT(c.first_name, ' ', c.last_name) AS customer, "
            + "p.pet_name, "
            + "a.appointment_date, "
            + "a.appointment_time, "
            + "GROUP_CONCAT("
            + "DISTINCT gs.service_name "
            + "ORDER BY gs.service_name "
            + "SEPARATOR ', '"
            + ") AS service_names, "
            + "CONCAT(g.first_name, ' ', g.last_name) AS groomer, "
            + "a.status "
            + "FROM appointments a "
            + "JOIN pets p "
            + "ON a.pet_id = p.pet_id "
            + "JOIN customers c "
            + "ON p.customer_id = c.customer_id "
            + "LEFT JOIN appointment_services aps "
            + "ON a.appointment_id = aps.appointment_id "
            + "LEFT JOIN grooming_services gs "
            + "ON aps.service_id = gs.service_id "
            + "LEFT JOIN groomers g "
            + "ON a.groomer_id = g.groomer_id "
            + "WHERE c.customer_id = ? "
            + "GROUP BY a.appointment_id, "
            + "c.first_name, c.last_name, "
            + "p.pet_name, "
            + "a.appointment_date, "
            + "a.appointment_time, "
            + "g.first_name, g.last_name, "
            + "a.status "
            + "ORDER BY a.appointment_date DESC, "
            + "a.appointment_time DESC, "
            + "a.appointment_id DESC";

    } else {

        sql = "SELECT a.appointment_id, "
            + "CONCAT(c.first_name, ' ', c.last_name) AS customer, "
            + "p.pet_name, "
            + "a.appointment_date, "
            + "a.appointment_time, "
            + "GROUP_CONCAT("
            + "DISTINCT gs.service_name "
            + "ORDER BY gs.service_name "
            + "SEPARATOR ', '"
            + ") AS service_names, "
            + "CONCAT(g.first_name, ' ', g.last_name) AS groomer, "
            + "a.status "
            + "FROM appointments a "
            + "JOIN pets p "
            + "ON a.pet_id = p.pet_id "
            + "JOIN customers c "
            + "ON p.customer_id = c.customer_id "
            + "LEFT JOIN appointment_services aps "
            + "ON a.appointment_id = aps.appointment_id "
            + "LEFT JOIN grooming_services gs "
            + "ON aps.service_id = gs.service_id "
            + "LEFT JOIN groomers g "
            + "ON a.groomer_id = g.groomer_id "
            + "WHERE c.customer_id = ? "
            + "AND a.appointment_date BETWEEN ? AND ? "
            + "GROUP BY a.appointment_id, "
            + "c.first_name, c.last_name, "
            + "p.pet_name, "
            + "a.appointment_date, "
            + "a.appointment_time, "
            + "g.first_name, g.last_name, "
            + "a.status "
            + "ORDER BY a.appointment_date DESC, "
            + "a.appointment_time DESC, "
            + "a.appointment_id DESC";
    }

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, customerId);

        if (fromDate != null && toDate != null) {
            pst.setDate(2, fromDate);
            pst.setDate(3, toDate);
        }

        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
        (DefaultTableModel) tblAppointmentHistory.getModel();

        model.setRowCount(0);

        while (rs.next()) {

            String serviceNames =
                    rs.getString("service_names");

            if (serviceNames == null ||
                serviceNames.trim().isEmpty()) {

                serviceNames = "No Service";
            }

            model.addRow(new Object[]{
    rs.getInt("appointment_id"),
    rs.getString("customer"),
    rs.getString("pet_name"),
    rs.getString("groomer"),
    serviceNames,
    rs.getDate("appointment_date"),
    rs.getTime("appointment_time"),
    rs.getString("status")
});
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading appointment report: "
            + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadGroomingHistoryByDate(
        String customerId,
        Date fromDate,
        Date toDate) {

    String sql;

    if (fromDate == null || toDate == null) {

        sql = "SELECT gr.record_id, "
            + "gr.appointment_id, "
            + "p.pet_name, "
            + "gr.grooming_date, "
            + "gr.allergy, "
            + "gr.behavior, "
            + "gr.notes "
            + "FROM grooming_records gr "
            + "JOIN appointments a "
            + "ON gr.appointment_id = a.appointment_id "
            + "JOIN pets p "
            + "ON a.pet_id = p.pet_id "
            + "WHERE p.customer_id = ? "
            + "AND gr.status = 'Active' "
            + "ORDER BY gr.grooming_date DESC";

    } else {

        sql = "SELECT gr.record_id, "
            + "gr.appointment_id, "
            + "p.pet_name, "
            + "gr.grooming_date, "
            + "gr.allergy, "
            + "gr.behavior, "
            + "gr.notes "
            + "FROM grooming_records gr "
            + "JOIN appointments a "
            + "ON gr.appointment_id = a.appointment_id "
            + "JOIN pets p "
            + "ON a.pet_id = p.pet_id "
            + "WHERE p.customer_id = ? "
            + "AND gr.status = 'Active' "
            + "AND gr.grooming_date BETWEEN ? AND ? "
            + "ORDER BY gr.grooming_date DESC";
    }

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, customerId);

        if (fromDate != null && toDate != null) {
            pst.setDate(2, fromDate);
            pst.setDate(3, toDate);
        }

        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
                (DefaultTableModel) tblGroomingHistory.getModel();

        model.setRowCount(0);

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("record_id"),
                rs.getInt("appointment_id"),
                rs.getString("pet_name"),
                rs.getDate("grooming_date"),
                rs.getString("allergy"),
                rs.getString("behavior"),
                rs.getString("notes")
            });
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading grooming report: "
            + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadPaymentHistoryByDate(
        String customerId,
        Date fromDate,
        Date toDate) {

    String sql;

    if (fromDate == null || toDate == null) {

        sql = "SELECT pay.payment_id, "
            + "pay.appointment_id, "
            + "pay.payment_date, "
            + "pay.total_amount, "
            + "pay.amount_paid, "
            + "pay.change_amount, "
            + "pay.payment_status "
            + "FROM payments pay "
            + "JOIN appointments a "
            + "ON pay.appointment_id = a.appointment_id "
            + "JOIN pets p "
            + "ON a.pet_id = p.pet_id "
            + "WHERE p.customer_id = ? "
            + "ORDER BY pay.payment_date DESC";

    } else {

        sql = "SELECT pay.payment_id, "
            + "pay.appointment_id, "
            + "pay.payment_date, "
            + "pay.total_amount, "
            + "pay.amount_paid, "
            + "pay.change_amount, "
            + "pay.payment_status "
            + "FROM payments pay "
            + "JOIN appointments a "
            + "ON pay.appointment_id = a.appointment_id "
            + "JOIN pets p "
            + "ON a.pet_id = p.pet_id "
            + "WHERE p.customer_id = ? "
            + "AND pay.payment_date BETWEEN ? AND ? "
            + "ORDER BY pay.payment_date DESC";
    }

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, customerId);

        if (fromDate != null && toDate != null) {
            pst.setDate(2, fromDate);
            pst.setDate(3, toDate);
        }

        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
                (DefaultTableModel) tblPaymentHistory.getModel();

        model.setRowCount(0);

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("payment_id"),
                rs.getInt("appointment_id"),
                rs.getDate("payment_date"),
                rs.getBigDecimal("total_amount"),
                rs.getBigDecimal("amount_paid"),
                rs.getBigDecimal("change_amount"),
                rs.getString("payment_status")
            });
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading payment report: "
            + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}

private void updateDatePickers() {

    String reportType =
            cmbReportType.getSelectedItem().toString();

    java.time.LocalDate today =
            java.time.LocalDate.now();

    java.time.LocalDate from;
    java.time.LocalDate to;

    switch (reportType) {

        case "Today":
            from = today;
            to = today;
            break;

        case "Yesterday":
            from = today.minusDays(1);
            to = from;
            break;

        case "This Week":
            from = today.with(
                java.time.DayOfWeek.MONDAY
            );
            to = today.with(
                java.time.DayOfWeek.SUNDAY
            );
            break;

        case "This Month":
            from = today.withDayOfMonth(1);
            to = today.withDayOfMonth(
                today.lengthOfMonth()
            );
            break;

        case "Last Month":
            java.time.LocalDate lastMonth =
                    today.minusMonths(1);

            from = lastMonth.withDayOfMonth(1);
            to = lastMonth.withDayOfMonth(
                lastMonth.lengthOfMonth()
            );
            break;

        case "Custom Date":
        case "Choose":
        case "Recent Records":
        default:
            return;
    }

    java.util.Date fromDate =
        java.util.Date.from(
            from.atStartOfDay(
                java.time.ZoneId.systemDefault()
            ).toInstant()
        );

    java.util.Date toDate =
        java.util.Date.from(
            to.atStartOfDay(
                java.time.ZoneId.systemDefault()
            ).toInstant()
        );

    datePickerFrom.setValue(fromDate);
    datePickerTo.setValue(toDate);
}

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new ReportFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane HistoryPanel;
    private javax.swing.JPanel appointmentHistoryPanel;
    private javax.swing.JButton btnGenerate;
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox<String> cmbReportType;
    private javax.swing.JTextField dateChooserTo;
    private javax.swing.JPanel groomingHistoryPanel;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JLabel lblAddress;
    private javax.swing.JLabel lblAddressTitle;
    private javax.swing.JLabel lblContact;
    private javax.swing.JLabel lblContactTitle;
    private javax.swing.JLabel lblCustomerId;
    private javax.swing.JLabel lblCustomerIdTitle;
    private javax.swing.JLabel lblCustomerInfoTitle;
    private javax.swing.JLabel lblCustomerInfoTitle1;
    private javax.swing.JLabel lblFrom;
    private javax.swing.JLabel lblFullName;
    private javax.swing.JLabel lblFullNameTitle;
    private javax.swing.JLabel lblPetInfoTitle;
    private javax.swing.JLabel lblReportPeriod;
    private javax.swing.JLabel lblSearch;
    private javax.swing.JLabel lblTo;
    private javax.swing.JPanel paymentHistoryPanel;
    private javax.swing.JPanel pnlCustomerInfo;
    private javax.swing.JPanel pnlPetInfo;
    private javax.swing.JTable tblAppointmentHistory;
    private javax.swing.JTable tblGroomingHistory;
    private javax.swing.JTable tblPaymentHistory;
    private javax.swing.JTable tblPets;
    private javax.swing.JTextField txtDate;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
