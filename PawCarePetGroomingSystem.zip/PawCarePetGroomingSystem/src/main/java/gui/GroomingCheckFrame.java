
package gui;
import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.util.Stack;
public class GroomingCheckFrame extends javax.swing.JFrame {
    private Stack<Integer> groomingHistoryStack = new Stack<>();
    private javax.swing.JButton btnUndoArchive;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GroomingCheckFrame.class.getName());

   public GroomingCheckFrame(String appointmentId) {
    initComponents();

    txtAppointmentId.setText(appointmentId);

    loadAppointmentDetails(appointmentId);
    loadAppointmentDate();
    loadGroomingsRecord();
    txtRecordId.setEditable(false);
    txtAppointmentId.setEditable(false);

    txtGroomingdate.setEditable(false);

    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        buttonGroup5 = new javax.swing.ButtonGroup();
        buttonGroup6 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblGroomingRecords = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        lblPetId = new javax.swing.JLabel();
        lblPetName = new javax.swing.JLabel();
        lblBreed = new javax.swing.JLabel();
        lblAge = new javax.swing.JLabel();
        lblCustomer = new javax.swing.JLabel();
        lblPetIdValue = new javax.swing.JLabel();
        lblPetNameValue = new javax.swing.JLabel();
        lblBreedValue = new javax.swing.JLabel();
        lblAgeValue = new javax.swing.JLabel();
        lblCustomerValue = new javax.swing.JLabel();
        pnlConditionMain = new javax.swing.JPanel();
        pnlConditionHeader = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        lblConditionTitle = new javax.swing.JLabel();
        lblOverallHealth = new javax.swing.JLabel();
        rbHasAllergy = new javax.swing.JRadioButton();
        rbNoAllergy = new javax.swing.JRadioButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        txtAllergyDetails = new javax.swing.JTextField();
        cmbBehavior = new javax.swing.JComboBox<>();
        txtSpecialCare = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtNotes = new javax.swing.JTextArea();
        txtGroomingDate = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        lblRecordId = new javax.swing.JLabel();
        lblAppointmentId = new javax.swing.JLabel();
        lblGroomingDate = new javax.swing.JLabel();
        txtRecordId = new javax.swing.JTextField();
        txtAppointmentId = new javax.swing.JTextField();
        txtGroomingdate = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblGroomingsRecord = new javax.swing.JTable();
        txtSearch = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        btnComplete = new javax.swing.JButton();
        btnReset = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnArchive = new javax.swing.JButton();
        btnUnachieve = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(241, 248, 254));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(227, 240, 253));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(67, 184, 246)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(10, 46, 86));
        jLabel1.setText("GROOMING CHECK");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, -1, -1));

        jLabel2.setText("Checks the pet's condition and record record details.");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 50, -1, -1));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Segoe UI Symbol", 1, 40)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("🐶");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, 60, 60));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 150)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(10, 63, 119));
        jLabel3.setText("●");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, -40, -1, 131));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gui/petimage3.jpg"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(978, 0, -1, -1));

        jPanel12.setBackground(new java.awt.Color(255, 226, 226));
        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 205, 205)));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(36, 59, 90));
        jLabel13.setText("Grooming Notes");

        jLabel14.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(36, 59, 90));
        jLabel14.setText("⚠️");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel13)
                .addContainerGap(210, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(jLabel14))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 370, 398, -1));

        btnBack.setBackground(new java.awt.Color(52, 89, 145));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("←");
        btnBack.addActionListener(this::btnBackActionPerformed);
        jPanel1.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 20, -1));

        jPanel9.setBackground(new java.awt.Color(255, 244, 244));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 205, 205)));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setText(" GROOMING RECORDS TABLE");

        tblGroomingRecords.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Record ID", "Appointment ID", "Pet Name", "Customer", "Allergy", "Behavior", "Grooming Date", "Notes"
            }
        ));
        tblGroomingRecords.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblGroomingRecordsMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblGroomingRecords);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(381, 381, 381)
                .addComponent(jLabel10)
                .addContainerGap(407, Short.MAX_VALUE))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(185, 185, 185))
        );

        jPanel1.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 460, -1, 290));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 6, 1260, 80));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(241, 248, 254));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(52, 89, 145));

        jLabel5.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("🐾 ");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Pet Information");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addContainerGap(608, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel8))
                .addContainerGap(9, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 1, 780, 40));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gui/petimage.png"))); // NOI18N
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 44, 110, -1));

        lblPetId.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblPetId.setText("Pet Id");
        jPanel3.add(lblPetId, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 50, -1, -1));

        lblPetName.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblPetName.setText("Pet Name");
        jPanel3.add(lblPetName, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 70, -1, -1));

        lblBreed.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblBreed.setText("Breed");
        jPanel3.add(lblBreed, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, -1, -1));

        lblAge.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblAge.setText("Age");
        jPanel3.add(lblAge, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 130, -1, -1));

        lblCustomer.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblCustomer.setText("Customer");
        jPanel3.add(lblCustomer, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 160, -1, -1));

        lblPetIdValue.setText("P001");
        jPanel3.add(lblPetIdValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 50, -1, -1));

        lblPetNameValue.setText("Milo");
        jPanel3.add(lblPetNameValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, -1, -1));

        lblBreedValue.setText("Golden Retriever");
        jPanel3.add(lblBreedValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 100, -1, -1));

        lblAgeValue.setText("2 years");
        jPanel3.add(lblAgeValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 130, -1, -1));

        lblCustomerValue.setText("Juan Dela Cruz");
        jPanel3.add(lblCustomerValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 160, -1, -1));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 550, 190));

        pnlConditionMain.setBackground(new java.awt.Color(241, 248, 254));
        pnlConditionMain.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        pnlConditionMain.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pnlConditionHeader.setBackground(new java.awt.Color(52, 89, 145));
        pnlConditionHeader.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("📋 ");
        pnlConditionHeader.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, -1));

        lblConditionTitle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblConditionTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblConditionTitle.setText(" Condition Checklist");
        pnlConditionHeader.add(lblConditionTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 0, -1, -1));

        pnlConditionMain.add(pnlConditionHeader, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 1, 1240, 30));

        lblOverallHealth.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblOverallHealth.setText("Allergy ");
        pnlConditionMain.add(lblOverallHealth, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        buttonGroup1.add(rbHasAllergy);
        rbHasAllergy.setText("Yes");
        pnlConditionMain.add(rbHasAllergy, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, -1, -1));

        buttonGroup1.add(rbNoAllergy);
        rbNoAllergy.setText("No");
        pnlConditionMain.add(rbNoAllergy, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 60, -1, -1));
        pnlConditionMain.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 83, 330, 20));
        pnlConditionMain.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 50, -1, 270));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel18.setText(" Behavior");
        pnlConditionMain.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, -1));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel19.setText("Special Care");
        pnlConditionMain.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 90, -1, -1));

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel24.setText("Allergy Details");
        pnlConditionMain.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 40, -1, -1));
        pnlConditionMain.add(txtAllergyDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 60, 340, -1));

        cmbBehavior.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Behavior", "Calm", "Nervous", "Restless", "Aggressive" }));
        pnlConditionMain.add(cmbBehavior, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 310, -1));
        pnlConditionMain.add(txtSpecialCare, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 110, 340, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setText("GROOMING NOTES");
        pnlConditionMain.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 40, -1, -1));

        txtNotes.setColumns(20);
        txtNotes.setRows(5);
        jScrollPane2.setViewportView(txtNotes);

        pnlConditionMain.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 60, 390, 70));

        jPanel2.add(pnlConditionMain, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 1240, 150));

        txtGroomingDate.setBackground(new java.awt.Color(255, 250, 240));
        txtGroomingDate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 218, 130)));
        txtGroomingDate.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel11.setBackground(new java.awt.Color(255, 243, 214));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(36, 59, 90));
        jLabel11.setText("Grooming Details");

        jLabel12.setFont(new java.awt.Font("Segoe UI Symbol", 0, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(36, 59, 90));
        jLabel12.setText("📋 ");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addContainerGap(473, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addGap(0, 6, Short.MAX_VALUE))
        );

        txtGroomingDate.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 1, 670, -1));

        lblRecordId.setText("Record ID");
        txtGroomingDate.add(lblRecordId, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 50, -1, -1));

        lblAppointmentId.setText("Appointment ID");
        txtGroomingDate.add(lblAppointmentId, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 97, -1, -1));

        lblGroomingDate.setText("Grooming Date ");
        txtGroomingDate.add(lblGroomingDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, -1, -1));
        txtGroomingDate.add(txtRecordId, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 50, 440, -1));
        txtGroomingDate.add(txtAppointmentId, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 100, 440, -1));
        txtGroomingDate.add(txtGroomingdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 150, 440, -1));

        jPanel2.add(txtGroomingDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 110, 670, 190));

        jPanel5.setBackground(new java.awt.Color(255, 244, 244));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 226, 226)));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblGroomingsRecord.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Record ID", "Appointment ID", "Pet Name", "Customer", "Allergy", "Behavior", "Grooming Date", "Notes"
            }
        ));
        tblGroomingsRecord.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblGroomingsRecordMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tblGroomingsRecord);

        jPanel5.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 1150, 210));

        txtSearch.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 226, 226)));
        jPanel5.add(txtSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 250, 30));

        btnSearch.setBackground(new java.awt.Color(255, 226, 226));
        btnSearch.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSearch.setText("SEARCH");
        btnSearch.addActionListener(this::btnSearchActionPerformed);
        jPanel5.add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, 90, 30));

        btnSave.setBackground(new java.awt.Color(255, 244, 244));
        btnSave.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSave.setForeground(new java.awt.Color(36, 59, 90));
        btnSave.setText("SAVE");
        btnSave.addActionListener(this::btnSaveActionPerformed);
        jPanel5.add(btnSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 10, -1, -1));

        btnComplete.setBackground(new java.awt.Color(255, 250, 240));
        btnComplete.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnComplete.setForeground(new java.awt.Color(36, 59, 90));
        btnComplete.setText("COMPLETE");
        btnComplete.addActionListener(this::btnCompleteActionPerformed);
        jPanel5.add(btnComplete, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 10, -1, -1));

        btnReset.setBackground(new java.awt.Color(255, 244, 244));
        btnReset.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnReset.setForeground(new java.awt.Color(36, 59, 90));
        btnReset.setText("RESET");
        btnReset.addActionListener(this::btnResetActionPerformed);
        jPanel5.add(btnReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 10, -1, -1));

        btnUpdate.setBackground(new java.awt.Color(227, 240, 253));
        btnUpdate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnUpdate.setForeground(new java.awt.Color(36, 59, 90));
        btnUpdate.setText("UPDATE");
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);
        jPanel5.add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 10, -1, -1));

        btnArchive.setBackground(new java.awt.Color(227, 240, 253));
        btnArchive.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnArchive.setForeground(new java.awt.Color(36, 59, 90));
        btnArchive.setText("ARCHIVE");
        btnArchive.addActionListener(this::btnArchiveActionPerformed);
        jPanel5.add(btnArchive, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 10, -1, -1));

        btnUnachieve.setBackground(new java.awt.Color(36, 59, 90));
        btnUnachieve.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnUnachieve.setForeground(new java.awt.Color(255, 255, 255));
        btnUnachieve.setText("UNDO");
        btnUnachieve.addActionListener(this::btnUnachieveActionPerformed);
        jPanel5.add(btnUnachieve, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 10, 70, -1));

        jPanel2.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 470, 1240, 420));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-4, -7, 1340, 930));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed

        MainFrame main = new MainFrame();
        main.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed

    String appointmentId = txtAppointmentId.getText().trim();

    if (appointmentId.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "Please enter an Appointment ID.",
                "Validation",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    if (cmbBehavior.getSelectedIndex() == 0) {
        JOptionPane.showMessageDialog(
                this,
                "Please select the pet's behavior.",
                "Validation",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }
    String allergy;

    if (rbHasAllergy.isSelected()) {
        allergy = "Yes";
    } else if (rbNoAllergy.isSelected()) {
        allergy = "No";
    } else {
        JOptionPane.showMessageDialog(
                this,
                "Please select whether the pet has an allergy.",
                "Validation",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    String allergyDetails =
            txtAllergyDetails.getText().trim();

    String behavior =
            cmbBehavior.getSelectedItem().toString();

    String specialCare =
            txtSpecialCare.getText().trim();

    String notes =
            txtNotes.getText().trim();

    String groomingDate =
            txtGroomingdate.getText().trim();

    if (groomingDate.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "Please enter the grooming date.",
                "Validation",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }
        String checkSql =
                "SELECT appointment_id "
                + "FROM appointments "
                + "WHERE appointment_id = ?";

        PreparedStatement checkPst =
                con.prepareStatement(checkSql);

        checkPst.setInt(1, Integer.parseInt(appointmentId));

        ResultSet rs = checkPst.executeQuery();

        if (!rs.next()) {

            rs.close();
            checkPst.close();
            con.close();

            JOptionPane.showMessageDialog(
                    this,
                    "Appointment ID does not exist.",
                    "Validation",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        rs.close();
        checkPst.close();

        String sql =
                "INSERT INTO grooming_records "
                + "(appointment_id, allergy, allergy_details, "
                + "behavior, special_care, notes, grooming_date) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
String recordCheckSql =
        "SELECT record_id "
      + "FROM grooming_records "
      + "WHERE appointment_id = ?";

PreparedStatement recordCheckPst =
        con.prepareStatement(recordCheckSql);

recordCheckPst.setInt(
        1,
        Integer.parseInt(appointmentId)
);

ResultSet recordCheckRs =
        recordCheckPst.executeQuery();

if (recordCheckRs.next()) {

    recordCheckRs.close();
    recordCheckPst.close();
    con.close();

    JOptionPane.showMessageDialog(
            this,
            "A grooming record already exists for this appointment.",
            "Duplicate Record",
            JOptionPane.WARNING_MESSAGE
    );

    return;
}

recordCheckRs.close();
recordCheckPst.close();
        PreparedStatement pst =
                con.prepareStatement(
                        sql,
                        java.sql.Statement.RETURN_GENERATED_KEYS
                );

        pst.setInt(1, Integer.parseInt(appointmentId));
        pst.setString(2, allergy);
        pst.setString(3, allergyDetails);
        pst.setString(4, behavior);
        pst.setString(5, specialCare);
        pst.setString(6, notes);
        pst.setDate(
                7,
                java.sql.Date.valueOf(groomingDate)
        );

        int rowsInserted = pst.executeUpdate();

        if (rowsInserted > 0) {

            ResultSet generatedKeys =
                    pst.getGeneratedKeys();

            if (generatedKeys.next()) {
                txtRecordId.setText(
                        String.valueOf(
                                generatedKeys.getInt(1)
                        )
                );
            }

            generatedKeys.close();

            JOptionPane.showMessageDialog(
                    this,
                    "Grooming record saved successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
loadGroomingsRecord();

        pst.close();
        con.close();

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
                this,
                "Appointment ID must be a number.",
                "Validation",
                JOptionPane.WARNING_MESSAGE
        );

    } catch (IllegalArgumentException e) {

        JOptionPane.showMessageDialog(
                this,
                "Invalid date format.\n"
                + "Please use: yyyy-MM-dd\n"
                + "Example: 2026-09-29",
                "Invalid Date",
                JOptionPane.WARNING_MESSAGE
        );

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error saving grooming record:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnCompleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCompleteActionPerformed

    String appointmentId = txtAppointmentId.getText().trim();

    if (appointmentId.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "No appointment is selected.",
                "Validation",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    int id;

    try {
        id = Integer.parseInt(appointmentId);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(
                this,
                "Invalid Appointment ID.",
                "Validation",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Complete grooming for appointment #" + id + "?",
            "Complete Grooming",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    try (Connection con = DBConnection.getConnection()) {

        if (con == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        String checkSql =
                "SELECT record_id FROM grooming_records "
              + "WHERE appointment_id = ?";

        try (PreparedStatement checkPst =
                     con.prepareStatement(checkSql)) {

            checkPst.setInt(1, id);

            try (ResultSet rs = checkPst.executeQuery()) {

                if (!rs.next()) {
                    JOptionPane.showMessageDialog(
                            this,
                            "Please SAVE the grooming check first "
                            + "before completing this appointment.",
                            "Grooming Record Required",
                            JOptionPane.WARNING_MESSAGE
                    );
                    return;
                }
            }
        }

        String updateSql =
                "UPDATE appointments "
              + "SET status = 'Completed' "
              + "WHERE appointment_id = ? "
              + "AND status = 'In Progress'";

        try (PreparedStatement pst =
                     con.prepareStatement(updateSql)) {

            pst.setInt(1, id);

            int rowsUpdated = pst.executeUpdate();

            if (rowsUpdated > 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Grooming is completed for appointment #"
                        + id + ".\n"
                        + "The appointment and grooming record "
                        + "remain saved in the database.",
                        "Grooming Completed",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "This appointment is not currently In Progress. "
                        + "Please check its status in the Appointment table.",
                        "Status Not Updated",
                        JOptionPane.WARNING_MESSAGE
                );
            }
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error completing grooming:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnCompleteActionPerformed

    private void tblGroomingRecordsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblGroomingRecordsMouseClicked

    }//GEN-LAST:event_tblGroomingRecordsMouseClicked

    private void tblGroomingsRecordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblGroomingsRecordMouseClicked
    
    int selectedRow = tblGroomingsRecord.getSelectedRow();

    if (selectedRow == -1) {
        return;
    }

    javax.swing.table.DefaultTableModel model =
            (javax.swing.table.DefaultTableModel) tblGroomingsRecord.getModel();

    String recordId =
            model.getValueAt(selectedRow, 0).toString();

    String appointmentId =
            model.getValueAt(selectedRow, 1).toString();

    String petName =
            model.getValueAt(selectedRow, 2).toString();

    String customer =
            model.getValueAt(selectedRow, 3).toString();

    String allergy =
            model.getValueAt(selectedRow, 4).toString();

    String behavior =
            model.getValueAt(selectedRow, 5).toString();

    String groomingDate =
            model.getValueAt(selectedRow, 6).toString();

    String notes =
            model.getValueAt(selectedRow, 7).toString();

    txtRecordId.setText(recordId);
    txtAppointmentId.setText(appointmentId);

    lblPetNameValue.setText(petName);
    lblCustomerValue.setText(customer);

    if (allergy.equalsIgnoreCase("Yes")) {
        rbHasAllergy.setSelected(true);
    } else {
        rbNoAllergy.setSelected(true);
    }
    cmbBehavior.setSelectedItem(behavior);
    txtGroomingdate.setText(groomingDate);
    txtNotes.setText(notes);
    loadGroomingRecordDetails(
            Integer.parseInt(recordId)
    );
    }//GEN-LAST:event_tblGroomingsRecordMouseClicked

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
                                       
    String keyword = txtSearch.getText().trim().toLowerCase();

    loadGroomingsRecord();

    if (keyword.isEmpty()) {
        return;
    }

    javax.swing.table.DefaultTableModel model =
            (javax.swing.table.DefaultTableModel) tblGroomingsRecord.getModel();

    boolean found = false;

    for (int i = model.getRowCount() - 1; i >= 0; i--) {

        boolean match = false;

        for (int j = 0; j < model.getColumnCount(); j++) {

            Object value = model.getValueAt(i, j);

            if (value != null &&
                    value.toString().toLowerCase().contains(keyword)) {

                match = true;
                break;
            }
        }

        if (!match) {
            model.removeRow(i);
        } else {
            found = true;
        }
    }

    if (!found) {

        JOptionPane.showMessageDialog(
                this,
                "No grooming record found.",
                "Search",
                JOptionPane.INFORMATION_MESSAGE
        );

        loadGroomingsRecord();
    }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed

    txtRecordId.setText("");

    rbHasAllergy.setSelected(false);
    rbNoAllergy.setSelected(false);

    txtAllergyDetails.setText("");

    cmbBehavior.setSelectedIndex(0);

    txtSpecialCare.setText("");

    txtNotes.setText("");

    loadAppointmentDate();
    }//GEN-LAST:event_btnResetActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed

    String recordId = txtRecordId.getText().trim();

    // 1. Check if a record was selected from the table
    if (recordId.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "Please select a grooming record from the table first.",
                "No Selection",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    // 2. Check the fields
    if (cmbBehavior.getSelectedIndex() == 0) {
        JOptionPane.showMessageDialog(
                this,
                "Please select the pet's behavior.",
                "Validation",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    String allergy;

    if (rbHasAllergy.isSelected()) {
        allergy = "Yes";
    } else if (rbNoAllergy.isSelected()) {
        allergy = "No";
    } else {
        JOptionPane.showMessageDialog(
                this,
                "Please select whether the pet has an allergy.",
                "Validation",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    String allergyDetails = txtAllergyDetails.getText().trim();
    String behavior = cmbBehavior.getSelectedItem().toString();
    String specialCare = txtSpecialCare.getText().trim();
    String notes = txtNotes.getText().trim();
    String groomingDate = txtGroomingdate.getText().trim();

    if (groomingDate.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "Please enter the grooming date.",
                "Validation",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    // 3. Ask for confirmation
    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to update this grooming record?",
            "Confirm Update",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    // 4. Update the record in the database
    String sql =
            "UPDATE grooming_records "
            + "SET allergy = ?, allergy_details = ?, "
            + "behavior = ?, special_care = ?, "
            + "notes = ?, grooming_date = ? "
            + "WHERE record_id = ?";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, allergy);
        pst.setString(2, allergyDetails);
        pst.setString(3, behavior);
        pst.setString(4, specialCare);
        pst.setString(5, notes);
        pst.setDate(6, java.sql.Date.valueOf(groomingDate));
        pst.setInt(7, Integer.parseInt(recordId));

        int rowsUpdated = pst.executeUpdate();

        if (rowsUpdated > 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Grooming record updated successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            loadGroomingsRecord();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "The grooming record could not be updated.",
                    "Update Failed",
                    JOptionPane.ERROR_MESSAGE
            );
        }

    } catch (IllegalArgumentException e) {

        JOptionPane.showMessageDialog(
                this,
                "Invalid date format.\n"
                + "Please use: yyyy-MM-dd\n"
                + "Example: 2026-09-29",
                "Invalid Date",
                JOptionPane.WARNING_MESSAGE
        );

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
                this,
                "Error updating grooming record:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnArchiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchiveActionPerformed

    String recordId = txtRecordId.getText().trim();

    // 1. Check if a record was selected from the table
    if (recordId.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "Please select a grooming record from the table first.",
                "No Selection",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    // 2. Ask for confirmation
    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to archive this grooming record?",
            "Confirm Archive",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    // 3. Mark the record as Archived (it is not deleted)
    String sql =
            "UPDATE grooming_records "
            + "SET status = 'Archived' "
            + "WHERE record_id = ?";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setInt(1, Integer.parseInt(recordId));

        int rowsUpdated = pst.executeUpdate();

        if (rowsUpdated > 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Grooming record archived successfully.",
                                        "Archive",
                    JOptionPane.INFORMATION_MESSAGE
            );
            groomingHistoryStack.push(Integer.parseInt(recordId));

            loadGroomingsRecord();
            btnResetActionPerformed(null);

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "The grooming record could not be archived.",
                    "Archive Failed",
                    JOptionPane.ERROR_MESSAGE
            );
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
                this,
                "Error archiving grooming record:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnArchiveActionPerformed

    private void btnUnachieveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUnachieveActionPerformed

        if (groomingHistoryStack.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "There is no archived record to undo.",
                    "Undo Archive",
                    JOptionPane.INFORMATION_MESSAGE
            );

            return;
        }

        int lastArchivedId = groomingHistoryStack.peek(); 

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Restore grooming record #" + lastArchivedId + "?",
                "Confirm Undo Archive",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String sql =
                "UPDATE grooming_records "
                + "SET status = 'Active' "
                + "WHERE record_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, lastArchivedId);

            int rowsUpdated = pst.executeUpdate();

            if (rowsUpdated > 0) {

                groomingHistoryStack.pop();
                JOptionPane.showMessageDialog(
                        this,
                        "Grooming record #" + lastArchivedId + " was restored.",
                        "Undo Archive",
                        JOptionPane.INFORMATION_MESSAGE
                );

                loadGroomingsRecord();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "The grooming record could not be restored.",
                        "Undo Archive Failed",
                        JOptionPane.ERROR_MESSAGE
                );
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error restoring grooming record:\n"
                    + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }//GEN-LAST:event_btnUnachieveActionPerformed
private void loadGroomingsRecord() {

    javax.swing.table.DefaultTableModel model =
            (javax.swing.table.DefaultTableModel) tblGroomingsRecord.getModel();

    model.setColumnIdentifiers(new String[]{
        "Record ID", "Appointment ID", "Pet Name", "Customer Name",
        "Allergy", "Behavior", "Grooming Date", "Notes",
        "Allergy Details", "Special Care"
    });

    model.setRowCount(0);

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {
            return;
        }

        String sql =
                "SELECT gr.record_id, "
                + "gr.appointment_id, "
                + "p.pet_name, "
                + "CONCAT(c.first_name, ' ', c.last_name) AS customer_name, "
                + "gr.allergy, "
                + "gr.behavior, "
                + "gr.grooming_date, "
                + "gr.notes, "
                + "gr.allergy_details, "
                + "gr.special_care "
                + "FROM grooming_records gr "
                + "JOIN appointments a "
                + "ON gr.appointment_id = a.appointment_id "
                + "JOIN pets p "
                + "ON a.pet_id = p.pet_id "
                + "JOIN customers c "
                + "ON p.customer_id = c.customer_id "
                + "WHERE gr.status = 'Active' "
                + "ORDER BY gr.grooming_date DESC, gr.record_id DESC";

        PreparedStatement pst =
                con.prepareStatement(sql);

        ResultSet rs = pst.executeQuery();

        while (rs.next()) {

            String allergyDetails = rs.getString("allergy_details");
            String specialCare = rs.getString("special_care");

            if (allergyDetails == null || allergyDetails.trim().isEmpty()) {
                allergyDetails = "-";
            }

            if (specialCare == null || specialCare.trim().isEmpty()) {
                specialCare = "-";
            }

            model.addRow(new Object[]{
                rs.getInt("record_id"),
                rs.getInt("appointment_id"),
                rs.getString("pet_name"),
                rs.getString("customer_name"),
                rs.getString("allergy"),
                rs.getString("behavior"),
                rs.getDate("grooming_date"),
                rs.getString("notes"),
                allergyDetails,
                specialCare
            });
        }

        rs.close();
        pst.close();
        con.close();

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error loading grooming records:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadGroomingRecordDetails(int recordId) {

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {
            return;
        }

        String sql =
                "SELECT allergy_details, special_care "
                + "FROM grooming_records "
                + "WHERE record_id = ?";

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setInt(1, recordId);

        ResultSet rs = pst.executeQuery();

        if (rs.next()) {

            String allergyDetails =
                    rs.getString("allergy_details");

            String specialCare =
                    rs.getString("special_care");

            txtAllergyDetails.setText(
                    allergyDetails == null
                    ? ""
                    : allergyDetails
            );

            txtSpecialCare.setText(
                    specialCare == null
                    ? ""
                    : specialCare
            );
        }

        rs.close();
        pst.close();
        con.close();

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error loading grooming record details:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadAppointmentDetails(String appointmentId) {
    if (appointmentId == null || appointmentId.trim().isEmpty()) {
        return;
    }

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {
            return;
        }

        String sql =
                "SELECT p.pet_id, "
                + "p.pet_name, "
                + "p.breed, "
                + "p.age, "
                + "CONCAT(c.first_name, ' ', c.last_name) AS customer_name "
                + "FROM appointments a "
                + "JOIN pets p "
                + "ON a.pet_id = p.pet_id "
                + "JOIN customers c "
                + "ON p.customer_id = c.customer_id "
                + "WHERE a.appointment_id = ?";

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setInt(1, Integer.parseInt(appointmentId.trim()));

        ResultSet rs = pst.executeQuery();

        if (rs.next()) {

            lblPetIdValue.setText(
                    rs.getString("pet_id")
            );

            lblPetNameValue.setText(
                    rs.getString("pet_name")
            );

            lblBreedValue.setText(
                    rs.getString("breed")
            );

            lblAgeValue.setText(
                    rs.getString("age") + " years"
            );

            lblCustomerValue.setText(
                    rs.getString("customer_name")
            );
        }

        rs.close();
        pst.close();
        con.close();

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error loading appointment details:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadAppointmentDate() {

    String appointmentId = txtAppointmentId.getText().trim();

    if (appointmentId.isEmpty()) {
        return;
    }

    String sql =
            "SELECT appointment_date "
          + "FROM appointments "
          + "WHERE appointment_id = ?";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setInt(1, Integer.parseInt(appointmentId));

        ResultSet rs = pst.executeQuery();

        if (rs.next()) {

            java.sql.Date appointmentDate =
                    rs.getDate("appointment_date");

            if (appointmentDate != null) {

                txtGroomingdate.setText(
                    appointmentDate.toString()
                );

            }
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading appointment date: "
            + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new GroomingCheckFrame("").setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnArchive;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnComplete;
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnUnachieve;
    private javax.swing.JButton btnUpdate;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.ButtonGroup buttonGroup5;
    private javax.swing.ButtonGroup buttonGroup6;
    private javax.swing.JComboBox<String> cmbBehavior;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JLabel lblAge;
    private javax.swing.JLabel lblAgeValue;
    private javax.swing.JLabel lblAppointmentId;
    private javax.swing.JLabel lblBreed;
    private javax.swing.JLabel lblBreedValue;
    private javax.swing.JLabel lblConditionTitle;
    private javax.swing.JLabel lblCustomer;
    private javax.swing.JLabel lblCustomerValue;
    private javax.swing.JLabel lblGroomingDate;
    private javax.swing.JLabel lblOverallHealth;
    private javax.swing.JLabel lblPetId;
    private javax.swing.JLabel lblPetIdValue;
    private javax.swing.JLabel lblPetName;
    private javax.swing.JLabel lblPetNameValue;
    private javax.swing.JLabel lblRecordId;
    private javax.swing.JPanel pnlConditionHeader;
    private javax.swing.JPanel pnlConditionMain;
    private javax.swing.JRadioButton rbHasAllergy;
    private javax.swing.JRadioButton rbNoAllergy;
    private javax.swing.JTable tblGroomingRecords;
    private javax.swing.JTable tblGroomingsRecord;
    private javax.swing.JTextField txtAllergyDetails;
    private javax.swing.JTextField txtAppointmentId;
    private javax.swing.JPanel txtGroomingDate;
    private javax.swing.JTextField txtGroomingdate;
    private javax.swing.JTextArea txtNotes;
    private javax.swing.JTextField txtRecordId;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtSpecialCare;
    // End of variables declaration//GEN-END:variables
}
