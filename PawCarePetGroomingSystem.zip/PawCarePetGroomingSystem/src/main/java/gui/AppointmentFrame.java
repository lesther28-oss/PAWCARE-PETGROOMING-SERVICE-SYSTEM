package gui;
import database.DBConnection;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import java.util.HashMap;
import java.util.Map;

public class AppointmentFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(AppointmentFrame.class.getName());

    private com.toedter.calendar.JDateChooser dateChooser;
    private java.util.ArrayList<Integer> serviceIds = new java.util.ArrayList<>();
    private java.util.ArrayList<String> groomerIds = new java.util.ArrayList<>();
    private java.util.Queue<Integer> appointmentQueue =new java.util.LinkedList<>();
    private Map<String, String> groomerSpecializations = new HashMap<>();
    private boolean updatingGroomerAvailability = false;
    
      public AppointmentFrame() {
    initComponents();
  setupGroomerComboColors();

    cmbTime.addActionListener(e -> updateGroomerAvailabilityDisplay());

    lstServices.addListSelectionListener(e -> {
    if (!e.getValueIsAdjusting()) {
        updateGroomerAvailabilityDisplay();
    }
});
    lstServices.setSelectionMode(
        javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION
    );

    setupDateChooser();
    loadStatusToCombo();
    loadTimeToCombo();
    loadServicesToList();
    loadGroomersToCombo();
    loadAppointments();
    colorAppointmentRows();

setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lblAppointmentId = new javax.swing.JLabel();
        lblDate = new javax.swing.JLabel();
        lblService = new javax.swing.JLabel();
        lblStatus = new javax.swing.JLabel();
        lblTime = new javax.swing.JLabel();
        txtAppointmentId = new javax.swing.JTextField();
        txtDate = new javax.swing.JTextField();
        btnAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnArchieve = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txtCustomerSearch = new javax.swing.JTextField();
        btnSearchCustomer = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        cmbCustomer = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        cmbPet = new javax.swing.JComboBox<>();
        cmbStatus = new javax.swing.JComboBox<>();
        jSeparator3 = new javax.swing.JSeparator();
        cmbTime = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        cmbGroomer = new javax.swing.JComboBox<>();
        btnProcessNext = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        lstServices = new javax.swing.JList<>();
        btnCompleteGrooming = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        txtSearch = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblAppointments = new javax.swing.JTable();
        btnGroomingCheck = new javax.swing.JButton();
        btnProceedPayment = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        lblAppointmentTitle = new javax.swing.JLabel();
        lblAppointmentSubtitle = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        jSeparator2.setBackground(new java.awt.Color(36, 59, 90));
        jSeparator2.setForeground(new java.awt.Color(36, 59, 90));

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(232, 238, 244));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(241, 248, 254));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblAppointmentId.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblAppointmentId.setForeground(new java.awt.Color(36, 59, 90));
        lblAppointmentId.setText("Appointment ID");
        jPanel1.add(lblAppointmentId, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 10, -1, -1));

        lblDate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblDate.setForeground(new java.awt.Color(36, 59, 90));
        lblDate.setText(" Date");
        jPanel1.add(lblDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 30, -1, -1));

        lblService.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblService.setForeground(new java.awt.Color(36, 59, 90));
        lblService.setText("Service");
        jPanel1.add(lblService, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 50, -1, -1));

        lblStatus.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblStatus.setForeground(new java.awt.Color(36, 59, 90));
        lblStatus.setText("Status ");
        jPanel1.add(lblStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 160, -1, -1));

        lblTime.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblTime.setForeground(new java.awt.Color(36, 59, 90));
        lblTime.setText("Time");
        jPanel1.add(lblTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 80, -1, 44));

        txtAppointmentId.setEditable(false);
        txtAppointmentId.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel1.add(txtAppointmentId, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 10, 130, 20));

        txtDate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        txtDate.addActionListener(this::txtDateActionPerformed);
        jPanel1.add(txtDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 50, 250, 30));

        btnAdd.setBackground(new java.awt.Color(36, 59, 90));
        btnAdd.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btnAdd.setForeground(new java.awt.Color(255, 255, 255));
        btnAdd.setText("📋 ADD TO QUEUE");
        btnAdd.addActionListener(this::btnAddActionPerformed);
        jPanel1.add(btnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 180, 30));

        btnUpdate.setBackground(new java.awt.Color(52, 89, 145));
        btnUpdate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnUpdate.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdate.setText("UPDATE");
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);
        jPanel1.add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 280, 100, 30));

        btnArchieve.setBackground(new java.awt.Color(52, 89, 145));
        btnArchieve.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnArchieve.setForeground(new java.awt.Color(255, 255, 255));
        btnArchieve.setText("ARCHIVE");
        btnArchieve.addActionListener(this::btnArchieveActionPerformed);
        jPanel1.add(btnArchieve, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 280, 100, 30));

        btnClear.setBackground(new java.awt.Color(220, 220, 220));
        btnClear.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnClear.setForeground(new java.awt.Color(255, 255, 255));
        btnClear.setText("CLEAR");
        btnClear.addActionListener(this::btnClearActionPerformed);
        jPanel1.add(btnClear, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 280, 110, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(36, 59, 90));
        jLabel5.setText("Customer Search");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, -1, -1));

        txtCustomerSearch.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        txtCustomerSearch.addActionListener(this::txtCustomerSearchActionPerformed);
        jPanel1.add(txtCustomerSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 260, 20));

        btnSearchCustomer.setBackground(new java.awt.Color(36, 59, 90));
        btnSearchCustomer.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSearchCustomer.setForeground(new java.awt.Color(255, 255, 255));
        btnSearchCustomer.setText("Search Customer");
        btnSearchCustomer.addActionListener(this::btnSearchCustomerActionPerformed);
        jPanel1.add(btnSearchCustomer, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 50, 130, 20));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(36, 59, 90));
        jLabel6.setText("Customer");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, -1, -1));

        cmbCustomer.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbCustomer.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        cmbCustomer.addActionListener(this::cmbCustomerActionPerformed);
        jPanel1.add(cmbCustomer, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 400, 30));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(36, 59, 90));
        jLabel7.setText("Pet");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, -1, -1));

        cmbPet.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbPet.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel1.add(cmbPet, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 400, 30));

        cmbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbStatus.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        cmbStatus.addActionListener(this::cmbStatusActionPerformed);
        jPanel1.add(cmbStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 180, 240, 40));

        jSeparator3.setBackground(new java.awt.Color(36, 59, 90));
        jSeparator3.setForeground(new java.awt.Color(100, 100, 100));
        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jPanel1.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 30, 30, 200));

        cmbTime.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(cmbTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 110, 240, 40));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(36, 59, 90));
        jLabel8.setText("Groomer");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, -1, -1));

        cmbGroomer.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(cmbGroomer, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 210, 400, -1));

        btnProcessNext.setBackground(new java.awt.Color(255, 243, 214));
        btnProcessNext.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnProcessNext.setText("PROCESS NEXT");
        btnProcessNext.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 218, 130)));
        btnProcessNext.addActionListener(this::btnProcessNextActionPerformed);
        jPanel1.add(btnProcessNext, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 180, -1));

        lstServices.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(lstServices);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 70, 250, 170));

        btnCompleteGrooming.setBackground(new java.awt.Color(238, 250, 247));
        btnCompleteGrooming.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCompleteGrooming.setText("COMPLETE GROOMING");
        btnCompleteGrooming.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(165, 215, 190)));
        btnCompleteGrooming.addActionListener(this::btnCompleteGroomingActionPerformed);
        jPanel1.add(btnCompleteGrooming, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 280, 160, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 1250, 340));

        jPanel2.setBackground(new java.awt.Color(242, 250, 247));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(165, 215, 190)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtSearch.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        txtSearch.addActionListener(this::txtSearchActionPerformed);
        jPanel2.add(txtSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 11, 283, 27));

        btnSearch.setBackground(new java.awt.Color(52, 89, 145));
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setText("🔍");
        btnSearch.addActionListener(this::btnSearchActionPerformed);
        jPanel2.add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(304, 13, 36, -1));

        tblAppointments.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Appointment ID", "Customer Name", "Pet Name", "Date", "Time", "Service", "Groomer", "Appointment Status", "Payment Status", "Balance Due"
            }
        ));
        tblAppointments.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblAppointmentsMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblAppointments);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(7, 47, 1208, 315));

        btnGroomingCheck.setBackground(new java.awt.Color(255, 250, 240));
        btnGroomingCheck.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnGroomingCheck.setText(" Grooming Check");
        btnGroomingCheck.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 218, 130)));
        btnGroomingCheck.addActionListener(this::btnGroomingCheckActionPerformed);
        jPanel2.add(btnGroomingCheck, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 10, 160, 30));

        btnProceedPayment.setBackground(new java.awt.Color(226, 241, 255));
        btnProceedPayment.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnProceedPayment.setForeground(new java.awt.Color(36, 59, 90));
        btnProceedPayment.setText("Proceed to Payment ");
        btnProceedPayment.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        btnProceedPayment.addActionListener(this::btnProceedPaymentActionPerformed);
        jPanel2.add(btnProceedPayment, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 10, 180, 34));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, 1250, 430));

        jPanel3.setBackground(new java.awt.Color(226, 241, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblAppointmentTitle.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        lblAppointmentTitle.setForeground(new java.awt.Color(36, 59, 90));
        lblAppointmentTitle.setText("Appointment Management ");
        jPanel3.add(lblAppointmentTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, -1, -1));

        lblAppointmentSubtitle.setBackground(new java.awt.Color(241, 248, 254));
        lblAppointmentSubtitle.setForeground(new java.awt.Color(100, 100, 100));
        lblAppointmentSubtitle.setText("Manage pet grooming appointments");
        jPanel3.add(lblAppointmentSubtitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gui/petimage3.jpg"))); // NOI18N
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 0, -1, -1));

        jButton1.setBackground(new java.awt.Color(36, 59, 90));
        jButton1.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        jButton1.setForeground(java.awt.Color.white);
        jButton1.setText("←");
        jButton1.addActionListener(this::jButton1ActionPerformed);
        jPanel3.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 80));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDateActionPerformed

    }//GEN-LAST:event_txtDateActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
                                     
                                    
    if (cmbCustomer.getSelectedIndex() <= 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please search and select a customer first.",
                "Missing Customer",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (cmbPet.getSelectedIndex() <= 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a pet.",
                "Missing Pet",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    String petItem =
            cmbPet.getSelectedItem().toString();

    String petId =
            petItem.split(" - ")[0]
                    .trim()
                    .toUpperCase();

    String dateText =
            txtDate.getText().trim();

    if (dateText.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "Please select an appointment date.",
                "Missing Date",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    java.time.LocalDate date;

    try {

        date =
                java.time.LocalDate.parse(dateText);

    } catch (java.time.format.DateTimeParseException e) {

        JOptionPane.showMessageDialog(
                this,
                "Invalid date. Please use yyyy-MM-dd.",
                "Invalid Date",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (date.isBefore(java.time.LocalDate.now())) {

        JOptionPane.showMessageDialog(
                this,
                "The appointment date cannot be in the past.",
                "Invalid Date",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (cmbTime.getSelectedIndex() <= 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select an appointment time.",
                "Missing Time",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    String timeText =
            cmbTime.getSelectedItem().toString();

    java.time.LocalTime time;

    try {

        java.time.format.DateTimeFormatter formatter =
                java.time.format.DateTimeFormatter.ofPattern(
                        "hh:mm a"
                );

        time =
                java.time.LocalTime.parse(
                        timeText,
                        formatter
                );

    } catch (java.time.format.DateTimeParseException e) {

        JOptionPane.showMessageDialog(
                this,
                "Invalid appointment time.",
                "Invalid Time",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    int[] selectedIndices =
            lstServices.getSelectedIndices();

    if (selectedIndices.length == 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select at least one grooming service.",
                "Missing Service",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (cmbGroomer.getSelectedIndex() <= 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a groomer.",
                "Missing Groomer",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    int groomerIndex =
            cmbGroomer.getSelectedIndex();

    String groomerId =
            groomerIds.get(groomerIndex);

    if (cmbStatus.getSelectedIndex() <= 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select an appointment status.",
                "Missing Status",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    String status =
            cmbStatus.getSelectedItem().toString();


    int durationMinutes =
            getSelectedServicesDuration();

    if (durationMinutes <= 0) {

        JOptionPane.showMessageDialog(
                this,
                "The selected services have no valid duration.",
                "Invalid Duration",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    java.time.LocalTime endTime =
            time.plusMinutes(durationMinutes);

if (overlapsLunchBreak(time, durationMinutes)) {

    JOptionPane.showMessageDialog(
            this,
            "The selected appointment overlaps "
            + "the groomer's lunch break "
            + "(12:00 PM - 1:00 PM).\n\n"
            + "Please select an appointment time "
            + "before 12:00 PM or from 1:00 PM onwards.",
            "Lunch Break",
            JOptionPane.WARNING_MESSAGE
    );

    return;
}

    java.time.LocalTime closingTime =
            java.time.LocalTime.of(18, 0);

    if (endTime.isAfter(closingTime)) {

        JOptionPane.showMessageDialog(
                this,
                "The selected services would end at "
                + endTime.format(
                        java.time.format.DateTimeFormatter
                                .ofPattern("hh:mm a")
                )
                + ".\n\n"
                + "Appointments must be completed by 6:00 PM.\n"
                + "Please select an earlier appointment time.",
                "Outside Operating Hours",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (!isGroomerAvailable(
            groomerId,
            date,
            time,
            durationMinutes,
            0)) {

        JOptionPane.showMessageDialog(
                this,
                "Groomer "
                + cmbGroomer.getSelectedItem()
                + " is already booked during this time.\n\n"
                + "Requested schedule: "
                + time.format(
                        java.time.format.DateTimeFormatter
                                .ofPattern("hh:mm a")
                )
                + " - "
                + endTime.format(
                        java.time.format.DateTimeFormatter
                                .ofPattern("hh:mm a")
                )
                + "\n\n"
                + "Please select another groomer or time.",
                "Groomer Unavailable",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    if (!confirmGroomerSpecialization(groomerId, selectedIndices)) {
        return;
    }
 try {
        Connection con =
                DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        String petSql =
                "SELECT c.status "
                + "FROM pets p "
                + "JOIN customers c "
                + "ON p.customer_id = c.customer_id "
                + "WHERE p.pet_id = ?";

        PreparedStatement petPst =
                con.prepareStatement(petSql);

        petPst.setString(
                1,
                petId
        );

        ResultSet petRs =
                petPst.executeQuery();

        if (!petRs.next()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Pet ID not found. Please register the pet first.",
                    "Pet Not Found",
                    JOptionPane.WARNING_MESSAGE
            );

            petRs.close();
            petPst.close();
            con.close();

            return;
        }

        String ownerStatus =
                petRs.getString("status");

        petRs.close();
        petPst.close();

        if (ownerStatus != null
                && ownerStatus.equalsIgnoreCase("Archived")) {

            JOptionPane.showMessageDialog(
                    this,
                    "The owner of this pet is archived.",
                    "Owner Archived",
                    JOptionPane.WARNING_MESSAGE
            );

            con.close();

            return;
        }
        String duplicateSql =
                "SELECT COUNT(*) "
                + "FROM appointments "
                + "WHERE pet_id = ? "
                + "AND appointment_date = ? "
                + "AND appointment_time = ? "
                + "AND status <> 'Cancelled'";

        PreparedStatement duplicatePst =
                con.prepareStatement(duplicateSql);

        duplicatePst.setString(
                1,
                petId
        );

        duplicatePst.setDate(
                2,
                java.sql.Date.valueOf(date)
        );

        duplicatePst.setTime(
                3,
                java.sql.Time.valueOf(time)
        );

        ResultSet duplicateRs =
                duplicatePst.executeQuery();

        if (duplicateRs.next()
                && duplicateRs.getInt(1) > 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "This pet already has an appointment at that date and time.",
                    "Duplicate Appointment",
                    JOptionPane.WARNING_MESSAGE
            );

            duplicateRs.close();
            duplicatePst.close();
            con.close();

            return;
        }

        duplicateRs.close();
        duplicatePst.close();

        int confirm =
                JOptionPane.showConfirmDialog(
                        this,
                        "Are you sure you want to add this appointment?\n\n"
                        + "Groomer: "
                        + cmbGroomer.getSelectedItem()
                        + "\n"
                        + "Schedule: "
                        + time.format(
                                java.time.format.DateTimeFormatter
                                        .ofPattern("hh:mm a")
                        )
                        + " - "
                        + endTime.format(
                                java.time.format.DateTimeFormatter
                                        .ofPattern("hh:mm a")
                        )
                        + "\n"
                        + "Duration: "
                        + durationMinutes
                        + " minutes",
                        "Confirm Appointment",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

        if (confirm != JOptionPane.YES_OPTION) {

            con.close();

            return;
        }
        int firstServiceId =
                serviceIds.get(selectedIndices[0]);

        String sql =
                "INSERT INTO appointments "
                + "(pet_id, service_id, groomer_id, "
                + "appointment_date, appointment_time, status) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        PreparedStatement pst =
                con.prepareStatement(
                        sql,
                        java.sql.Statement.RETURN_GENERATED_KEYS
                );

        pst.setString(
                1,
                petId
        );

        pst.setInt(
                2,
                firstServiceId
        );

        pst.setString(
                3,
                groomerId
        );

        pst.setDate(
                4,
                java.sql.Date.valueOf(date)
        );

        pst.setTime(
                5,
                java.sql.Time.valueOf(time)
        );

        pst.setString(
                6,
                status
        );

        pst.executeUpdate();

        ResultSet generatedKeys =
                pst.getGeneratedKeys();

        int appointmentId = 0;

        if (generatedKeys.next()) {

            appointmentId =
                    generatedKeys.getInt(1);

            txtAppointmentId.setText(
                    String.valueOf(appointmentId)
            );
        }

        generatedKeys.close();
        pst.close();

        String serviceSql =
                "INSERT INTO appointment_services "
                + "(appointment_id, service_id) "
                + "VALUES (?, ?)";

        PreparedStatement servicePst =
                con.prepareStatement(serviceSql);

        for (int index : selectedIndices) {

            int serviceId =
                    serviceIds.get(index);

            servicePst.setInt(
                    1,
                    appointmentId
            );

            servicePst.setInt(
                    2,
                    serviceId
            );

            servicePst.executeUpdate();
        }

        servicePst.close();

        if ("Pending".equalsIgnoreCase(status)) {
            appointmentQueue.offer(appointmentId);
        }

        con.close();

        loadAppointments();

        JOptionPane.showMessageDialog(
                this,
                "Appointment added successfully!\n\n"
                + "Estimated schedule: "
                + time.format(
                        java.time.format.DateTimeFormatter
                                .ofPattern("hh:mm a")
                )
                + " - "
                + endTime.format(
                        java.time.format.DateTimeFormatter
                                .ofPattern("hh:mm a")
                )
                + "\n"
                + "Duration: "
                + durationMinutes
                + " minutes",
                "Success",
                JOptionPane.INFORMATION_MESSAGE
        );

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error adding appointment:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnAddActionPerformed

    private void tblAppointmentsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblAppointmentsMouseClicked
                                        
    int selectedRow = tblAppointments.getSelectedRow();

    if (selectedRow == -1) {
        return;
    }

    DefaultTableModel model =
            (DefaultTableModel) tblAppointments.getModel();
    String appointmentId =
            model.getValueAt(selectedRow, 0).toString();

    String petId = "";
    String groomerId = "";

    try (Connection lookupCon = DBConnection.getConnection();
         PreparedStatement lookupPst = lookupCon.prepareStatement(
                 "SELECT pet_id, groomer_id FROM appointments "
               + "WHERE appointment_id = ?")) {

        lookupPst.setInt(1, Integer.parseInt(appointmentId));

        try (ResultSet lookupRs = lookupPst.executeQuery()) {

            if (lookupRs.next()) {
                petId = lookupRs.getString("pet_id");
                groomerId = lookupRs.getString("groomer_id");
            }
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    if (petId == null) {
        petId = "";
    }

    if (groomerId == null) {
        groomerId = "";
    }

    String date =
            model.getValueAt(selectedRow, 3).toString();

    String time =
            model.getValueAt(selectedRow, 4).toString();

    String status =
            model.getValueAt(selectedRow, 7).toString();
    txtAppointmentId.setText(appointmentId);

    txtDate.setText(date);

    if (dateChooser != null && !date.isEmpty()) {

        try {

            java.util.Date parsedDate =
                    new java.text.SimpleDateFormat(
                            "yyyy-MM-dd"
                    ).parse(date);

            dateChooser.setDate(parsedDate);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
    cmbTime.setSelectedIndex(-1);

    String selectedTime =
            convertTo12Hour(time);

    for (int i = 0;
            i < cmbTime.getItemCount();
            i++) {

        String comboTime =
                cmbTime.getItemAt(i);

        if (comboTime != null
                && comboTime.equalsIgnoreCase(selectedTime)) {

            cmbTime.setSelectedIndex(i);

            break;
        }
    }

    lstServices.clearSelection();


    try {

        Connection serviceCon =
                DBConnection.getConnection();

        if (serviceCon != null) {

            String serviceSql =
                    "SELECT aps.service_id "
                    + "FROM appointment_services aps "
                    + "WHERE aps.appointment_id = ?";


            PreparedStatement servicePst =
                    serviceCon.prepareStatement(
                            serviceSql
                    );


            servicePst.setInt(
                    1,
                    Integer.parseInt(appointmentId)
            );


            ResultSet serviceRs =
                    servicePst.executeQuery();


            while (serviceRs.next()) {

                int serviceId =
                        serviceRs.getInt(
                                "service_id"
                        );

                int serviceIndex =
                        serviceIds.indexOf(serviceId);


                if (serviceIndex >= 0) {

                    lstServices.addSelectionInterval(
                            serviceIndex,
                            serviceIndex
                    );
                }
            }


            serviceRs.close();
            servicePst.close();
            serviceCon.close();
        }


    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error loading services:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
        int groomerPosition = groomerIds.indexOf(groomerId);

    if (groomerPosition > 0) {
        cmbGroomer.setSelectedIndex(groomerPosition);
    } else {
        cmbGroomer.setSelectedIndex(0);
    }

    cmbStatus.setSelectedItem(status);
    try {

        Connection con =
                DBConnection.getConnection();

        if (con == null) {

            return;
        }


        String sql =
                "SELECT p.customer_id, "
                + "c.first_name, "
                + "c.last_name, "
                + "p.pet_name "
                + "FROM pets p "
                + "JOIN customers c "
                + "ON p.customer_id = c.customer_id "
                + "WHERE p.pet_id = ?";


        PreparedStatement pst =
                con.prepareStatement(sql);


        pst.setString(
                1,
                petId
        );


        ResultSet rs =
                pst.executeQuery();


        if (rs.next()) {

            String customerId =
                    rs.getString("customer_id");

            String firstName =
                    rs.getString("first_name");

            String lastName =
                    rs.getString("last_name");

            String petName =
                    rs.getString("pet_name");

            String customerName =
                    customerId
                    + " - "
                    + firstName
                    + " "
                    + lastName;


            cmbCustomer.removeAllItems();

            cmbCustomer.addItem(
                    customerName
            );

            cmbCustomer.setSelectedItem(
                    customerName
            );

            String petDisplay =
                    petId
                    + " - "
                    + petName;


            cmbPet.removeAllItems();

            cmbPet.addItem(
                    petDisplay
            );

            cmbPet.setSelectedItem(
                    petDisplay
            );
        }


        rs.close();
        pst.close();
        con.close();


    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error loading appointment details:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_tblAppointmentsMouseClicked

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
                         
    int selectedRow = tblAppointments.getSelectedRow();
 
    if (selectedRow == -1) {
 
        JOptionPane.showMessageDialog(
                this,
                "Please select an appointment to update.",
                "No Selection",
                JOptionPane.WARNING_MESSAGE
        );
 
        return;
    }
    String appointmentIdText =
            txtAppointmentId.getText().trim();
 
    if (appointmentIdText.isEmpty()) {
 
        JOptionPane.showMessageDialog(
                this,
                "Appointment ID is missing.",
                "Validation Error",
                JOptionPane.WARNING_MESSAGE
        );
 
        return;
    }
 
    int appointmentId;
 
    try {
 
        appointmentId =
                Integer.parseInt(appointmentIdText);
 
    } catch (NumberFormatException e) {
 
        JOptionPane.showMessageDialog(
                this,
                "Invalid Appointment ID.",
                "Validation Error",
                JOptionPane.WARNING_MESSAGE
        );
 
        return;
    }
 
    Object selectedPetObject =
            cmbPet.getSelectedItem();
 
    if (selectedPetObject == null
            || selectedPetObject.toString().trim().isEmpty()
            || selectedPetObject.toString()
                    .equalsIgnoreCase("Choose Pet")) {
 
        JOptionPane.showMessageDialog(
                this,
                "Please select a pet.",
                "Missing Pet",
                JOptionPane.WARNING_MESSAGE
        );
 
        return;
    }
 
 
    String petItem =
            cmbPet.getSelectedItem().toString();
 
    String petId =
            petItem.split(" - ")[0]
                    .trim()
                    .toUpperCase();
 
    String dateText =
            txtDate.getText().trim();
 
    if (dateText.isEmpty()) {
 
        JOptionPane.showMessageDialog(
                this,
                "Please select an appointment date.",
                "Missing Date",
                JOptionPane.WARNING_MESSAGE
        );
 
        return;
    }
 
 
    java.time.LocalDate date;
 
    try {
 
        date =
                java.time.LocalDate.parse(dateText);
 
    } catch (java.time.format.DateTimeParseException e) {
 
        JOptionPane.showMessageDialog(
                this,
                "Invalid date. Use yyyy-MM-dd.",
                "Invalid Date",
                JOptionPane.WARNING_MESSAGE
        );
 
        return;
    }
 
    if (date.isBefore(java.time.LocalDate.now())) {
 
        JOptionPane.showMessageDialog(
                this,
                "The appointment date cannot be in the past.",
                "Invalid Date",
                JOptionPane.WARNING_MESSAGE
        );
 
        return;
    }
 
    if (cmbTime.getSelectedIndex() <= 0) {
 
        JOptionPane.showMessageDialog(
                this,
                "Please select an appointment time.",
                "Missing Time",
                JOptionPane.WARNING_MESSAGE
        );
 
        cmbTime.requestFocus();
 
        return;
    }
 
 
    String timeText =
            cmbTime.getSelectedItem().toString();
 
    java.time.LocalTime time;
 
    try {
 
        java.time.format.DateTimeFormatter formatter =
                java.time.format.DateTimeFormatter.ofPattern(
                        "hh:mm a"
                );
 
        time =
                java.time.LocalTime.parse(
                        timeText,
                        formatter
                );
 
    } catch (java.time.format.DateTimeParseException e) {
 
        JOptionPane.showMessageDialog(
                this,
                "Invalid appointment time.",
                "Invalid Time",
                JOptionPane.WARNING_MESSAGE
        );
 
        cmbTime.requestFocus();
 
        return;
    }
    int[] selectedIndices =
            lstServices.getSelectedIndices();
 
    if (selectedIndices.length == 0) {
 
        JOptionPane.showMessageDialog(
                this,
                "Please select at least one grooming service.",
                "Missing Service",
                JOptionPane.WARNING_MESSAGE
        );
 
        return;
    }
    int firstServiceId =
        serviceIds.get(selectedIndices[0]);
 
int durationMinutes =
        getSelectedServicesDuration();
 
if (durationMinutes <= 0) {
 
    JOptionPane.showMessageDialog(
            this,
            "The selected services have no valid duration.",
            "Invalid Duration",
            JOptionPane.WARNING_MESSAGE
    );
 
    return;
}
 
 
java.time.LocalTime endTime =
        time.plusMinutes(durationMinutes);
 
 
if (overlapsLunchBreak(time, durationMinutes)) {
 
    JOptionPane.showMessageDialog(
            this,
            "The selected appointment overlaps "
            + "the groomer's lunch break "
            + "(12:00 PM - 1:00 PM).\n\n"
            + "Please select an appointment time "
            + "before 12:00 PM or from 1:00 PM onwards.",
            "Lunch Break",
            JOptionPane.WARNING_MESSAGE
    );
 
    return;
}
 
java.time.LocalTime closingTime =
        java.time.LocalTime.of(18, 0);
 
if (endTime.isAfter(closingTime)) {
 
    JOptionPane.showMessageDialog(
            this,
            "The selected services would end at "
            + endTime.format(
                    java.time.format.DateTimeFormatter
                            .ofPattern("hh:mm a")
            )
            + ".\n\n"
            + "Appointments must be completed by 6:00 PM.\n"
            + "Please select an earlier appointment time.",
            "Outside Operating Hours",
            JOptionPane.WARNING_MESSAGE
    );
 
    return;
}
 
 
if (cmbGroomer.getSelectedIndex() <= 0) {
 
        JOptionPane.showMessageDialog(
                this,
                "Please select a groomer.",
                "Missing Groomer",
                JOptionPane.WARNING_MESSAGE
        );
 
        cmbGroomer.requestFocus();
 
        return;
    }
 
 
    int groomerIndex =
            cmbGroomer.getSelectedIndex();
 
    String groomerId =
            groomerIds.get(groomerIndex);
 
 
if (!isGroomerAvailable(
        groomerId,
        date,
        time,
        durationMinutes,
        appointmentId)) {
 
    JOptionPane.showMessageDialog(
            this,
            "The selected groomer is already "
            + "booked during this time.\n\n"
            + "Estimated schedule: "
            + time.format(
                    java.time.format.DateTimeFormatter
                            .ofPattern("hh:mm a")
            )
            + " - "
            + endTime.format(
                    java.time.format.DateTimeFormatter
                            .ofPattern("hh:mm a")
            )
            + "\n\n"
            + "Please select another groomer or time.",
            "Groomer Unavailable",
            JOptionPane.WARNING_MESSAGE
    );
 
    return;
}
 
    if (!confirmGroomerSpecialization(groomerId, selectedIndices)) {
        return;
    }
    if (cmbStatus.getSelectedIndex() <= 0) {
 
        JOptionPane.showMessageDialog(
                this,
                "Please select an appointment status.",
                "Missing Status",
                JOptionPane.WARNING_MESSAGE
        );
 
        return;
    }
 
 
    String status =
            cmbStatus.getSelectedItem().toString();
    int confirm =
            JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to update this appointment?",
                    "Confirm Update",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );
 
    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }
    try {
 
        Connection con =
                DBConnection.getConnection();
 
        if (con == null) {
 
            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
 
            return;
        }
 
        String petSql =
                "SELECT pet_id "
                + "FROM pets "
                + "WHERE pet_id = ?";
 
 
        PreparedStatement petPst =
                con.prepareStatement(petSql);
 
        petPst.setString(
                1,
                petId
        );
 
 
        ResultSet petRs =
                petPst.executeQuery();
 
 
        if (!petRs.next()) {
 
            JOptionPane.showMessageDialog(
                    this,
                    "Pet ID not found.",
                    "Pet Not Found",
                    JOptionPane.WARNING_MESSAGE
            );
 
            petRs.close();
            petPst.close();
            con.close();
 
            return;
        }
 
 
        petRs.close();
        petPst.close();
        String duplicateSql =
                "SELECT COUNT(*) "
                + "FROM appointments "
                + "WHERE pet_id = ? "
                + "AND appointment_date = ? "
                + "AND appointment_time = ? "
                + "AND status <> 'Cancelled' "
                + "AND appointment_id <> ?";
 
 
        PreparedStatement duplicatePst =
                con.prepareStatement(duplicateSql);
 
 
        duplicatePst.setString(
                1,
                petId
        );
 
        duplicatePst.setDate(
                2,
                java.sql.Date.valueOf(date)
        );
 
        duplicatePst.setTime(
                3,
                java.sql.Time.valueOf(time)
        );
 
        duplicatePst.setInt(
                4,
                appointmentId
        );
 
 
        ResultSet duplicateRs =
                duplicatePst.executeQuery();
 
 
        if (duplicateRs.next()
                && duplicateRs.getInt(1) > 0) {
 
            JOptionPane.showMessageDialog(
                    this,
                    "This pet already has another appointment at that date and time.",
                    "Duplicate Appointment",
                    JOptionPane.WARNING_MESSAGE
            );
 
            duplicateRs.close();
            duplicatePst.close();
            con.close();
 
            return;
        }
 
 
        duplicateRs.close();
        duplicatePst.close();
 
        String sql =
                "UPDATE appointments "
                + "SET pet_id = ?, "
                + "service_id = ?, "
                + "groomer_id = ?, "
                + "appointment_date = ?, "
                + "appointment_time = ?, "
                + "status = ? "
                + "WHERE appointment_id = ?";
 
 
        PreparedStatement pst =
                con.prepareStatement(sql);
 
 
        pst.setString(
                1,
                petId
        );
 
        pst.setInt(
                2,
                firstServiceId
        );
 
        pst.setString(
                3,
                groomerId
        );
 
        pst.setDate(
                4,
                java.sql.Date.valueOf(date)
        );
 
        pst.setTime(
                5,
                java.sql.Time.valueOf(time)
        );
 
        pst.setString(
                6,
                status
        );
 
        pst.setInt(
                7,
                appointmentId
        );
 
 
        int rowsUpdated =
                pst.executeUpdate();
 
 
        pst.close();
        if (rowsUpdated > 0) {
 
 
            String deleteServicesSql =
                    "DELETE FROM appointment_services "
                    + "WHERE appointment_id = ?";
 
 
            PreparedStatement deletePst =
                    con.prepareStatement(
                            deleteServicesSql
                    );
            deletePst.setInt(
                    1,
                    appointmentId
            );
 
 
            deletePst.executeUpdate();
 
            deletePst.close();
 
            String insertServiceSql =
                    "INSERT INTO appointment_services "
                    + "(appointment_id, service_id) "
                    + "VALUES (?, ?)";
 
 
            PreparedStatement insertServicePst =
                    con.prepareStatement(
                            insertServiceSql
                    );
 
 
            for (int index : selectedIndices) {
 
                int selectedServiceId =
                        serviceIds.get(index);
 
 
                insertServicePst.setInt(
                        1,
                        appointmentId
                );
 
                insertServicePst.setInt(
                        2,
                        selectedServiceId
                );
 
 
                insertServicePst.executeUpdate();
            }
 
 
            insertServicePst.close();
        }
 
        con.close();
        if (rowsUpdated > 0) {
            loadAppointments();
 
 
            JOptionPane.showMessageDialog(
                    this,
                    "Appointment updated successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );
 
 
        } else {
 
            JOptionPane.showMessageDialog(
                    this,
                    "No record was updated.",
                    "Update Failed",
                    JOptionPane.WARNING_MESSAGE
            );
        }
 
 
    } catch (Exception e) {
 
        e.printStackTrace();
 
        JOptionPane.showMessageDialog(
                this,
                "Error updating appointment:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnArchieveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchieveActionPerformed

    int selectedRow =
            tblAppointments.getSelectedRow();
 
    if (selectedRow == -1) {
 
        JOptionPane.showMessageDialog(
                this,
                "Please select an appointment to archive.",
                "No Selection",
                JOptionPane.WARNING_MESSAGE
        );
 
        return;
    }
 
    DefaultTableModel model =
            (DefaultTableModel) tblAppointments.getModel();
 
    if (model.getValueAt(selectedRow, 0) == null) {
        return;
    }
 
    int appointmentId =
            Integer.parseInt(
                    model.getValueAt(selectedRow, 0).toString()
            );
 
        String petId =
            model.getValueAt(selectedRow, 2).toString();  

    String currentStatus =
            model.getValueAt(selectedRow, 7).toString();
 
 
    if (currentStatus.equalsIgnoreCase("Archived")) {
 
        JOptionPane.showMessageDialog(
                this,
                "This appointment is already archived.",
                "Already Archived",
                JOptionPane.INFORMATION_MESSAGE
        );
 
        return;
    }
 
 
    int confirm =
            JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to archive the appointment of pet "
                    + petId + "?",
                    "Confirm Archive",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );
 
    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }
 
 
    try {
 
        Connection con =
                DBConnection.getConnection();
 
        if (con == null) {
 
            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
 
            return;
        }
 
 
        String sql =
                "UPDATE appointments "
                + "SET status = ? "
                + "WHERE appointment_id = ?";
 
        PreparedStatement pst =
                con.prepareStatement(sql);
 
        pst.setString(1, "Archived");
        pst.setInt(2, appointmentId);
 
        int rowsUpdated =
                pst.executeUpdate();
 
        pst.close();
        con.close();
 
 
        if (rowsUpdated > 0) {
 
            loadAppointments();
 
            cmbStatus.setSelectedItem("Archived");
 
            JOptionPane.showMessageDialog(
                    this,
                    "Appointment archived successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );
 
        } else {
 
            JOptionPane.showMessageDialog(
                    this,
                    "No record was archived.",
                    "Archive Failed",
                    JOptionPane.WARNING_MESSAGE
            );
        }
 
    } catch (Exception e) {
 
        e.printStackTrace();
 
        JOptionPane.showMessageDialog(
                this,
                "Error archiving appointment:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnArchieveActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed


    txtAppointmentId.setText("");
    txtCustomerSearch.setText("");
    txtDate.setText("");
    txtSearch.setText("");
    cmbTime.setSelectedIndex(0);
    cmbGroomer.setSelectedIndex(0);
 
    if (dateChooser != null) {
        dateChooser.setDate(null);
    }
    cmbCustomer.removeAllItems();
 
    cmbCustomer.addItem(
            "Choose Customer"
    );
 
    cmbPet.removeAllItems();
 
    cmbPet.addItem(
            "Choose Pet"
    );
 
    lstServices.clearSelection();
    cmbStatus.setSelectedIndex(0);
    tblAppointments.clearSelection();
    loadAppointments();
    txtCustomerSearch.requestFocus();
    }//GEN-LAST:event_btnClearActionPerformed

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed

    String keyword = txtSearch.getText().trim();

    DefaultTableModel model =
            (DefaultTableModel) tblAppointments.getModel();

    model.setRowCount(0);

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        String sql =
                "SELECT a.appointment_id, "
                + "a.pet_id, "
                + "a.appointment_date, "
                + "a.appointment_time, "
                + "GROUP_CONCAT("
                + "DISTINCT s.service_name "
                + "ORDER BY s.service_name "
                + "SEPARATOR ', '"
                + ") AS service_names, "
                + "CONCAT("
                + "g.groomer_id, ' - ', "
                + "g.first_name, ' ', "
                + "g.last_name"
                + ") AS groomer_name, "
                + "a.status "
                + "FROM appointments a "
                + "LEFT JOIN appointment_services aps "
                + "ON a.appointment_id = aps.appointment_id "
                + "LEFT JOIN grooming_services s "
                + "ON aps.service_id = s.service_id "
                + "LEFT JOIN groomers g "
                + "ON a.groomer_id = g.groomer_id "
                + "WHERE CAST(a.appointment_id AS CHAR) LIKE ? "
                + "OR a.pet_id LIKE ? "
                + "OR CAST(a.appointment_date AS CHAR) LIKE ? "
                + "OR CAST(a.appointment_time AS CHAR) LIKE ? "
                + "OR s.service_name LIKE ? "
                + "OR g.groomer_id LIKE ? "
                + "OR CONCAT("
                + "g.first_name, ' ', g.last_name"
                + ") LIKE ? "
                + "OR a.status LIKE ? "
                + "GROUP BY "
                + "a.appointment_id, "
                + "a.pet_id, "
                + "a.appointment_date, "
                + "a.appointment_time, "
                + "g.groomer_id, "
                + "g.first_name, "
                + "g.last_name, "
                + "a.status "
                + "ORDER BY "
                + "a.appointment_date ASC, "
                + "a.appointment_time ASC";

        PreparedStatement pst =
                con.prepareStatement(sql);

        String like =
                "%" + keyword + "%";

        pst.setString(1, like);
        pst.setString(2, like);
        pst.setString(3, like);
        pst.setString(4, like);
        pst.setString(5, like);
        pst.setString(6, like);
        pst.setString(7, like);
        pst.setString(8, like);

        ResultSet rs =
                pst.executeQuery();

        int count = 0;

        while (rs.next()) {

            String groomerName =
                    rs.getString("groomer_name");

            if (groomerName == null) {
                groomerName = "Not Assigned";
            }

            String serviceNames =
                    rs.getString("service_names");

            if (serviceNames == null
                    || serviceNames.trim().isEmpty()) {

                serviceNames = "No Service";
            }

            model.addRow(
                    new Object[]{
                        rs.getInt("appointment_id"),
                        rs.getString("pet_id"),
                        rs.getString("appointment_date"),
                        rs.getString("appointment_time")
                                .substring(0, 5),
                        serviceNames,
                        groomerName,
                        rs.getString("status")
                    }
            );

            count++;
        }

        rs.close();
        pst.close();
        con.close();

        if (count == 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "No appointment found.",
                    "Search Result",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error searching appointments:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_txtSearchActionPerformed

    private void cmbStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbStatusActionPerformed

    }//GEN-LAST:event_cmbStatusActionPerformed

    private void btnSearchCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchCustomerActionPerformed

    String keyword = txtCustomerSearch.getText().trim();

    if (keyword.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "Please enter a Customer ID or customer name.",
                "Search Customer",
                JOptionPane.WARNING_MESSAGE
        );

        txtCustomerSearch.requestFocus();

        return;
    }

    cmbCustomer.removeAllItems();
    cmbPet.removeAllItems();

    cmbCustomer.addItem("Choose Customer");

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        
String sql =
        "SELECT customer_id, first_name, last_name "
        + "FROM customers "
        + "WHERE status = 'Active' "
        + "AND (LOWER(customer_id) LIKE ? "
        + "OR LOWER(first_name) LIKE ? "
        + "OR LOWER(last_name) LIKE ? "
        + "OR LOWER(CONCAT(first_name, ' ', last_name)) LIKE ?) "
        + "ORDER BY LOWER(first_name), LOWER(last_name)";

        PreparedStatement pst =
                con.prepareStatement(sql);

        
String searchValue = "%"
        + keyword.toLowerCase(java.util.Locale.ROOT)
        + "%";

pst.setString(1, searchValue);
pst.setString(2, searchValue);
pst.setString(3, searchValue);
pst.setString(4, searchValue);


        ResultSet rs = pst.executeQuery();

        int count = 0;

        while (rs.next()) {

            String customerId =
                    rs.getString("customer_id");

            String firstName =
                    rs.getString("first_name");

            String lastName =
                    rs.getString("last_name");

            cmbCustomer.addItem(
                    customerId
                    + " - "
                    + firstName
                    + " "
                    + lastName
            );

            count++;
        }

        rs.close();
        pst.close();
        con.close();

        if (count == 0) {

            cmbCustomer.removeAllItems();
            cmbCustomer.addItem("Choose Customer");

            JOptionPane.showMessageDialog(
                    this,
                    "No active customer found.",
                    "Search Result",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } else {

            cmbCustomer.setSelectedIndex(1);

            JOptionPane.showMessageDialog(
                    this,
                    count + " customer(s) found.",
                    "Search Result",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error searching customer:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnSearchCustomerActionPerformed

    private void cmbCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCustomerActionPerformed

    cmbPet.removeAllItems();

    cmbPet.addItem("Choose Pet");

    if (cmbCustomer.getSelectedIndex() <= 0) {
        return;
    }

    String customerItem =
            cmbCustomer.getSelectedItem().toString();

    String customerId =
            customerItem.split(" - ")[0].trim().toUpperCase();

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        String sql =
                "SELECT pet_id, pet_name "
                + "FROM pets "
                + "WHERE customer_id = ? "
                + "ORDER BY pet_name";

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setString(1, customerId);

        ResultSet rs = pst.executeQuery();

        int count = 0;

        while (rs.next()) {

            String petId =
                    rs.getString("pet_id");

            String petName =
                    rs.getString("pet_name");

            cmbPet.addItem(
                    petId + " - " + petName
            );

            count++;
        }

        rs.close();
        pst.close();
        con.close();

        if (count == 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "This customer has no registered pets.",
                    "No Pets Found",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error loading pets:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_cmbCustomerActionPerformed

    private void btnProcessNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProcessNextActionPerformed
  

    if (appointmentQueue.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "There are no appointments in the queue.",
                "Queue Empty",
                JOptionPane.INFORMATION_MESSAGE
        );

        return;
    }

    int appointmentId = appointmentQueue.peek();

    java.math.BigDecimal total =
            new service.PaymentService().getAppointmentTotal(appointmentId);

    java.math.BigDecimal requiredDown =
            total.multiply(DOWNPAYMENT_RATE)
                 .setScale(2, java.math.RoundingMode.HALF_UP);

    java.math.BigDecimal paid = getAmountPaid(appointmentId);

    if (paid.compareTo(requiredDown) < 0) {

        JOptionPane.showMessageDialog(
                this,
                "Appointment #" + appointmentId
                + " has no sufficient downpayment yet.\n\n"
                + "Required downpayment (50%): ₱" + requiredDown + "\n"
                + "Paid so far: ₱" + paid + "\n\n"
                + "Please click \"Proceed to Payment\" first.",
                "Downpayment Required",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }


    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Start grooming for appointment #" + appointmentId + "?\n"
            + "The appointment status will change from Pending to In Progress.",
            "Start Grooming",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    String sql =
            "UPDATE appointments "
            + "SET status = 'In Progress' "
            + "WHERE appointment_id = ? AND status = 'Pending'";

    try (Connection con = DBConnection.getConnection()) {

        if (con == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        try (PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, appointmentId);

            int rowsUpdated = pst.executeUpdate();

            if (rowsUpdated > 0) {

                appointmentQueue.poll();

                loadAppointments();

                JOptionPane.showMessageDialog(
                        this,
                        "Appointment #" + appointmentId
                        + " is now In Progress.\n"
                        + "The pet is currently being groomed.",
                        "Grooming Started",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } else {

                loadAppointments();

                JOptionPane.showMessageDialog(
                        this,
                        "This appointment is no longer Pending.\n"
                        + "The queue has been refreshed.",
                        "Queue Updated",
                        JOptionPane.WARNING_MESSAGE
                );
            }
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error starting grooming:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }
    private static final java.math.BigDecimal DOWNPAYMENT_RATE =
            new java.math.BigDecimal("0.50");

    private java.math.BigDecimal getAmountPaid(int appointmentId) {

        String sql =
                "SELECT COALESCE(SUM(amount_paid), 0) AS paid "
              + "FROM payments "
              + "WHERE appointment_id = ? "
              + "AND (payment_status IS NULL OR payment_status <> 'Archived')";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, appointmentId);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return rs.getBigDecimal("paid");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return java.math.BigDecimal.ZERO;
    }//GEN-LAST:event_btnProcessNextActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        MainFrame main = new MainFrame();
        main.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnGroomingCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGroomingCheckActionPerformed
int selectedRow = tblAppointments.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(
                this,
                "Please select an appointment first.",
                "Grooming Check",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    DefaultTableModel model =
            (DefaultTableModel) tblAppointments.getModel();

    String appointmentId =
            model.getValueAt(selectedRow, 0).toString();

    GroomingCheckFrame groomingCheck =
            new GroomingCheckFrame(appointmentId);

    groomingCheck.setVisible(true);
    }//GEN-LAST:event_btnGroomingCheckActionPerformed

    private void btnProceedPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProceedPaymentActionPerformed
                                              
    int row = tblAppointments.getSelectedRow();

    if (row == -1) {

        JOptionPane.showMessageDialog(
            this,
            "Please select an appointment first.",
            "Payment",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    int appointmentId =
            Integer.parseInt(
                tblAppointments.getValueAt(row, 0).toString()
            );

    PaymentFrame paymentFrame =
            new PaymentFrame(appointmentId);

    paymentFrame.setVisible(true);

    this.dispose();
    }//GEN-LAST:event_btnProceedPaymentActionPerformed

    private void txtCustomerSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCustomerSearchActionPerformed

    }//GEN-LAST:event_txtCustomerSearchActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed

    String keyword = txtSearch.getText().trim();

    if (keyword.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "Please enter an Appointment ID, Customer ID, "
                + "Customer Name, or Pet Name.",
                "Search Appointment",
                JOptionPane.WARNING_MESSAGE
        );
        txtSearch.requestFocus();
        return;
    }

    String sql =
            "SELECT a.appointment_id, "
          + "CONCAT(c.first_name, ' ', c.last_name) AS customer_name, "
          + "p.pet_name, "
          + "a.appointment_date, "
          + "a.appointment_time, "
          + "GROUP_CONCAT(DISTINCT gs.service_name "
          + "SEPARATOR ', ') AS services, "
          + "CONCAT(g.first_name, ' ', g.last_name) AS groomer, "
          + "a.status "
          + "FROM appointments a "
          + "LEFT JOIN pets p ON a.pet_id = p.pet_id "
          + "LEFT JOIN customers c ON p.customer_id = c.customer_id "
          + "LEFT JOIN appointment_services aps "
          + "ON a.appointment_id = aps.appointment_id "
          + "LEFT JOIN grooming_services gs "
          + "ON aps.service_id = gs.service_id "
          + "LEFT JOIN groomers g ON a.groomer_id = g.groomer_id "
          + "WHERE CAST(a.appointment_id AS CHAR) LIKE ? "
          + "OR a.pet_id LIKE ? "
          + "OR c.customer_id LIKE ? "
          + "OR CONCAT(c.first_name, ' ', c.last_name) LIKE ? "
          + "OR p.pet_name LIKE ? "
          + "GROUP BY a.appointment_id "
          + "ORDER BY a.appointment_date DESC, a.appointment_time DESC";

    java.util.List<Object[]> results = new java.util.ArrayList<>();
    boolean hasPastAppointment = false;
    boolean customerExists = false;

    try (Connection con = DBConnection.getConnection()) {

        if (con == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        String searchValue = "%" + keyword + "%";

        try (PreparedStatement pst = con.prepareStatement(sql)) {

            for (int i = 1; i <= 5; i++) {
                pst.setString(i, searchValue);
            }

            try (ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {

                    java.sql.Date appointmentDate =
                            rs.getDate("appointment_date");

                    if (appointmentDate != null
                            && appointmentDate.before(
                                    new java.sql.Date(
                                            System.currentTimeMillis()))) {
                        hasPastAppointment = true;
                    }

                    java.sql.Time appointmentTime =
                            rs.getTime("appointment_time");

                    String timeText = appointmentTime == null
                            ? ""
                            : appointmentTime.toString().substring(0, 5);

                    String customerName =
                            rs.getString("customer_name");

                    String petName =
                            rs.getString("pet_name");

                    String groomerName =
                            rs.getString("groomer");

                    String serviceNames =
                            rs.getString("services");

                    results.add(new Object[]{
                        rs.getInt("appointment_id"),
                        customerName == null ? "Unknown Customer" : customerName,
                        petName == null ? "Unknown Pet" : petName,
                        appointmentDate,
                        timeText,
                        serviceNames == null ? "No Service" : serviceNames,
                        groomerName == null ? "Not Assigned" : groomerName,
                        rs.getString("status")
                    });
                }
            }
        }

        if (results.isEmpty()) {

            String customerSql =
                    "SELECT COUNT(*) FROM customers "
                  + "WHERE customer_id LIKE ? "
                  + "OR CONCAT(first_name, ' ', last_name) LIKE ?";

            try (PreparedStatement pst =
                    con.prepareStatement(customerSql)) {

                pst.setString(1, searchValue);
                pst.setString(2, searchValue);

                try (ResultSet rs = pst.executeQuery()) {
                    if (rs.next()) {
                        customerExists = rs.getInt(1) > 0;
                    }
                }
            }

            if (customerExists) {
                JOptionPane.showMessageDialog(
                        this,
                        "Customer found, but no appointment records "
                        + "match your search.",
                        "No Appointment Found",
                        JOptionPane.INFORMATION_MESSAGE
                );
            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "No matching customer or appointment was found.",
                        "Search Result",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }

            return;
        }

        if (hasPastAppointment) {

            int choice = JOptionPane.showConfirmDialog(
                    this,
                    "Past appointment record(s) were found.\n"
                    + "Do you want to display the matching records, "
                    + "including past appointments?",
                    "View Past Appointments",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );

            if (choice != JOptionPane.YES_OPTION) {
                return;
            }
        }

        DefaultTableModel model =
                (DefaultTableModel) tblAppointments.getModel();

        model.setRowCount(0);

        for (Object[] row : results) {
            model.addRow(row);
        }

        tblAppointments.revalidate();
        tblAppointments.repaint();

        JOptionPane.showMessageDialog(
                this,
                results.size() + " matching appointment(s) found.",
                "Search Result",
                JOptionPane.INFORMATION_MESSAGE
        );

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error searching appointments:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnCompleteGroomingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCompleteGroomingActionPerformed

    int selectedRow = tblAppointments.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(
                this,
                "Please select an appointment first.",
                "No Appointment Selected",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    int modelRow = tblAppointments.convertRowIndexToModel(selectedRow);

    int appointmentId = Integer.parseInt(
            tblAppointments.getModel()
                    .getValueAt(modelRow, 0).toString()
    );

    String status = tblAppointments.getModel()
            .getValueAt(modelRow, 7).toString();

    if (!"In Progress".equalsIgnoreCase(status)) {
        JOptionPane.showMessageDialog(
                this,
                "Only appointments with In Progress status "
                + "can be marked as Completed.",
                "Invalid Appointment Status",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure grooming is finished for appointment #"
            + appointmentId + "?",
            "Complete Grooming",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    String sql =
            "UPDATE appointments "
            + "SET status = 'Completed' "
            + "WHERE appointment_id = ? "
            + "AND status = 'In Progress'";

    try (Connection con = DBConnection.getConnection()) {

        if (con == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        try (PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, appointmentId);

            int rowsUpdated = pst.executeUpdate();

            if (rowsUpdated > 0) {

                loadAppointments();

                JOptionPane.showMessageDialog(
                        this,
                        "Grooming for appointment #"
                        + appointmentId
                        + " has been completed!",
                        "Grooming Completed",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } else {
                loadAppointments();

                JOptionPane.showMessageDialog(
                        this,
                        "The appointment status has changed. "
                        + "Please refresh and try again.",
                        "Update Failed",
                        JOptionPane.WARNING_MESSAGE
                );
            }
        }

    } catch (Exception e) {
        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error completing grooming:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    }//GEN-LAST:event_btnCompleteGroomingActionPerformed
private void loadStatusToCombo() {

    cmbStatus.setModel(
        new javax.swing.DefaultComboBoxModel<>(
            new String[] {
                "Choose Status",
                "Pending",
                "Completed",
                "Cancelled",
                "Archived"
            }
        )
    );
}

private void loadServicesToList() {

    serviceIds.clear();

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        String sql =
                "SELECT service_id, service_name "
              + "FROM grooming_services "
              + "WHERE status = 'Active' "
              + "ORDER BY service_name";

        PreparedStatement pst =
                con.prepareStatement(sql);

        ResultSet rs =
                pst.executeQuery();

        javax.swing.DefaultListModel<String> listModel =
                new javax.swing.DefaultListModel<>();

        while (rs.next()) {

            int serviceId =
                    rs.getInt("service_id");

            String serviceName =
                    rs.getString("service_name");

            serviceIds.add(serviceId);

            listModel.addElement(serviceName);
        }

        lstServices.setModel(listModel);

        lstServices.setSelectionMode(
                javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION
        );

        rs.close();
        pst.close();
        con.close();

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error loading services:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadGroomersToCombo() {

    cmbGroomer.removeAllItems();
    groomerIds.clear();
    groomerSpecializations.clear();

    cmbGroomer.addItem("Choose Groomer");
    groomerIds.add("");

    try {

        Connection con = DBConnection.getConnection();

        if (con == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        String sql =
                "SELECT groomer_id, first_name, last_name, specialization "
              + "FROM groomers "
              + "WHERE status = 'Active' "
              + "ORDER BY first_name, last_name";

        PreparedStatement pst =
                con.prepareStatement(sql);

        ResultSet rs =
                pst.executeQuery();

        while (rs.next()) {

            String groomerId =
                    rs.getString("groomer_id");

            String firstName =
                    rs.getString("first_name");

            String lastName =
                    rs.getString("last_name");

            String specialization =
                    rs.getString("specialization");

            if (specialization == null) {
                specialization = "";
            }

            String groomerName =
                    groomerId
                    + " - "
                    + firstName
                    + " "
                    + lastName;

            groomerIds.add(groomerId);
            cmbGroomer.addItem(groomerName);

            groomerSpecializations.put(groomerId, specialization.trim());
        }

        rs.close();
        pst.close();
        con.close();

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error loading groomers:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

private boolean groomerHandlesService(String specialization, String serviceName) {

    String spec = specialization.toLowerCase().trim();
    String service = serviceName.toLowerCase().trim();

    if (spec.contains("general") || spec.equals("all")
            || spec.contains("all service")) {
        return true;
    }

    java.util.List<String> ignore = java.util.Arrays.asList(
            "grooming", "groomer", "pet", "pets",
            "service", "services", "and"
    );

    String[] specWords = spec.split("[^a-z]+");
    String[] serviceWords = service.split("[^a-z]+");

    for (String s : specWords) {

        if (s.length() < 3 || ignore.contains(s)) {
            continue;
        }

        for (String w : serviceWords) {

                        if (w.length() < 3 || ignore.contains(w)) {
                continue;
            }

            if (s.contains(w) || w.contains(s)) {
                return true;
            }
        }
    }

    return false;
}

private boolean confirmGroomerSpecialization(String groomerId, int[] selectedIndices) {

    String specialization = groomerSpecializations.get(groomerId);

    if (specialization == null || specialization.trim().isEmpty()) {
        return true;
    }

    String notCovered = "";

    for (int i = 0; i < selectedIndices.length; i++) {

        String serviceName =
                lstServices.getModel()
                        .getElementAt(selectedIndices[i])
                        .toString();

        if (!groomerHandlesService(specialization, serviceName)) {
            notCovered = notCovered + "- " + serviceName + "\n";
        }
    }

    if (notCovered.isEmpty()) {
        return true;
    }

    int choice = JOptionPane.showConfirmDialog(
            this,
            "Groomer: " + cmbGroomer.getSelectedItem()
            + "\nSpecialization: " + specialization
            + "\n\nThis specialization does not clearly cover:\n"
            + notCovered
            + "\nDo you still want to assign this groomer?",
            "Groomer Specialization",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
    );

    return choice == JOptionPane.YES_OPTION;
}
private void updateGroomerAvailabilityDisplay() {

    if (updatingGroomerAvailability) {
        return;
    }

    updatingGroomerAvailability = true;

    try {

        int selectedIndex =
                cmbGroomer.getSelectedIndex();

        String selectedGroomerId = "";

        if (selectedIndex > 0
                && selectedIndex < groomerIds.size()) {

            selectedGroomerId =
                    groomerIds.get(selectedIndex);
        }


        String dateText =
                txtDate.getText().trim();

        if (dateText.isEmpty()
                || cmbTime.getSelectedIndex() <= 0
                || lstServices.getSelectedIndices().length == 0) {

            return;
        }

        java.time.LocalDate date;

        try {

            date =
                    java.time.LocalDate.parse(dateText);

        } catch (Exception e) {

            return;
        }

        String timeText =
                cmbTime.getSelectedItem().toString();

        java.time.LocalTime time;

        try {

            java.time.format.DateTimeFormatter formatter =
                    java.time.format.DateTimeFormatter.ofPattern(
                            "hh:mm a"
                    );

            time =
                    java.time.LocalTime.parse(
                            timeText,
                            formatter
                    );

        } catch (Exception e) {

            return;
        }


        int durationMinutes =
                getSelectedServicesDuration();

        if (durationMinutes <= 0) {
            return;
        }


        int excludeAppointmentId = 0;

        try {

            if (!txtAppointmentId.getText()
                    .trim()
                    .isEmpty()) {

                excludeAppointmentId =
                        Integer.parseInt(
                                txtAppointmentId
                                        .getText()
                                        .trim()
                        );
            }

        } catch (NumberFormatException e) {

            excludeAppointmentId = 0;
        }


        java.util.ArrayList<String> ids =
                new java.util.ArrayList<>();

        java.util.ArrayList<String> names =
                new java.util.ArrayList<>();

        for (int i = 1;
                i < cmbGroomer.getItemCount();
                i++) {

            if (i < groomerIds.size()) {

                ids.add(
                        groomerIds.get(i)
                );

                String item =
                        cmbGroomer.getItemAt(i);

                int statusIndex =
                        item.indexOf("  ");

                if (statusIndex > 0) {

                    item =
                            item.substring(
                                    0,
                                    statusIndex
                            );
                }

                names.add(item);
            }
        }


        cmbGroomer.removeAllItems();

        cmbGroomer.addItem(
                "Choose Groomer"
        );

        groomerIds.clear();

        groomerIds.add("");


        for (int i = 0;
                i < ids.size();
                i++) {

            String groomerId =
                    ids.get(i);

            String groomerName =
                    names.get(i);

            String availabilityStatus;

            boolean available =
                    isGroomerAvailable(
                            groomerId,
                            date,
                            time,
                            durationMinutes,
                            excludeAppointmentId
                    );

            if (!available) {

                availabilityStatus =
                        "🔴 Busy";

            } else {

                boolean hasUpcoming =
                        hasUpcomingAppointment(
                                groomerId,
                                date,
                                time,
                                excludeAppointmentId
                        );

                if (hasUpcoming) {

                    availabilityStatus =
                            "🟡 Busy Soon";

                } else {

                    availabilityStatus =
                            "🟢 Available";
                }
            }

            groomerIds.add(
                    groomerId
            );

            cmbGroomer.addItem(
                    groomerName
                    + "  "
                    + availabilityStatus
            );
        }

        if (!selectedGroomerId.isEmpty()) {

            for (int i = 1;
                    i < groomerIds.size();
                    i++) {

                if (groomerIds.get(i)
                        .equals(selectedGroomerId)) {

                    cmbGroomer.setSelectedIndex(i);

                    break;
                }
            }
        }

    } catch (Exception e) {

        e.printStackTrace();

    } finally {

        updatingGroomerAvailability = false;
    }
}
private boolean hasUpcomingAppointment(
        String groomerId,
        java.time.LocalDate date,
        java.time.LocalTime selectedTime,
        int excludeAppointmentId) {

    String sql =
            "SELECT appointment_time "
          + "FROM appointments "
          + "WHERE groomer_id = ? "
          + "AND appointment_date = ? "
          + "AND status = 'Pending' "
          + "AND appointment_id <> ? "
          + "AND appointment_time > ? "
          + "ORDER BY appointment_time "
          + "LIMIT 1";

    try (
        Connection con = DBConnection.getConnection();
        PreparedStatement pst = con.prepareStatement(sql)
    ) {

        pst.setString(1, groomerId);

        pst.setDate(
                2,
                java.sql.Date.valueOf(date)
        );

        pst.setInt(
                3,
                excludeAppointmentId
        );

        pst.setTime(
                4,
                java.sql.Time.valueOf(selectedTime)
        );

        ResultSet rs =
                pst.executeQuery();

        return rs.next();

    } catch (Exception e) {

        e.printStackTrace();
        return false;
    }
}
private boolean isGroomerAvailable(
        String groomerId,
        java.time.LocalDate date,
        java.time.LocalTime startTime,
        int durationMinutes,
        int excludeAppointmentId) {

    java.time.LocalTime newEndTime =
            startTime.plusMinutes(durationMinutes);

    String sql =
            "SELECT a.appointment_id, "
          + "a.appointment_time, "
          + "COALESCE(SUM(gs.duration_minutes), 0) AS total_duration "
          + "FROM appointments a "
          + "JOIN appointment_services aps "
          + "ON a.appointment_id = aps.appointment_id "
          + "JOIN grooming_services gs "
          + "ON aps.service_id = gs.service_id "
          + "WHERE a.groomer_id = ? "
          + "AND a.appointment_date = ? "
          + "AND a.status = 'Pending' "
          + "AND a.appointment_id <> ? "
          + "GROUP BY a.appointment_id, a.appointment_time";

    try (
        Connection con = DBConnection.getConnection();
        PreparedStatement pst = con.prepareStatement(sql)
    ) {

        pst.setString(1, groomerId);
        pst.setDate(2, java.sql.Date.valueOf(date));
        pst.setInt(3, excludeAppointmentId);

        ResultSet rs = pst.executeQuery();

        while (rs.next()) {

            java.sql.Time sqlTime =
                    rs.getTime("appointment_time");

            java.time.LocalTime existingStart =
                    sqlTime.toLocalTime();

            int existingDuration =
                    rs.getInt("total_duration");

            java.time.LocalTime existingEnd =
                    existingStart.plusMinutes(existingDuration);

            boolean overlaps =
                    startTime.isBefore(existingEnd)
                    && newEndTime.isAfter(existingStart);

            if (overlaps) {
                return false;
            }
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error checking groomer availability:\n"
                + e.getMessage(),
                "Availability Error",
                JOptionPane.ERROR_MESSAGE
        );

        return false;
    }

    return true;
}

private int getSelectedServicesDuration() {

    int[] selectedIndices =
            lstServices.getSelectedIndices();

    if (selectedIndices.length == 0) {
        return 0;
    }

    int totalDuration = 0;

    StringBuilder placeholders =
            new StringBuilder();

    for (int i = 0; i < selectedIndices.length; i++) {

        if (i > 0) {
            placeholders.append(",");
        }

        placeholders.append("?");
    }

    String sql =
            "SELECT COALESCE(SUM(duration_minutes), 0) "
          + "AS total_duration "
          + "FROM grooming_services "
          + "WHERE service_id IN ("
          + placeholders
          + ")";

    try (
        Connection con = DBConnection.getConnection();
        PreparedStatement pst = con.prepareStatement(sql)
    ) {

        for (int i = 0; i < selectedIndices.length; i++) {

            pst.setInt(
                    i + 1,
                    serviceIds.get(selectedIndices[i])
            );
        }

        ResultSet rs =
                pst.executeQuery();

        if (rs.next()) {
            totalDuration =
                    rs.getInt("total_duration");
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error calculating service duration:\n"
                + e.getMessage(),
                "Duration Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    return totalDuration;
}
private boolean overlapsLunchBreak(
        java.time.LocalTime startTime,
        int durationMinutes) {

    java.time.LocalTime lunchStart =
            java.time.LocalTime.of(12, 0);

    java.time.LocalTime lunchEnd =
            java.time.LocalTime.of(13, 0);

    java.time.LocalTime endTime =
            startTime.plusMinutes(durationMinutes);

    return startTime.isBefore(lunchEnd)
            && endTime.isAfter(lunchStart);
}

private void loadAppointments() {

    DefaultTableModel model =
            (DefaultTableModel) tblAppointments.getModel();

    model.setRowCount(0);
    appointmentQueue.clear();

    
String sql =
        "SELECT a.appointment_id, "
      + "CONCAT(c.first_name, ' ', c.last_name) AS customer_name, "
      + "p.pet_name, "
      + "a.appointment_date, "
      + "a.appointment_time, "
      + "GROUP_CONCAT(DISTINCT gs.service_name SEPARATOR ', ') AS services, "
      + "CONCAT(g.first_name, ' ', g.last_name) AS groomer, "
      + "a.status, "
      + "COALESCE(pay.total_amount, "
      + " (SELECT SUM(gs2.price) "
      + "  FROM appointment_services aps2 "
      + "  JOIN grooming_services gs2 "
      + "  ON aps2.service_id = gs2.service_id "
      + "  WHERE aps2.appointment_id = a.appointment_id), "
      + " (SELECT gs3.price FROM grooming_services gs3 "
      + "  WHERE gs3.service_id = a.service_id), 0) AS total_due, "
      + "COALESCE(pay.paid_amount, 0) AS paid_amount, "
      + "CASE "
      + "WHEN COALESCE(pay.paid_amount, 0) <= 0 THEN 'Unpaid' "
      + "WHEN COALESCE(pay.paid_amount, 0) >= COALESCE(pay.total_amount, "
      + " (SELECT SUM(gs4.price) "
      + "  FROM appointment_services aps4 "
      + "  JOIN grooming_services gs4 "
      + "  ON aps4.service_id = gs4.service_id "
      + "  WHERE aps4.appointment_id = a.appointment_id), "
      + " (SELECT gs5.price FROM grooming_services gs5 "
      + "  WHERE gs5.service_id = a.service_id), 0) THEN 'Paid' "
      + "ELSE 'Partial' "
      + "END AS payment_display, "
      + "GREATEST(COALESCE(pay.total_amount, "
      + " (SELECT SUM(gs6.price) "
      + "  FROM appointment_services aps6 "
      + "  JOIN grooming_services gs6 "
      + "  ON aps6.service_id = gs6.service_id "
      + "  WHERE aps6.appointment_id = a.appointment_id), "
      + " (SELECT gs7.price FROM grooming_services gs7 "
      + "  WHERE gs7.service_id = a.service_id), 0) "
      + " - COALESCE(pay.paid_amount, 0), 0) AS balance_due "
      + "FROM appointments a "
      + "LEFT JOIN pets p ON a.pet_id = p.pet_id "
      + "LEFT JOIN customers c ON p.customer_id = c.customer_id "
      + "LEFT JOIN appointment_services aps "
      + "ON a.appointment_id = aps.appointment_id "
      + "LEFT JOIN grooming_services gs "
      + "ON aps.service_id = gs.service_id "
      + "LEFT JOIN groomers g ON a.groomer_id = g.groomer_id "
      + "LEFT JOIN ("
      + "    SELECT appointment_id, "
      + "           MAX(total_amount) AS total_amount, "
      + "           SUM(amount_paid) AS paid_amount "
      + "    FROM payments "
      + "    WHERE payment_status IS NULL "
      + "       OR payment_status <> 'Archived' "
      + "    GROUP BY appointment_id"
      + ") pay ON a.appointment_id = pay.appointment_id "
      + "WHERE "
      + "(a.status = 'Pending' AND a.appointment_date >= CURDATE()) "
      + "OR a.status = 'In Progress' "
      + "OR (a.status = 'Completed' AND a.appointment_date = CURDATE()) "
      + "GROUP BY a.appointment_id "
      + "ORDER BY CASE "
      + "WHEN a.status = 'In Progress' THEN 1 "
      + "WHEN a.status = 'Pending' THEN 2 "
      + "WHEN a.status = 'Completed' THEN 3 "
      + "ELSE 4 END, "
      + "a.appointment_date, a.appointment_time";


    try (Connection con = DBConnection.getConnection()) {

        if (con == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {

                int appointmentId = rs.getInt("appointment_id");
                String status = rs.getString("status");

                String groomerName = rs.getString("groomer");

                if (groomerName == null) {
                    groomerName = "Not Assigned";
                }

                String serviceNames = rs.getString("services");

                if (serviceNames == null
                        || serviceNames.trim().isEmpty()) {
                    serviceNames = "No Service";
                }

                java.sql.Date appointmentDate =
                        rs.getDate("appointment_date");

                java.sql.Time appointmentTime =
                        rs.getTime("appointment_time");

                String timeText = appointmentTime == null
                        ? ""
                        : appointmentTime.toString().substring(0, 5);

                
model.addRow(new Object[]{
    appointmentId,
    rs.getString("customer_name"),
    rs.getString("pet_name"),
    rs.getDate("appointment_date"),
    timeText,
    serviceNames,
    groomerName,
    status,
    rs.getString("payment_display"),
    rs.getBigDecimal("balance_due")
});

                if ("Pending".equalsIgnoreCase(status)) {
                    appointmentQueue.offer(appointmentId);
                }
            }
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error loading appointments:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    tblAppointments.revalidate();
    tblAppointments.repaint();
}

private String getPetName(String petId) {

    try {

        Connection con =
                DBConnection.getConnection();

        if (con == null) {
            return "";
        }

        String sql =
                "SELECT pet_name "
                + "FROM pets "
                + "WHERE pet_id = ?";

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setString(1, petId);

        ResultSet rs =
                pst.executeQuery();

        String petName = "";

        if (rs.next()) {
            petName = rs.getString("pet_name");
        }
        rs.close();
        pst.close();
        con.close();

        return petName;

    } catch (Exception e) {

        e.printStackTrace();

        return "";
    }
}
private void setupDateChooser() {
 
    dateChooser = new com.toedter.calendar.JDateChooser();
    dateChooser.setDateFormatString("yyyy-MM-dd");
 
    jPanel1.add(dateChooser,
    new org.netbeans.lib.awtextra.AbsoluteConstraints(608, 50, 240, 35));
    txtDate.setVisible(false);
 
    dateChooser.addPropertyChangeListener("date", evt -> {
        java.util.Date picked = dateChooser.getDate();
 
        if (picked == null) {
            txtDate.setText("");
        } else {
            txtDate.setText(new java.text.SimpleDateFormat("yyyy-MM-dd").format(picked));
        }
        updateGroomerAvailabilityDisplay();
    });
 
    jPanel1.revalidate();
    jPanel1.repaint();
}
private void loadTimeToCombo() {

    cmbTime.removeAllItems();

    cmbTime.addItem("Choose Time");

    for (int hour = 9; hour <= 17; hour++) {

        for (int minute = 0; minute < 60; minute += 30) {

            int displayHour = hour;

            String amPm = "AM";

            if (hour >= 12) {
                amPm = "PM";
            }

            if (displayHour > 12) {
                displayHour -= 12;
            }

            String time = String.format(
                    "%02d:%02d %s",
                    displayHour,
                    minute,
                    amPm
            );

            cmbTime.addItem(time);
        }
    }
}
private String convertTo12Hour(String time) {

    try {

        java.time.LocalTime localTime =
                java.time.LocalTime.parse(time);

        return localTime.format(
                java.time.format.DateTimeFormatter
                        .ofPattern("hh:mm a")
        );

    } catch (Exception e) {

        return time;
    }
}
private void colorAppointmentRows() {
 
    DefaultTableCellRenderer renderer =
            new DefaultTableCellRenderer() {
 
        @Override
        public Component getTableCellRendererComponent(
                JTable table,
                Object value,
                boolean isSelected,
                boolean hasFocus,
                int row,
                int column) {
 
            Component c = super.getTableCellRendererComponent(
                    table, value, isSelected, hasFocus, row, column);
 
            c.setForeground(Color.BLACK);
            c.setBackground(Color.WHITE);
 
            int appointmentId = Integer.parseInt(
                    table.getValueAt(row, 0).toString()
            );
 
            String status =
                    table.getValueAt(row, 7).toString();
            if (!appointmentQueue.isEmpty()
                    && appointmentId == appointmentQueue.peek()) {
 
                c.setBackground(new Color(255, 235, 156));
                c.setForeground(Color.BLACK);
 
            } else if (status.equalsIgnoreCase("Completed")) {
 
                c.setBackground(new Color(198, 239, 206));
                c.setForeground(new Color(0, 97, 0));
 
            } else if (status.equalsIgnoreCase("Cancelled")) {
 
                c.setBackground(new Color(255, 199, 206));
                c.setForeground(new Color(156, 0, 6));
            }
 
            if (isSelected) {
                c.setBackground(table.getSelectionBackground());
                c.setForeground(table.getSelectionForeground());
            }
 
            return c;
        }
    };
 
    for (int i = 0; i < tblAppointments.getColumnCount(); i++) {
        tblAppointments
                .getColumnModel()
                .getColumn(i)
                .setCellRenderer(renderer);
    }
 
    tblAppointments.repaint();
}
private void setupGroomerComboColors() {
 
    cmbGroomer.setRenderer(new javax.swing.DefaultListCellRenderer() {
 
        @Override
        public java.awt.Component getListCellRendererComponent(
                javax.swing.JList<?> list,
                Object value,
                int index,
                boolean isSelected,
                boolean cellHasFocus) {
 
            super.getListCellRendererComponent(
                    list,
                    value,
                    index,
                    isSelected,
                    cellHasFocus
            );
 
            if (value != null) {
 
                String text = value.toString();
 
                if (text.contains("🟢 Available")) {
 
                    setForeground(new java.awt.Color(0, 128, 0));
 
                } else if (text.contains("🟡 Busy Soon")) {
 
                    setForeground(new java.awt.Color(180, 120, 0));
 
                } else if (text.contains("🔴 Busy")) {
 
                    setForeground(new java.awt.Color(200, 0, 0));
 
                } else {
 
                    setForeground(java.awt.Color.BLACK);
                }
            }
 
            return this;
        }
    });
}
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> new AppointmentFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnArchieve;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnCompleteGrooming;
    private javax.swing.JButton btnGroomingCheck;
    private javax.swing.JButton btnProceedPayment;
    private javax.swing.JButton btnProcessNext;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnSearchCustomer;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cmbCustomer;
    private javax.swing.JComboBox<String> cmbGroomer;
    private javax.swing.JComboBox<String> cmbPet;
    private javax.swing.JComboBox<String> cmbStatus;
    private javax.swing.JComboBox<String> cmbTime;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JLabel lblAppointmentId;
    private javax.swing.JLabel lblAppointmentSubtitle;
    private javax.swing.JLabel lblAppointmentTitle;
    private javax.swing.JLabel lblDate;
    private javax.swing.JLabel lblService;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblTime;
    private javax.swing.JList<String> lstServices;
    private javax.swing.JTable tblAppointments;
    private javax.swing.JTextField txtAppointmentId;
    private javax.swing.JTextField txtCustomerSearch;
    private javax.swing.JTextField txtDate;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
