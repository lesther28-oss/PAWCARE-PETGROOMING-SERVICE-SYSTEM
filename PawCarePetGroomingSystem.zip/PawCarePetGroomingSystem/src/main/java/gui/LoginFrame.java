package gui;

public class LoginFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(LoginFrame.class.getName());

    public LoginFrame() {
    initComponents();

    pnlLogin.setOpaque(true);

    getContentPane().setBackground(
        new java.awt.Color(36, 59, 90)
    );

    txtPassword.setText("");
    txtPassword.setEchoChar('*');

    pnlLogin.setVisible(true);

    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        pnlLogin = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        lblUsername = new javax.swing.JLabel();
        lblPassword = new javax.swing.JLabel();
        txtUsername = new javax.swing.JTextField();
        txtPassword = new javax.swing.JPasswordField();
        btnLogin = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        chkShowPassword = new javax.swing.JCheckBox();
        jLabel14 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(36, 59, 90));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(72, 105, 150));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 200)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(72, 105, 150));
        jLabel1.setText("●");
        jLabel1.setPreferredSize(new java.awt.Dimension(80, 80));
        jLabel1.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jLabel1AncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 150, -1, -1));

        jLabel2.setBackground(new java.awt.Color(245, 247, 250));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(245, 247, 250));
        jLabel2.setText("<html>Welcome to<br>PawCare!</html>");
        jLabel2.setPreferredSize(new java.awt.Dimension(350, 90));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 190, -1, -1));

        jLabel3.setBackground(new java.awt.Color(50, 76, 112));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 230)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(72, 105, 150));
        jLabel3.setText("●");
        jLabel3.setPreferredSize(new java.awt.Dimension(180, 180));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, -80, -1, 170));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(220, 228, 238));
        jLabel4.setText("<html> Caring for every pet, one grooming<br> visit at a time. </html>");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 300, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(200, 212, 226));
        jLabel5.setText("<html> Manage your customers, pets,<br> appointments, and grooming services<br> with ease. </html>");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 360, -1, -1));

        jLabel6.setBackground(new java.awt.Color(245, 247, 250));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(245, 247, 250));
        jLabel6.setText("PawCare");
        jLabel6.setPreferredSize(new java.awt.Dimension(150, 30));
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, -1, -1));

        pnlLogin.setBackground(new java.awt.Color(235, 240, 247));
        pnlLogin.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        pnlLogin.setPreferredSize(new java.awt.Dimension(380, 430));
        pnlLogin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(36, 59, 90));
        jLabel7.setText("SIGN IN");
        pnlLogin.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 40, -1, -1));

        lblUsername.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblUsername.setForeground(new java.awt.Color(36, 59, 90));
        lblUsername.setText("Username");
        lblUsername.setPreferredSize(new java.awt.Dimension(300, 25));
        pnlLogin.add(lblUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, -1, -1));

        lblPassword.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblPassword.setForeground(new java.awt.Color(36, 59, 90));
        lblPassword.setText("Password");
        lblPassword.setPreferredSize(new java.awt.Dimension(300, 40));
        pnlLogin.add(lblPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, -1, -1));

        txtUsername.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txtUsername.setForeground(new java.awt.Color(36, 59, 90));
        txtUsername.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        txtUsername.setPreferredSize(new java.awt.Dimension(300, 40));
        txtUsername.addActionListener(this::txtUsernameActionPerformed);
        pnlLogin.add(txtUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 420, 50));

        txtPassword.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txtPassword.setForeground(new java.awt.Color(36, 59, 90));
        txtPassword.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        txtPassword.setPreferredSize(new java.awt.Dimension(300, 40));
        txtPassword.addActionListener(this::txtPasswordActionPerformed);
        pnlLogin.add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 250, 420, 50));

        btnLogin.setBackground(new java.awt.Color(36, 59, 90));
        btnLogin.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnLogin.setForeground(new java.awt.Color(255, 255, 255));
        btnLogin.setText("LOGIN");
        btnLogin.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        btnLogin.setPreferredSize(new java.awt.Dimension(300, 45));
        btnLogin.addActionListener(this::btnLoginActionPerformed);
        pnlLogin.add(btnLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 370, -1, -1));

        jLabel8.setBackground(new java.awt.Color(100, 110, 125));
        jLabel8.setForeground(new java.awt.Color(100, 110, 125));
        jLabel8.setText("Enter your account details to continue.");
        pnlLogin.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(100, 110, 125));
        jLabel9.setText("Admin access only");
        pnlLogin.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 420, -1, -1));

        chkShowPassword.setBackground(new java.awt.Color(235, 240, 247));
        chkShowPassword.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        chkShowPassword.setForeground(new java.awt.Color(100, 110, 125));
        chkShowPassword.setText("Show Password");
        chkShowPassword.addActionListener(this::chkShowPasswordActionPerformed);
        pnlLogin.add(chkShowPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 310, -1, -1));

        jLabel14.setFont(new java.awt.Font("Dialog", 0, 26)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(36, 59, 90));
        jLabel14.setText("🐾");
        pnlLogin.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 10, -1, -1));

        jLabel24.setFont(new java.awt.Font("Segoe UI Emoji", 0, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(120, 140, 165));
        jLabel24.setText("👤");
        jLabel24.setPreferredSize(new java.awt.Dimension(25, 25));
        pnlLogin.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, -1));

        jLabel27.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(120, 140, 165));
        jLabel27.setText("🔒︎");
        pnlLogin.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 30, 30));

        getContentPane().add(pnlLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 100, 520, 490));

        jLabel10.setBackground(new java.awt.Color(72, 105, 150));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 90)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(72, 105, 150));
        jLabel10.setText("●");
        jLabel10.setPreferredSize(new java.awt.Dimension(120, 120));
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 610, 80, 150));

        jLabel11.setBackground(new java.awt.Color(50, 76, 112));
        jLabel11.setFont(new java.awt.Font("Segoe UI Symbol", 0, 120)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(50, 76, 112));
        jLabel11.setText("╱");
        jLabel11.setPreferredSize(new java.awt.Dimension(120, 100));
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, -70, 310, 220));

        jLabel12.setForeground(new java.awt.Color(180, 200, 225));
        jLabel12.setText("Pet Grooming System");
        jLabel12.setPreferredSize(new java.awt.Dimension(180, 25));
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 140, -1, -1));

        jLabel13.setBackground(new java.awt.Color(245, 247, 250));
        jLabel13.setFont(new java.awt.Font("Dialog", 0, 32)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("🐾");
        jLabel13.setPreferredSize(new java.awt.Dimension(340, 42));
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 50, -1));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 0, 100)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(50, 76, 112));
        jLabel15.setText("/");
        jLabel15.setPreferredSize(new java.awt.Dimension(100, 120));
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 40, -1, -1));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 0, 150)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(72, 105, 150));
        jLabel16.setText("●");
        jLabel16.setPreferredSize(new java.awt.Dimension(65, 65));
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 560, -1, -1));

        jLabel17.setFont(new java.awt.Font("Segoe UI Symbol", 0, 32)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(72, 105, 150));
        jLabel17.setText("🐾");
        jLabel17.setPreferredSize(new java.awt.Dimension(45, 45));
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, -1));

        jLabel18.setFont(new java.awt.Font("Segoe UI Symbol", 0, 24)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(72, 105, 150));
        jLabel18.setText("🐾");
        jLabel18.setPreferredSize(new java.awt.Dimension(35, 35));
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(1230, 660, -1, -1));

        jLabel19.setFont(new java.awt.Font("Segoe UI Symbol", 0, 24)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(72, 105, 150));
        jLabel19.setText("🐾");
        jLabel19.setPreferredSize(new java.awt.Dimension(40, 40));
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 130, -1, -1));

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gui/pawcare.png"))); // NOI18N
        getContentPane().add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 490, 410, 110));

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        getContentPane().add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 170, -1, -1));

        jLabel21.setFont(new java.awt.Font("Segoe UI Symbol", 1, 24)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(72, 105, 150));
        jLabel21.setText("──────────");
        jLabel21.setPreferredSize(new java.awt.Dimension(128, 50));
        getContentPane().add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 260, -1, -1));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 300)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(50, 76, 112));
        jLabel22.setText("●");
        jLabel22.setToolTipText("");
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(-50, -200, 190, -1));

        jLabel25.setFont(new java.awt.Font("Segoe UI", 0, 200)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(72, 105, 150));
        jLabel25.setText("●");
        getContentPane().add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 540, -1, -1));

        jLabel26.setFont(new java.awt.Font("Segoe UI", 0, 250)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(50, 76, 112));
        jLabel26.setText("●");
        getContentPane().add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, 490, -1, -1));

        jLabel28.setFont(new java.awt.Font("Segoe UI Emoji", 0, 24)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(72, 105, 150));
        jLabel28.setText("🐾");
        getContentPane().add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 40, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jLabel1AncestorAdded

    }//GEN-LAST:event_jLabel1AncestorAdded

    private void txtUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsernameActionPerformed

   
    }//GEN-LAST:event_txtUsernameActionPerformed

    private void txtPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPasswordActionPerformed

    }//GEN-LAST:event_txtPasswordActionPerformed

    private void chkShowPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkShowPasswordActionPerformed

     if (chkShowPassword.isSelected()) {
        txtPassword.setEchoChar((char) 0);
    } else {
        txtPassword.setEchoChar('*');
    }

    }//GEN-LAST:event_chkShowPasswordActionPerformed

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
   
    String username = txtUsername.getText().trim();
    String password = new String(txtPassword.getPassword());

    // 1. Check if the fields are empty
    if (username.isEmpty() || password.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(
            this,
            "Please enter your username and password.",
            "Login",
            javax.swing.JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    String sql = "SELECT admin_id FROM admins "
               + "WHERE username = ? AND password = ?";

    try (java.sql.Connection con = database.DBConnection.getConnection();
         java.sql.PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, username);
        pst.setString(2, password);

        java.sql.ResultSet rs = pst.executeQuery();

        if (rs.next()) {

            MainFrame main = new MainFrame();
            main.setVisible(true);

            this.dispose();

        } else {

            javax.swing.JOptionPane.showMessageDialog(
                this,
                "Invalid username or password.",
                "Login Failed",
                javax.swing.JOptionPane.ERROR_MESSAGE
            );
        }

    } catch (Exception e) {

        javax.swing.JOptionPane.showMessageDialog(
            this,
            "Error logging in: " + e.getMessage(),
            "Database Error",
            javax.swing.JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnLoginActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new LoginFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLogin;
    private javax.swing.JCheckBox chkShowPassword;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel lblPassword;
    private javax.swing.JLabel lblUsername;
    private javax.swing.JPanel pnlLogin;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtUsername;
    // End of variables declaration//GEN-END:variables
}