
package gui;

import database.DBConnection;

import model.Payment;
import service.PaymentService;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class PaymentFrame extends javax.swing.JFrame {
    
    private int selectedAppointmentId = 0; 
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PaymentFrame.class.getName());
    private PaymentService paymentService = new PaymentService();
    
   public PaymentFrame(int appointmentId) {
    initComponents();
setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
    selectedAppointmentId = appointmentId;

    if (appointmentId > 0) {

        txtAppointmentId.setText(
            String.valueOf(appointmentId)
        );

        BigDecimal total =
                paymentService.getAppointmentTotal(appointmentId);

        if (total != null) {
            txtTotalAmount.setText(
                total.toPlainString()
            );
        }

    } else {

        txtAppointmentId.setText("");
        txtTotalAmount.setText("");
    }


    txtPaymentId.setEditable(false);
    txtAppointmentId.setEditable(false);
    txtTotalAmount.setEditable(false);
    txtChangeAmount.setEditable(false);
    txtPaymentStatus.setEditable(false);
    txtServices.setEditable(false);
    txtRemainingBalance.setEditable(false);

    txtPaymentDate.setText(
        new java.sql.Date(System.currentTimeMillis()).toString()
    );

    
if (appointmentId > 0) {

    loadServices(appointmentId);
    loadPaymentForAppointment(appointmentId);
    loadOutstandingBalance(appointmentId);

} else {

    loadPayments();

    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
}

}
    private void clearPaymentFields() {

    txtPaymentId.setText("");
    txtAmountPaid.setText("");
    txtChangeAmount.setText("");
    txtPaymentStatus.setText("");

    txtPaymentDate.setText(
        new java.sql.Date(System.currentTimeMillis()).toString()
    );

    if (selectedAppointmentId > 0) {

        txtAppointmentId.setText(
            String.valueOf(selectedAppointmentId)
        );

        BigDecimal total =
                paymentService.getAppointmentTotal(selectedAppointmentId);

        if (total != null) {
            txtTotalAmount.setText(total.toPlainString());
        }

        loadServices(selectedAppointmentId);

    } else {

        txtAppointmentId.setText("");
        txtTotalAmount.setText("");
        txtServices.setText("");
    }
}

private void loadServices(int appointmentId) {

    String sql =
            "SELECT gs.service_name, gs.price "
          + "FROM appointment_services aps "
          + "JOIN grooming_services gs "
          + "ON aps.service_id = gs.service_id "
          + "WHERE aps.appointment_id = ? "
          + "ORDER BY gs.service_name";

    StringBuilder services = new StringBuilder();
    BigDecimal total = BigDecimal.ZERO;

    try (java.sql.Connection con =
             database.DBConnection.getConnection();
         java.sql.PreparedStatement pst =
             con.prepareStatement(sql)) {

        pst.setInt(1, appointmentId);

        try (java.sql.ResultSet rs =
                 pst.executeQuery()) {

            while (rs.next()) {

                String serviceName =
                        rs.getString("service_name");

                BigDecimal price =
                        rs.getBigDecimal("price");

                services.append(serviceName)
                        .append("    ₱")
                        .append(price.toPlainString())
                        .append("\n");

                total = total.add(price);
            }
        }

        services.append("----------------------------\n");
        services.append("TOTAL    ₱")
                .append(total.toPlainString());

        txtServices.setText(services.toString());

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading services: " + e.getMessage(),
            "Payment",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
private void loadPaymentForAppointment(int appointmentId) {

    String sql =
            "SELECT payment_id, appointment_id, total_amount, "
          + "amount_paid, change_amount, payment_status, payment_date "
          + "FROM payments "
          + "WHERE appointment_id = ? "
          + "AND payment_status <> 'Archived' "
          + "ORDER BY payment_id DESC";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setInt(1, appointmentId);

        try (ResultSet rs = pst.executeQuery()) {

            DefaultTableModel model =
                    (DefaultTableModel) jTable1.getModel();

            model.setRowCount(0);

            while (rs.next()) {

                model.addRow(new Object[]{
                    rs.getInt("payment_id"),
                    rs.getInt("appointment_id"),
                    rs.getBigDecimal("total_amount"),
                    rs.getBigDecimal("amount_paid"),
                    rs.getBigDecimal("change_amount"),
                    rs.getString("payment_status"),
                    rs.getDate("payment_date")
                });
            }
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading payment: " + e.getMessage(),
            "Payment",
            JOptionPane.ERROR_MESSAGE
        );
    }
}

private void loadOutstandingBalance(int appointmentId) {

    BigDecimal totalAmount =
            paymentService.getAppointmentTotal(appointmentId);

    if (totalAmount == null) {
        return;
    }

    BigDecimal previousPaid = BigDecimal.ZERO;
    String previousStatus = "Unpaid";

    String sql =
            "SELECT amount_paid, payment_status "
          + "FROM payments "
          + "WHERE appointment_id = ? "
          + "AND (payment_status IS NULL "
          + "OR payment_status <> 'Archived') "
          + "ORDER BY payment_id DESC "
          + "LIMIT 1";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setInt(1, appointmentId);

        try (ResultSet rs = pst.executeQuery()) {
            if (rs.next()) {
                previousPaid = rs.getBigDecimal("amount_paid");

                if (previousPaid == null) {
                    previousPaid = BigDecimal.ZERO;
                }

                previousStatus = rs.getString("payment_status");
            }
        }

        BigDecimal remaining =
                totalAmount.subtract(previousPaid);

        if (remaining.compareTo(BigDecimal.ZERO) < 0) {
            remaining = BigDecimal.ZERO;
        }

        txtTotalAmount.setText(totalAmount.toPlainString());
        txtRemainingBalance.setText(remaining.toPlainString());

        txtAmountPaid.setText(remaining.toPlainString());

        txtPaymentStatus.setText(
                remaining.compareTo(BigDecimal.ZERO) == 0
                ? "Paid"
                : previousPaid.compareTo(BigDecimal.ZERO) > 0
                    ? "Partial"
                    : "Unpaid"
        );

        txtCustomerMoney.setText("");
        txtChangeAmount.setText("0.00");

    } catch (Exception e) {
        JOptionPane.showMessageDialog(
                this,
                "Error loading remaining balance: " + e.getMessage(),
                "Payment",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlForm = new javax.swing.JPanel();
        lblServiceId = new javax.swing.JLabel();
        lblServiceName = new javax.swing.JLabel();
        lblPrice = new javax.swing.JLabel();
        lblDescription = new javax.swing.JLabel();
        txtPaymentId = new javax.swing.JTextField();
        txtAppointmentId = new javax.swing.JTextField();
        txtTotalAmount = new javax.swing.JTextField();
        txtChangeAmount = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        lblServiceInformation = new javax.swing.JLabel();
        btnAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnArchieve = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtAmountPaid = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtPaymentStatus = new javax.swing.JTextField();
        txtPaymentDate = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtRemainingBalance = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtCustomerMoney = new javax.swing.JTextField();
        pnlTable = new javax.swing.JPanel();
        txtSearch = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        lblServices = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtServices = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        lblServiceTitle = new javax.swing.JLabel();
        lblServiceSubtitle = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(235, 247, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pnlForm.setBackground(new java.awt.Color(241, 248, 254));
        pnlForm.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(190, 215, 240)));
        pnlForm.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblServiceId.setBackground(new java.awt.Color(231, 243, 253));
        lblServiceId.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblServiceId.setForeground(new java.awt.Color(36, 59, 90));
        lblServiceId.setText("Payment ID");
        pnlForm.add(lblServiceId, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, -1, -1));

        lblServiceName.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblServiceName.setForeground(new java.awt.Color(36, 59, 90));
        lblServiceName.setText("Appointment ID");
        pnlForm.add(lblServiceName, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 60, -1, -1));

        lblPrice.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblPrice.setForeground(new java.awt.Color(36, 59, 90));
        lblPrice.setText("Total Amount");
        pnlForm.add(lblPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        lblDescription.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblDescription.setForeground(new java.awt.Color(36, 59, 90));
        lblDescription.setText("Change Amount");
        pnlForm.add(lblDescription, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 70, -1, -1));

        txtPaymentId.setEditable(false);
        txtPaymentId.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(190, 215, 240)));
        pnlForm.add(txtPaymentId, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, 100, 20));

        txtAppointmentId.setEditable(false);
        txtAppointmentId.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(190, 215, 240)));
        txtAppointmentId.addActionListener(this::txtAppointmentIdActionPerformed);
        pnlForm.add(txtAppointmentId, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 60, 110, 20));

        txtTotalAmount.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        pnlForm.add(txtTotalAmount, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 100, 248, 33));

        txtChangeAmount.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        pnlForm.add(txtChangeAmount, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 60, 248, 32));

        jPanel2.setBackground(new java.awt.Color(52, 89, 145));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(190, 215, 240)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblServiceInformation.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblServiceInformation.setForeground(new java.awt.Color(255, 255, 255));
        lblServiceInformation.setText("PAYMENT INFORMATION");
        jPanel2.add(lblServiceInformation, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        btnAdd.setBackground(new java.awt.Color(36, 59, 90));
        btnAdd.setForeground(java.awt.Color.white);
        btnAdd.setText("➕");
        btnAdd.addActionListener(this::btnAddActionPerformed);
        jPanel2.add(btnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(1086, 11, -1, -1));

        btnUpdate.setBackground(new java.awt.Color(36, 59, 90));
        btnUpdate.setFont(new java.awt.Font("Segoe UI Symbol", 0, 12)); // NOI18N
        btnUpdate.setForeground(java.awt.Color.white);
        btnUpdate.setText("✏");
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);
        jPanel2.add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(1121, 11, -1, -1));

        btnArchieve.setBackground(new java.awt.Color(36, 59, 90));
        btnArchieve.setForeground(java.awt.Color.white);
        btnArchieve.setText("🗑");
        btnArchieve.addActionListener(this::btnArchieveActionPerformed);
        jPanel2.add(btnArchieve, new org.netbeans.lib.awtextra.AbsoluteConstraints(1156, 11, -1, -1));

        btnClear.setBackground(new java.awt.Color(78, 190, 178));
        btnClear.setForeground(java.awt.Color.white);
        btnClear.setText("↻");
        btnClear.addActionListener(this::btnClearActionPerformed);
        jPanel2.add(btnClear, new org.netbeans.lib.awtextra.AbsoluteConstraints(1191, 11, -1, -1));

        pnlForm.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1250, 50));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(36, 59, 90));
        jLabel1.setText("Payment Status");
        pnlForm.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 110, -1, -1));

        jLabel4.setBackground(new java.awt.Color(36, 59, 90));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(36, 59, 90));
        jLabel4.setText("Downpayment / Payment");
        pnlForm.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, -1, -1));

        txtAmountPaid.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        txtAmountPaid.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtAmountPaidKeyReleased(evt);
            }
        });
        pnlForm.add(txtAmountPaid, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 200, 250, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(36, 59, 90));
        jLabel5.setText("Payment Date");
        pnlForm.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 160, -1, -1));

        txtPaymentStatus.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        pnlForm.add(txtPaymentStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 110, 250, 30));

        txtPaymentDate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        txtPaymentDate.addActionListener(this::txtPaymentDateActionPerformed);
        pnlForm.add(txtPaymentDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 160, 250, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(36, 59, 90));
        jLabel3.setText("Remaining Balance");
        pnlForm.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 200, -1, -1));

        txtRemainingBalance.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        pnlForm.add(txtRemainingBalance, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 200, 250, 30));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(36, 59, 90));
        jLabel6.setText("Customer's Money");
        pnlForm.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, -1));

        txtCustomerMoney.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(36, 59, 90)));
        txtCustomerMoney.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCustomerMoneyKeyReleased(evt);
            }
        });
        pnlForm.add(txtCustomerMoney, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 150, 250, 30));

        getContentPane().add(pnlForm, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 98, 1249, 244));

        pnlTable.setBackground(new java.awt.Color(238, 250, 247));
        pnlTable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(145, 215, 195)));
        pnlTable.setPreferredSize(new java.awt.Dimension(1000, 700));
        pnlTable.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtSearch.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(78, 190, 178)));
        pnlTable.add(txtSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(824, 10, 350, 30));

        btnSearch.setBackground(new java.awt.Color(78, 190, 178));
        btnSearch.setForeground(java.awt.Color.white);
        btnSearch.setText("🔍");
        btnSearch.addActionListener(this::btnSearchActionPerformed);
        pnlTable.add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 10, 40, 30));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "PAYMENT ID", "APPOINTMENT ID", "TOTAL AMOUNT", "AMOUNT PAID", "CHANGE AMOUNT", "PAYMENT STATUS", "PAYMENT DATE"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);

        pnlTable.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 910, 290));

        lblServices.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblServices.setText("SERVICES");
        pnlTable.add(lblServices, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 60, -1, -1));

        txtServices.setEditable(false);
        txtServices.setColumns(20);
        txtServices.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        txtServices.setRows(5);
        txtServices.setText("Bath & Blow Dry    ₱400.00\nHaircut            ₱150.00\nNail Trimming      ₱150.00\n────────────────────────\nTOTAL              ₱700.00");
        jScrollPane1.setViewportView(txtServices);

        pnlTable.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 90, 260, 260));

        getContentPane().add(pnlTable, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 360, 1249, 551));

        jPanel1.setBackground(new java.awt.Color(226, 241, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(190, 215, 240)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblServiceTitle.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        lblServiceTitle.setForeground(new java.awt.Color(36, 59, 90));
        lblServiceTitle.setText("PAYMENT MANAGEMENT");
        jPanel1.add(lblServiceTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, -1, -1));

        lblServiceSubtitle.setForeground(new java.awt.Color(36, 59, 90));
        lblServiceSubtitle.setText("Manage payments and transaction records");
        jPanel1.add(lblServiceSubtitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, -1, -1));

        btnBack.setBackground(new java.awt.Color(36, 59, 90));
        btnBack.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("←");
        btnBack.addActionListener(this::btnBackActionPerformed);
        jPanel1.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, 20));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gui/petimage3.jpg"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 0, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 6, 1250, 80));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed

        MainFrame main = new MainFrame();
        main.setVisible(true);
        
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void txtAppointmentIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAppointmentIdActionPerformed

    String appointmentText =
            txtAppointmentId.getText().trim();

    if (appointmentText.isEmpty()) {
        return;
    }

    try {

        int appointmentId =
                Integer.parseInt(appointmentText);

        BigDecimal total =
                paymentService.getAppointmentTotal(appointmentId);

        if (total == null) {

            JOptionPane.showMessageDialog(
                this,
                "Appointment not found.",
                "Payment",
                JOptionPane.WARNING_MESSAGE
            );

            txtTotalAmount.setText("");
            return;
        }

        txtTotalAmount.setText(
                total.toPlainString()
        );

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
            this,
            "Please enter a valid Appointment ID.",
            "Payment",
            JOptionPane.WARNING_MESSAGE
        );
    }
    }//GEN-LAST:event_txtAppointmentIdActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
                                   
    try {

        String appointmentText =
                txtAppointmentId.getText().trim();

        String totalText =
                txtTotalAmount.getText().trim();

        String paidText =
                txtAmountPaid.getText().trim();

        String customerMoneyText =
                txtCustomerMoney.getText().trim();

        String dateText =
                txtPaymentDate.getText().trim();

        if (appointmentText.isEmpty()
                || totalText.isEmpty()
                || paidText.isEmpty()
                || customerMoneyText.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Please complete the payment information.",
                "Payment",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        int appointmentId =
                Integer.parseInt(appointmentText);

        BigDecimal totalAmount =
                new BigDecimal(totalText);

        BigDecimal newPayment =
                new BigDecimal(paidText);

        BigDecimal customerMoney =
                new BigDecimal(customerMoneyText);

        if (newPayment.compareTo(BigDecimal.ZERO) <= 0) {

            JOptionPane.showMessageDialog(
                this,
                "Payment amount must be greater than zero.",
                "Payment",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        if (customerMoney.compareTo(BigDecimal.ZERO) <= 0) {

            JOptionPane.showMessageDialog(
                this,
                "Customer's money must be greater than zero.",
                "Payment",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        if (newPayment.compareTo(customerMoney) > 0) {

            JOptionPane.showMessageDialog(
                this,
                "Payment amount cannot be greater than customer's money.",
                "Payment",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }


        String statusSql =
                "SELECT status FROM appointments "
              + "WHERE appointment_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst =
                     con.prepareStatement(statusSql)) {

            pst.setInt(1, appointmentId);

            try (ResultSet rs = pst.executeQuery()) {

                if (!rs.next()) {

                    JOptionPane.showMessageDialog(
                        this,
                        "Appointment not found.",
                        "Payment",
                        JOptionPane.WARNING_MESSAGE
                    );

                    return;
                }

                String appointmentStatus =
                        rs.getString("status");

                if ("Cancelled".equalsIgnoreCase(appointmentStatus)
                        || "Archived".equalsIgnoreCase(appointmentStatus)) {

                    JOptionPane.showMessageDialog(
                        this,
                        "Payment cannot be processed for a "
                        + appointmentStatus + " appointment.",
                        "Payment",
                        JOptionPane.WARNING_MESSAGE
                    );

                    return;
                }
            }
        }


        String checkSql =
                "SELECT payment_id, total_amount, amount_paid, "
              + "payment_status "
              + "FROM payments "
              + "WHERE appointment_id = ? "
              + "AND payment_status <> 'Archived' "
              + "ORDER BY payment_id DESC "
              + "LIMIT 1";

        int existingPaymentId = 0;
        BigDecimal existingAmountPaid = BigDecimal.ZERO;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst =
                     con.prepareStatement(checkSql)) {

            pst.setInt(1, appointmentId);

            try (ResultSet rs = pst.executeQuery()) {

                if (rs.next()) {

                    existingPaymentId =
                            rs.getInt("payment_id");

                    existingAmountPaid =
                            rs.getBigDecimal("amount_paid");

                    String existingStatus =
                            rs.getString("payment_status");

                    if ("Paid".equalsIgnoreCase(existingStatus)) {

                        JOptionPane.showMessageDialog(
                            this,
                            "This appointment is already fully paid.",
                            "Payment",
                            JOptionPane.WARNING_MESSAGE
                        );

                        return;
                    }
                }
            }
        }

        BigDecimal totalAmountPaid;

        if (existingPaymentId > 0) {

            totalAmountPaid =
                    existingAmountPaid.add(newPayment);

        } else {

            totalAmountPaid =
                    newPayment;
        }

        if (totalAmountPaid.compareTo(totalAmount) > 0) {

            BigDecimal excess =
                    totalAmountPaid.subtract(totalAmount);

            JOptionPane.showMessageDialog(
                this,
                "Payment exceeds the remaining balance by ₱"
                + excess.toPlainString(),
                "Payment",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        BigDecimal changeAmount =
                customerMoney.subtract(newPayment);


        BigDecimal remainingBalance =
                totalAmount.subtract(totalAmountPaid);

        txtRemainingBalance.setText(
                remainingBalance.toPlainString()
        );

        txtChangeAmount.setText(
                changeAmount.toPlainString()
        );

        String paymentStatus;

        if (remainingBalance.compareTo(BigDecimal.ZERO) == 0) {

            paymentStatus = "Paid";

        } else {

            paymentStatus = "Partial";
        }


        Date paymentDate;

        if (dateText.isEmpty()) {

            paymentDate =
                    new Date(System.currentTimeMillis());

        } else {

            paymentDate =
                    Date.valueOf(dateText);
        }


        if (existingPaymentId == 0) {

            Payment payment = new Payment();

            payment.setAppointmentId(appointmentId);
            payment.setTotalAmount(totalAmount);
            payment.setAmountPaid(totalAmountPaid);
            payment.setChangeAmount(changeAmount);
            payment.setPaymentStatus(paymentStatus);
            payment.setPaymentDate(paymentDate);

            boolean success =
                    paymentService.addPayment(payment);

            if (success) {

                JOptionPane.showMessageDialog(
                    this,
                    "Payment added successfully!\n\n"
                    + "Customer's Money: ₱"
                    + customerMoney.toPlainString()
                    + "\nPayment Amount: ₱"
                    + newPayment.toPlainString()
                    + "\nChange: ₱"
                    + changeAmount.toPlainString()
                    + "\nRemaining Balance: ₱"
                    + remainingBalance.toPlainString()
                    + "\nStatus: "
                    + paymentStatus,
                    "Payment",
                    JOptionPane.INFORMATION_MESSAGE
                );

            } else {

                JOptionPane.showMessageDialog(
                    this,
                    "Failed to add payment.",
                    "Payment",
                    JOptionPane.ERROR_MESSAGE
                );

                return;
            }

        } else {

            Payment payment = new Payment();

            payment.setPaymentId(existingPaymentId);
            payment.setAppointmentId(appointmentId);
            payment.setTotalAmount(totalAmount);
            payment.setAmountPaid(totalAmountPaid);
            payment.setChangeAmount(changeAmount);
            payment.setPaymentStatus(paymentStatus);
            payment.setPaymentDate(paymentDate);

            boolean success =
                    paymentService.updatePayment(payment);

            if (success) {

                JOptionPane.showMessageDialog(
                    this,
                    "Payment updated successfully!\n\n"
                    + "Customer's Money: ₱"
                    + customerMoney.toPlainString()
                    + "\nAdditional Payment: ₱"
                    + newPayment.toPlainString()
                    + "\nTotal Paid: ₱"
                    + totalAmountPaid.toPlainString()
                    + "\nChange: ₱"
                    + changeAmount.toPlainString()
                    + "\nRemaining Balance: ₱"
                    + remainingBalance.toPlainString()
                    + "\nStatus: "
                    + paymentStatus,
                    "Payment",
                    JOptionPane.INFORMATION_MESSAGE
                );

            } else {

                JOptionPane.showMessageDialog(
                    this,
                    "Failed to update payment.",
                    "Payment",
                    JOptionPane.ERROR_MESSAGE
                );

                return;
            }
        }


        if (selectedAppointmentId > 0) {

            loadServices(selectedAppointmentId);
            loadPaymentForAppointment(selectedAppointmentId);

        } else {

            loadPayments();
        }

        txtAmountPaid.setText("");
        txtCustomerMoney.setText("");
        txtChangeAmount.setText("0.00");
        txtRemainingBalance.setText("");

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
            this,
            "Please enter valid numbers.",
            "Payment",
            JOptionPane.WARNING_MESSAGE
        );

    } catch (IllegalArgumentException e) {

        JOptionPane.showMessageDialog(
            this,
            "Payment date must be in YYYY-MM-DD format.",
            "Payment",
            JOptionPane.WARNING_MESSAGE
        );

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error: " + e.getMessage(),
            "Payment",
            JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnAddActionPerformed

    private void txtPaymentDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPaymentDateActionPerformed

    }//GEN-LAST:event_txtPaymentDateActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed

    txtCustomerMoney.setText("");
    txtRemainingBalance.setText("");
    txtPaymentId.setText("");
    txtAmountPaid.setText("");
    txtChangeAmount.setText("");
    txtPaymentStatus.setText("");

    txtPaymentDate.setText(
        new java.sql.Date(System.currentTimeMillis()).toString()
    );

    if (selectedAppointmentId > 0) {

        txtAppointmentId.setText(
            String.valueOf(selectedAppointmentId)
        );

        BigDecimal total =
                paymentService.getAppointmentTotal(selectedAppointmentId);

        if (total != null) {
            txtTotalAmount.setText(total.toPlainString());
        }

        loadServices(selectedAppointmentId);

    } else {

        txtAppointmentId.setText("");
        txtTotalAmount.setText("");
        txtServices.setText("");
        loadOutstandingBalance(selectedAppointmentId);
    }
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
                                      
    String keyword =
            txtSearch.getText().trim();

    if (keyword.isEmpty()) {

        if (selectedAppointmentId > 0) {
            loadPaymentForAppointment(selectedAppointmentId);
        } else {
            loadPayments();
        }

        return;
    }

    if (selectedAppointmentId > 0) {

        String sql =
        "SELECT payment_id, appointment_id, total_amount, "
      + "amount_paid, change_amount, payment_status, payment_date "
      + "FROM payments "
      + "WHERE appointment_id = ? "
      + "AND payment_status <> 'Archived' "
      + "AND (CAST(payment_id AS CHAR) LIKE ? "
      + "OR CAST(total_amount AS CHAR) LIKE ? "
      + "OR CAST(amount_paid AS CHAR) LIKE ? "
      + "OR payment_status LIKE ?) "
      + "ORDER BY payment_id DESC";

        DefaultTableModel model =
                (DefaultTableModel) jTable1.getModel();

        model.setRowCount(0);

        try (Connection con = database.DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            String search = "%" + keyword + "%";

            pst.setInt(1, selectedAppointmentId);
            pst.setString(2, search);
            pst.setString(3, search);
            pst.setString(4, search);
            pst.setString(5, search);

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {

                model.addRow(new Object[]{
                    rs.getInt("payment_id"),
                    rs.getInt("appointment_id"),
                    rs.getBigDecimal("total_amount"),
                    rs.getBigDecimal("amount_paid"),
                    rs.getBigDecimal("change_amount"),
                    rs.getString("payment_status"),
                    rs.getDate("payment_date")
                });
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                this,
                "Error searching payment: " + e.getMessage(),
                "Payment",
                JOptionPane.ERROR_MESSAGE
            );
        }

    } else {

        DefaultTableModel model =
                (DefaultTableModel) jTable1.getModel();

        model.setRowCount(0);

        ArrayList<Payment> payments =
                paymentService.searchPayments(keyword);

        for (Payment payment : payments) {

            model.addRow(new Object[]{
                payment.getPaymentId(),
                payment.getAppointmentId(),
                payment.getTotalAmount(),
                payment.getAmountPaid(),
                payment.getChangeAmount(),
                payment.getPaymentStatus(),
                payment.getPaymentDate()
            });
        }
    }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
                                     
    int row = jTable1.getSelectedRow();

    if (row == -1) {
        return;
    }

    txtPaymentId.setText(
        jTable1.getValueAt(row, 0).toString()
    );

    int appointmentId =
        Integer.parseInt(
            jTable1.getValueAt(row, 1).toString()
        );

    selectedAppointmentId = appointmentId;

    txtAppointmentId.setText(
        String.valueOf(appointmentId)
    );

    loadServices(appointmentId);

    txtTotalAmount.setText(jTable1.getValueAt(row, 2).toString());

String amountPaidText = jTable1.getValueAt(row, 3).toString();
txtAmountPaid.setText(amountPaidText);

BigDecimal totalAmount =
        new BigDecimal(jTable1.getValueAt(row, 2).toString());

BigDecimal amountPaid =
        new BigDecimal(amountPaidText);

BigDecimal remainingBalance =
        totalAmount.subtract(amountPaid);

if (remainingBalance.compareTo(BigDecimal.ZERO) < 0) {
    remainingBalance = BigDecimal.ZERO;
}

txtRemainingBalance.setText(
        remainingBalance.toPlainString()
);

txtChangeAmount.setText(
        jTable1.getValueAt(row, 4).toString()
);

    txtPaymentStatus.setText(
        jTable1.getValueAt(row, 5).toString()
    );

    txtPaymentDate.setText(
        jTable1.getValueAt(row, 6).toString()
    );
    }//GEN-LAST:event_jTable1MouseClicked

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed

    try {

        String paymentIdText =
                txtPaymentId.getText().trim();

        String appointmentIdText =
                txtAppointmentId.getText().trim();

        String totalText =
                txtTotalAmount.getText().trim();

        String amountPaidText =
                txtAmountPaid.getText().trim();

        String dateText =
                txtPaymentDate.getText().trim();

        if (paymentIdText.isEmpty()
                || appointmentIdText.isEmpty()
                || totalText.isEmpty()
                || amountPaidText.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Please select a payment first.",
                "Payment",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        int paymentId =
                Integer.parseInt(paymentIdText);

        int appointmentId =
                Integer.parseInt(appointmentIdText);
        String statusSql =
        "SELECT status FROM appointments "
      + "WHERE appointment_id = ?";

try (Connection con = DBConnection.getConnection();
     PreparedStatement pst =
             con.prepareStatement(statusSql)) {

    pst.setInt(1, appointmentId);

    try (ResultSet rs = pst.executeQuery()) {

        if (!rs.next()) {

            JOptionPane.showMessageDialog(
                this,
                "Appointment not found.",
                "Payment",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        String appointmentStatus =
                rs.getString("status");

        if ("Cancelled".equalsIgnoreCase(appointmentStatus)
                || "Archived".equalsIgnoreCase(appointmentStatus)) {

            JOptionPane.showMessageDialog(
                this,
                "Payment cannot be updated for a "
                + appointmentStatus + " appointment.",
                "Payment",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }
    }
}

        BigDecimal totalAmount =
                new BigDecimal(totalText);

        BigDecimal amountPaid =
                new BigDecimal(amountPaidText);

        if (amountPaid.compareTo(BigDecimal.ZERO) < 0) {

            JOptionPane.showMessageDialog(
                this,
                "Amount paid cannot be negative.",
                "Payment",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        if (amountPaid.compareTo(totalAmount) > 0) {

            JOptionPane.showMessageDialog(
                this,
                "Amount paid cannot be greater than the total amount.",
                "Payment",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        BigDecimal changeAmount =
                BigDecimal.ZERO;

        String paymentStatus;

        if (amountPaid.compareTo(totalAmount) == 0) {

            paymentStatus = "Paid";

        } else if (amountPaid.compareTo(BigDecimal.ZERO) > 0) {

            paymentStatus = "Partial";

        } else {

            paymentStatus = "Pending";
        }

        Date paymentDate;

        if (dateText.isEmpty()) {

            paymentDate =
                    new Date(System.currentTimeMillis());

        } else {

            paymentDate =
                    Date.valueOf(dateText);
        }

        Payment payment = new Payment();

        payment.setPaymentId(paymentId);
        payment.setAppointmentId(appointmentId);
        payment.setTotalAmount(totalAmount);
        payment.setAmountPaid(amountPaid);
        payment.setChangeAmount(changeAmount);
        payment.setPaymentStatus(paymentStatus);
        payment.setPaymentDate(paymentDate);

        boolean success =
                paymentService.updatePayment(payment);

        if (success) {

            JOptionPane.showMessageDialog(
                this,
                "Payment updated successfully!",
                "Payment",
                JOptionPane.INFORMATION_MESSAGE
            );

            if (selectedAppointmentId > 0) {

                loadServices(selectedAppointmentId);
                loadPaymentForAppointment(selectedAppointmentId);

            } else {

                loadPayments();
            }

            txtAmountPaid.setText("");
            txtChangeAmount.setText("");

        } else {

            JOptionPane.showMessageDialog(
                this,
                "Failed to update payment.",
                "Payment",
                JOptionPane.ERROR_MESSAGE
            );
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
            this,
            "Please enter valid numbers.",
            "Payment",
            JOptionPane.WARNING_MESSAGE
        );

    } catch (IllegalArgumentException e) {

        JOptionPane.showMessageDialog(
            this,
            "Payment date must be in YYYY-MM-DD format.",
            "Payment",
            JOptionPane.WARNING_MESSAGE
        );

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error updating payment: " + e.getMessage(),
            "Payment",
            JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnArchieveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchieveActionPerformed


    String paymentIdText =
            txtPaymentId.getText().trim();

    if (paymentIdText.isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "Please select a payment first.",
            "Archive Payment",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    int choice = JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to archive this payment?",
        "Archive Payment",
        JOptionPane.YES_NO_OPTION
    );

    if (choice != JOptionPane.YES_OPTION) {
        return;
    }

    try {

        int paymentId =
                Integer.parseInt(paymentIdText);

        boolean success =
                paymentService.archivePayment(paymentId);

        if (success) {

            JOptionPane.showMessageDialog(
                this,
                "Payment archived successfully!",
                "Archive Payment",
                JOptionPane.INFORMATION_MESSAGE
            );

            if (selectedAppointmentId > 0) {
    loadPaymentForAppointment(selectedAppointmentId);
} else {
    loadPayments();
}

clearPaymentFields();

        } else {

            JOptionPane.showMessageDialog(
                this,
                "Failed to archive payment.",
                "Archive Payment",
                JOptionPane.ERROR_MESSAGE
            );
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
            this,
            "Invalid Payment ID.",
            "Archive Payment",
            JOptionPane.WARNING_MESSAGE
        );

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error archiving payment: " + e.getMessage(),
            "Archive Payment",
            JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnArchieveActionPerformed

    private void txtAmountPaidKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtAmountPaidKeyReleased
                                     
    String totalText = txtTotalAmount.getText().trim();
    String customerMoneyText = txtCustomerMoney.getText().trim();
    String paymentText = txtAmountPaid.getText().trim();

    if (totalText.isEmpty()) {
        txtChangeAmount.setText("0.00");
        txtRemainingBalance.setText("0.00");
        return;
    }

    try {

        BigDecimal totalAmount =
                new BigDecimal(totalText);

        BigDecimal customerMoney =
                customerMoneyText.isEmpty()
                ? BigDecimal.ZERO
                : new BigDecimal(customerMoneyText);

        BigDecimal paymentAmount =
                paymentText.isEmpty()
                ? BigDecimal.ZERO
                : new BigDecimal(paymentText);

 
        if (paymentAmount.compareTo(customerMoney) > 0) {

            txtChangeAmount.setText("0.00");

            txtRemainingBalance.setText(
                    totalAmount.toPlainString()
            );

            return;
        }

        BigDecimal previousPaid = BigDecimal.ZERO;

        String appointmentText =
                txtAppointmentId.getText().trim();

        if (!appointmentText.isEmpty()) {

            int appointmentId =
                    Integer.parseInt(appointmentText);

            String sql =
                    "SELECT amount_paid "
                  + "FROM payments "
                  + "WHERE appointment_id = ? "
                  + "AND payment_status <> 'Archived' "
                  + "ORDER BY payment_id DESC "
                  + "LIMIT 1";

            try (Connection con =
                     DBConnection.getConnection();
                 PreparedStatement pst =
                     con.prepareStatement(sql)) {

                pst.setInt(1, appointmentId);

                try (ResultSet rs =
                         pst.executeQuery()) {

                    if (rs.next()) {

                        previousPaid =
                                rs.getBigDecimal("amount_paid");

                        if (previousPaid == null) {
                            previousPaid = BigDecimal.ZERO;
                        }
                    }
                }
            }
        }

 
        BigDecimal change =
                customerMoney.subtract(paymentAmount);


        BigDecimal totalPaid =
                previousPaid.add(paymentAmount);

        BigDecimal remainingBalance =
                totalAmount.subtract(totalPaid);

        if (remainingBalance.compareTo(BigDecimal.ZERO) < 0) {
            remainingBalance = BigDecimal.ZERO;
        }

        txtChangeAmount.setText(
                change.toPlainString()
        );

        txtRemainingBalance.setText(
                remainingBalance.toPlainString()
        );

    } catch (NumberFormatException e) {

        txtChangeAmount.setText("0.00");
        txtRemainingBalance.setText(
                totalText.isEmpty()
                ? "0.00"
                : totalText
        );

    } catch (Exception e) {

        txtChangeAmount.setText("0.00");
        txtRemainingBalance.setText("0.00");
    }
    }//GEN-LAST:event_txtAmountPaidKeyReleased

    private void txtCustomerMoneyKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCustomerMoneyKeyReleased

        txtAmountPaidKeyReleased(evt);
    }//GEN-LAST:event_txtCustomerMoneyKeyReleased

private void loadPayments() {

    DefaultTableModel model =
            (DefaultTableModel) jTable1.getModel();

    model.setRowCount(0);

    String sql =
            "SELECT payment_id, appointment_id, total_amount, "
          + "amount_paid, change_amount, payment_status, payment_date "
          + "FROM payments "
          + "WHERE payment_date = CURDATE() "
          + "AND payment_status <> 'Archived' "
          + "ORDER BY payment_id DESC";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = con.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("payment_id"),
                rs.getInt("appointment_id"),
                rs.getBigDecimal("total_amount"),
                rs.getBigDecimal("amount_paid"),
                rs.getBigDecimal("change_amount"),
                rs.getString("payment_status"),
                rs.getDate("payment_date")
            });
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading today's payments: " + e.getMessage(),
            "Payment",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
    public static void main(String args[]) {
  
        java.awt.EventQueue.invokeLater(() -> new PaymentFrame(0).setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnArchieve;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblDescription;
    private javax.swing.JLabel lblPrice;
    private javax.swing.JLabel lblServiceId;
    private javax.swing.JLabel lblServiceInformation;
    private javax.swing.JLabel lblServiceName;
    private javax.swing.JLabel lblServiceSubtitle;
    private javax.swing.JLabel lblServiceTitle;
    private javax.swing.JLabel lblServices;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JPanel pnlTable;
    private javax.swing.JTextField txtAmountPaid;
    private javax.swing.JTextField txtAppointmentId;
    private javax.swing.JTextField txtChangeAmount;
    private javax.swing.JTextField txtCustomerMoney;
    private javax.swing.JTextField txtPaymentDate;
    private javax.swing.JTextField txtPaymentId;
    private javax.swing.JTextField txtPaymentStatus;
    private javax.swing.JTextField txtRemainingBalance;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextArea txtServices;
    private javax.swing.JTextField txtTotalAmount;
    // End of variables declaration//GEN-END:variables
}
